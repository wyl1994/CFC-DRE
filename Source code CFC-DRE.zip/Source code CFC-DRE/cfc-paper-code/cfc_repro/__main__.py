"""Support `python -m cfc_repro` in an installed environment."""
from .cli import main

main()

