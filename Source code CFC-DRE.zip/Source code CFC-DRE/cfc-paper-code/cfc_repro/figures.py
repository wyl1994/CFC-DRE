"""Plot study outputs without requiring bundled historical result tables.

Regional SOZ/NSOZ levels use the original matched-patient plotting bootstrap.
Those levels are distinct from the paired regional contrast shown in S6.
"""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .analysis import publication as paper, reliability
from .io import write_metadata


def paired_trajectories(frame, output):
    """Plot patient-paired contrasts, distinct from subtracting two pooled medians."""
    if set(frame.n_patients) != {79}:
        raise ValueError("S6 requires the frozen 79-patient complete six-window summaries")
    fig, axes = plt.subplots(3, 2, figsize=(7.16, 5.6))
    fig.subplots_adjust(left=.115, right=.97, top=.94, bottom=.15, wspace=.30, hspace=.72)
    time = [-25, -15, -5, 5, 15, 25]
    for i, (family, label) in enumerate(zip(paper.FAMILIES, paper.LABELS)):
        ax = axes.flat[i]
        data = frame[frame.cfc_family.eq(family)].sort_values("window_order")
        if len(data) != 6:
            raise ValueError(f"Expected six trajectory values for {family}")
        ax.axvspan(-10, 10, color="#F0F1F2", zorder=-2)
        ax.axhline(0, color="#ADB4B9", linewidth=.6, zorder=-1)
        ax.axvline(0, color="#717579", linestyle=":", linewidth=.7)
        ax.fill_between(time, data.ci95_low, data.ci95_high, color=paper.SOZ, alpha=.14, linewidth=0)
        ax.plot(time, data.median_effect, color=paper.SOZ, linewidth=1.2)
        ax.set_xlim(-30, 30)
        ax.set_xticks([-30, -20, -10, 0, 10, 20, 30])
        ax.tick_params(length=2, pad=2, labelsize=8)
        ax.spines[["top", "right"]].set_visible(False)
        paper.panel(ax, f"({chr(97 + i)}) {label}")
    axes.flat[5].set_visible(False)
    fig.text(.025, .55, "Paired SOZ - NSOZ contrast", rotation=90, va="center", fontsize=9)
    fig.text(.52, .07, "Window midpoint relative to onset (s)", ha="center", fontsize=9)
    fig.text(.52, .025, "79 matched patients; patient-pooled medians and 95% bootstrap intervals", ha="center", fontsize=8)
    fig.savefig(output / "FigS06_Six_Window_Regional_Trajectories.pdf")
    fig.savefig(output / "FigS06_Six_Window_Regional_Trajectories.png", dpi=250)
    plt.close(fig)


def summarize_region_levels(patient_values, repeats=3000):
    """Preserve the author regional-trajectory bootstrap, seed and group order."""
    rng = np.random.default_rng(20260918)
    rows = []
    for (zone, window, family), group in patient_values.groupby(
        ["soz_label", "window_id", "cfc_family"], observed=True
    ):
        values = group["family_z_value"].to_numpy(float)
        samples = values[rng.integers(0, len(values), size=(repeats, len(values)))]
        low, high = np.quantile(np.median(samples, axis=1), [0.025, 0.975])
        rows.append({"soz_label": zone, "window_id": window, "cfc_family": family,
                     "n_patients": len(values), "median_z_value": np.median(values),
                     "ci95_low": low, "ci95_high": high})
    return pd.DataFrame(rows)


def regional_levels(patient_root: Path):
    """Match the exact paired features before aggregating each patient's family."""
    feature_keys = ["dataset_id", "patient_id", "window_id", "cfc_family", "method", "feature_id"]
    zone = pd.read_parquet(patient_root / "patient_zone_six_windows.parquet")
    paired = pd.read_parquet(patient_root / "patient_spatial_contrast_six_windows.parquet", columns=feature_keys)
    zone = zone.merge(paired.drop_duplicates(feature_keys), on=feature_keys,
                      how="inner", validate="many_to_one")
    if not zone.groupby(feature_keys, observed=True).soz_label.nunique().eq(2).all():
        raise ValueError("Some matched features lack SOZ or NSOZ values")
    patient_keys = ["dataset_id", "patient_id", "window_id", "soz_label", "cfc_family"]
    values = zone.groupby(patient_keys, observed=True).z_value.median().rename("family_z_value").reset_index()
    if len(values) != 79 * 6 * 2 * 5:
        raise ValueError("The paper regional-level plot requires the 79 complete matched patients")
    return summarize_region_levels(values)


def render(study: Path, output: Path, panels=None, patient_root=None):
    """Find exact analysis outputs; ambiguous or missing inputs are errors."""
    panels = panels or ["fig2", "fig3", "fig4", "s6", "s10"]
    names = {
        "spatial": "cohort_feature_statistics.csv",
        "pairwise": "pairwise_map_comparisons_revised.csv",
        "loco": "leave_one_cohort_out_map_validation.csv",
        "candidates": "candidate_validation_summary.csv",
        "primary": "中心等权五家族置换检验.csv",
        "paired_trajectory": "六窗五家族轨迹统计.csv",
        "matched_observed": "matched_window_pairwise_observed.csv",
        "matched_bootstrap": "matched_window_pairwise_bootstrap_summary.csv",
        "split_half": "matched_window_split_half_summary.csv",
    }
    needed = {"fig2": ["spatial"], "fig3": ["pairwise", "loco", "candidates"],
              "fig4": ["primary"], "s6": ["paired_trajectory"],
              "s10": ["matched_observed", "matched_bootstrap", "split_half"]}
    paths = {}
    for key in dict.fromkeys(key for panel in panels for key in needed[panel]):
        candidates = list(study.rglob(names[key]))
        if len(candidates) != 1:
            raise FileNotFoundError(f"Expected exactly one {names[key]} under {study}; found {len(candidates)}")
        paths[key] = candidates[0]
    if "fig4" in panels and patient_root is None:
        raise ValueError("Fig. 4 requires --patient-root; regional levels are not differences of pooled medians")
    paper.PROJECT = output.resolve()
    (output / "figures/main").mkdir(parents=True, exist_ok=True)
    supplementary = output / "figures/supplementary"
    supplementary.mkdir(parents=True, exist_ok=True)
    # The inherited save() writes previews beside PROJECT; use an explicit output folder.
    def save(fig, name):
        fig.savefig(output / "figures/main" / (name + ".pdf"))
        fig.savefig(output / "figures/main" / (name + ".png"), dpi=250)
        plt.close(fig)
    paper.save = save
    paper.style()
    used = []
    def read(key):
        path = paths[key]
        used.append(path)
        frame = pd.read_csv(path)
        # Inference tables use display labels; plotting uses frozen machine IDs.
        if "scope_name" in frame:
            frame["scope_name"] = frame.scope_name.replace({"CFC coherence": "CFC_coherence"})
        return frame
    if "fig2" in panels:
        paper.fig2(read("spatial"))
    if "fig3" in panels:
        paper.fig3(read("pairwise"), read("loco"), read("candidates"))
    if "fig4" in panels:
        regional = regional_levels(patient_root)
        regional.to_csv(output / "regional_trajectory_summary.csv", index=False)
        used.extend([patient_root / "patient_zone_six_windows.parquet",
                     patient_root / "patient_spatial_contrast_six_windows.parquet"])
        paper.fig4(read("primary"), regional)
    if "s6" in panels:
        paired_trajectories(read("paired_trajectory"), supplementary)
    if "s10" in panels:
        reliability.make_figure(read("matched_observed"), read("matched_bootstrap"), read("split_half"), supplementary)
    write_metadata(output, {"input_level": "computed study outputs", "group_inference_recomputed": False,
                           "regional_level_bootstrap": {"seed": 20260918, "repeats": 3000} if "fig4" in panels else None,
                           "figure_1": "Hand-edited workflow diagram; not generated by these analysis scripts"}, used)
    print(f"Publication panels written to {output}")
