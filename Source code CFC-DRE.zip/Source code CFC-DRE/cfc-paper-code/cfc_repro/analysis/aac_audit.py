"""Sampled comparison of ordinal versus average ranks in tied AAC envelopes.

Scientific definitions follow the frozen author analysis; see REPRODUCE.md.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import sys
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import signal
from scipy.stats import rankdata


TARGET_SFREQ = 500.0
CONTEXT_SEC = 68.0
PADDING_SEC = 4.0
RNG_SEED = 20260907
ALL_BANDS = (
    ("delta", 2.0, 4.0),
    ("theta", 4.0, 8.0),
    ("alpha", 8.0, 13.0),
    ("beta", 13.0, 30.0),
    ("low_gamma", 30.0, 55.0),
    ("high_gamma", 65.0, 100.0),
    ("ripple", 100.0, 150.0),
    ("fast_ripple_low", 150.0, 200.0),
)
AAC_PAIRS = [
    (left[0], right[0])
    for index, left in enumerate(ALL_BANDS)
    for right in ALL_BANDS[index + 1 :]
]
WINDOWS = (
    ("pre_cumulative_10", -10.0, 0.0),
    ("pre_cumulative_20", -20.0, 0.0),
    ("pre_cumulative_30", -30.0, 0.0),
    ("post_cumulative_10", 0.0, 10.0),
    ("post_cumulative_20", 0.0, 20.0),
    ("post_cumulative_30", 0.0, 30.0),
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Audit AAC tied-rank handling on real windows.")
    parser.add_argument("--seizures", type=Path, required=True)
    parser.add_argument("--channels", type=Path, required=True)
    parser.add_argument("--preprocessing-script", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--patients-per-cohort", type=int, default=3)
    parser.add_argument("--surrogates", type=int, default=1000)
    return parser.parse_args()


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def stable_rng(*parts: Any) -> np.random.Generator:
    text = "|".join(str(part) for part in (RNG_SEED, *parts))
    seed = int.from_bytes(hashlib.sha256(text.encode("utf-8")).digest()[:8], "little")
    return np.random.default_rng(seed)


def zscore(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=np.float64)
    standard_deviation = np.std(values)
    if standard_deviation == 0:
        return np.zeros_like(values)
    return (values - np.mean(values)) / standard_deviation


def ordinal_rank_zscore(values: np.ndarray) -> np.ndarray:
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty(values.size, dtype=np.float64)
    ranks[order] = np.arange(1, values.size + 1, dtype=np.float64)
    return zscore(ranks)


def average_rank_zscore(values: np.ndarray) -> np.ndarray:
    return zscore(rankdata(values, method="average"))


def preprocess_selected(
    values: np.ndarray, sfreq: float, mains_hz: float, preprocessing: Any
) -> np.ndarray:
    processed = np.asarray(values, dtype=np.float64)
    harmonic = mains_hz
    while harmonic <= 220.0 and harmonic < sfreq / 2.0 - 2.0:
        b, a = signal.iirnotch(harmonic, preprocessing.NOTCH_Q, fs=sfreq)
        processed = signal.filtfilt(b, a, processed, axis=-1)
        harmonic += mains_hz
    high = min(220.0, sfreq / 2.0 - 5.0)
    sos = signal.butter(4, [1.0, high], btype="bandpass", fs=sfreq, output="sos")
    processed = signal.sosfiltfilt(sos, processed, axis=-1)
    target_samples = int(round(CONTEXT_SEC * TARGET_SFREQ))
    if abs(sfreq - TARGET_SFREQ) > 1e-6 or processed.shape[-1] != target_samples:
        processed = signal.resample(processed, target_samples, axis=-1)
    return np.asarray(processed, dtype=np.float64)


def fft_bandpass_full(values: np.ndarray, low_hz: float, high_hz: float) -> np.ndarray:
    centered = np.asarray(values, dtype=np.float64) - np.mean(values)
    frequencies = np.fft.rfftfreq(centered.size, d=1.0 / TARGET_SFREQ)
    spectrum = np.fft.rfft(centered)
    spectrum *= (frequencies >= low_hz) & (frequencies <= high_hz)
    return np.fft.irfft(spectrum, n=centered.size)


def smooth_log_envelope(filtered: np.ndarray) -> np.ndarray:
    envelope = np.abs(signal.hilbert(filtered))
    log_envelope = np.log(envelope + np.finfo(np.float64).eps)
    width = int(round(0.2 * TARGET_SFREQ))
    return np.convolve(log_envelope, np.ones(width) / width, mode="same")


def build_envelopes(values: np.ndarray) -> dict[str, np.ndarray]:
    return {
        name: smooth_log_envelope(fft_bandpass_full(values, low, high))
        for name, low, high in ALL_BANDS
    }


def window_slice(start_sec: float, end_sec: float) -> slice:
    start = int(round((start_sec + 30.0 + PADDING_SEC) * TARGET_SFREQ))
    end = int(round((end_sec + 30.0 + PADDING_SEC) * TARGET_SFREQ))
    return slice(start, end)


def choose_records(
    seizures: pd.DataFrame, channels: pd.DataFrame, patients_per_cohort: int
) -> pd.DataFrame:
    counts = (
        channels.groupby(["dataset_id", "patient_id", "recording_id"], observed=True)
        .size()
        .rename("n_channels")
        .reset_index()
    )
    records = seizures.merge(counts, on=["dataset_id", "patient_id", "recording_id"], how="inner")
    chosen = []
    for dataset_id, cohort in records.groupby("dataset_id", observed=True):
        patient_counts = (
            cohort.groupby("patient_id", observed=True)["n_channels"]
            .median()
            .sort_values()
        )
        positions = np.linspace(0, len(patient_counts) - 1, patients_per_cohort + 2)[1:-1]
        selected_patients = patient_counts.index[np.rint(positions).astype(int)].tolist()
        for patient_id in selected_patients:
            candidates = cohort.loc[cohort["patient_id"] == patient_id].copy()
            target = float(candidates["n_channels"].median())
            candidates["distance"] = np.abs(candidates["n_channels"] - target)
            chosen.append(candidates.sort_values(["distance", "recording_id"]).iloc[0])
    return pd.DataFrame(chosen).reset_index(drop=True)


def choose_channels(record_channels: pd.DataFrame) -> pd.DataFrame:
    selected = []
    for label in ("SOZ", "NSOZ"):
        candidates = record_channels.loc[record_channels["soz_label"] == label].sort_values(
            "channel_index_1based"
        )
        if not candidates.empty:
            selected.append(candidates.iloc[len(candidates) // 2])
    if len(selected) < 2:
        fallback = record_channels.sort_values("channel_index_1based")
        for _, row in fallback.iloc[[len(fallback) // 3, 2 * len(fallback) // 3]].iterrows():
            if not any(row["channel_index_1based"] == item["channel_index_1based"] for item in selected):
                selected.append(row)
    return pd.DataFrame(selected[:2]).reset_index(drop=True)


def read_referenced_channels(
    record: pd.Series,
    record_channels: pd.DataFrame,
    selected_channels: pd.DataFrame,
    preprocessing: Any,
) -> tuple[dict[str, np.ndarray], float]:
    reader = preprocessing.make_reader(Path(record["signal_path"]), record["file_format"])
    try:
        arrays = []
        frequencies = []
        for row in record_channels.itertuples(index=False):
            index = reader.resolve(row.channel_name_raw, int(row.channel_index_1based))
            values, sfreq, unit = reader.read(
                index, float(record["onset_sec"]) - 34.0, CONTEXT_SEC
            )
            scale = preprocessing.unit_scale_to_uv(unit)
            arrays.append(values * (scale if scale is not None else 1.0))
            frequencies.append(sfreq)
    finally:
        reader.close()
    if max(frequencies) - min(frequencies) > 1e-6:
        raise ValueError("mixed_sampling_frequencies")
    sfreq = float(frequencies[0])
    source = signal.detrend(np.asarray(arrays, dtype=np.float64), axis=-1, type="linear")
    index_by_channel = {
        int(row.channel_index_1based): index
        for index, row in enumerate(record_channels.itertuples(index=False))
    }
    selected_indices = [
        index_by_channel[int(row.channel_index_1based)]
        for row in selected_channels.itertuples(index=False)
    ]
    selected_source = source[selected_indices]
    references = {
        "CAR": selected_source - np.mean(source, axis=0, keepdims=True),
        "median": selected_source - np.median(source, axis=0, keepdims=True),
    }
    return {
        name: preprocess_selected(
            values, sfreq, preprocessing.LINE_HZ[str(record["dataset_id"])], preprocessing
        )
        for name, values in references.items()
    }, sfreq


def circular_shifts(
    n_samples: int, n_surrogates: int, *identity: Any
) -> np.ndarray:
    minimum = 50
    maximum = n_samples - minimum
    if maximum <= minimum:
        raise ValueError("window_too_short_for_one_second_shift")
    return stable_rng(*identity, "circular_shifts").integers(
        minimum, maximum + 1, size=n_surrogates
    )


def correlation_stats(
    left: np.ndarray, right: np.ndarray, shifts: np.ndarray
) -> tuple[float, float, float, float]:
    observed = float(np.mean(left * right))
    surrogates = np.asarray(
        [np.mean(left * np.roll(right, int(shift))) for shift in shifts], dtype=float
    )
    surrogate_mean = float(np.mean(surrogates))
    surrogate_std = float(np.std(surrogates, ddof=1))
    z_value = (observed - surrogate_mean) / surrogate_std if surrogate_std > 0 else 0.0
    return observed, surrogate_mean, surrogate_std, float(z_value)


def make_figure(tie_table: pd.DataFrame, effect_table: pd.DataFrame, output: Path) -> None:
    plt.rcParams.update(
        {
            "font.family": "Arial",
            "font.size": 8,
            "axes.linewidth": 0.8,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )
    fig, axes = plt.subplots(1, 2, figsize=(7.16, 2.65), constrained_layout=True)
    ties = tie_table.groupby("band", observed=True)["tied_sample_fraction"].max().reindex(
        [band[0] for band in ALL_BANDS]
    )
    axes[0].bar(np.arange(ties.size), ties.to_numpy(), color="#4C78A8", width=0.72)
    axes[0].set_xticks(np.arange(ties.size), ties.index, rotation=45, ha="right")
    axes[0].set_ylabel("Maximum tied-sample fraction")
    axes[0].set_title("(a) Exact ties in sampled envelopes", loc="left", fontweight="bold")

    metrics = ["observed_difference", "surrogate_mean_difference", "z_difference"]
    labels = ["Observed", "Surrogate mean", "Standardized z"]
    maxima = [float(effect_table[metric].abs().max()) for metric in metrics]
    axes[1].bar(np.arange(3), maxima, color=["#16877B", "#F2A541", "#E45756"], width=0.64)
    axes[1].set_xticks(np.arange(3), labels, rotation=20, ha="right")
    axes[1].set_ylabel("Maximum absolute difference")
    axes[1].set_title("(b) Average-rank minus ordinal-rank", loc="left", fontweight="bold")
    axes[1].ticklabel_format(axis="y", style="sci", scilimits=(-3, 3))
    for axis in axes:
        axis.spines[["top", "right"]].set_visible(False)
        axis.grid(axis="y", color="#D9D9D9", linewidth=0.5, alpha=0.7)
    output.mkdir(parents=True, exist_ok=True)
    fig.savefig(output / "aac_tied_rank_audit.png", dpi=600, bbox_inches="tight")
    fig.savefig(output / "aac_tied_rank_audit.pdf", bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    data_dir = args.output / "01_统计数据"
    figure_dir = args.output / "02_结果图"
    data_dir.mkdir(parents=True, exist_ok=True)
    figure_dir.mkdir(parents=True, exist_ok=True)

    preprocessing = load_module("aac_audit_preprocessing", args.preprocessing_script)
    seizures = pd.read_csv(args.seizures, low_memory=False)
    channels = pd.read_csv(args.channels, low_memory=False)
    chosen_records = choose_records(seizures, channels, args.patients_per_cohort)
    chosen_records.to_csv(
        data_dir / "sampled_records.csv", index=False, encoding="utf-8-sig"
    )

    tie_rows = []
    effect_rows = []
    selected_channel_rows = []
    failures = []
    for record_number, record in chosen_records.iterrows():
        record_channels = channels.loc[
            (channels["dataset_id"] == record["dataset_id"])
            & (channels["recording_id"] == record["recording_id"])
        ].sort_values("channel_index_1based")
        selected_channels = choose_channels(record_channels)
        try:
            references, source_sfreq = read_referenced_channels(
                record, record_channels, selected_channels, preprocessing
            )
            for row in selected_channels.itertuples(index=False):
                selected_channel_rows.append(
                    {
                        "dataset_id": record["dataset_id"],
                        "patient_id": record["patient_id"],
                        "recording_id": record["recording_id"],
                        "channel_name": row.channel_name_raw,
                        "channel_index_1based": int(row.channel_index_1based),
                        "soz_label": row.soz_label,
                        "source_sampling_frequency_hz": source_sfreq,
                        "n_reference_channels": int(record_channels.shape[0]),
                    }
                )
            for reference_name, reference_values in references.items():
                for channel_offset, channel in enumerate(selected_channels.itertuples(index=False)):
                    envelopes = build_envelopes(reference_values[channel_offset])
                    for window_id, start_sec, end_sec in WINDOWS:
                        section = window_slice(start_sec, end_sec)
                        downsampled = {
                            name: values[section][:: int(round(TARGET_SFREQ / 50.0))]
                            for name, values in envelopes.items()
                        }
                        ordinal_ranks = {}
                        average_ranks = {}
                        for band_name, values in downsampled.items():
                            ordinal = ordinal_rank_zscore(values)
                            average = average_rank_zscore(values)
                            ordinal_ranks[band_name] = ordinal
                            average_ranks[band_name] = average
                            unique_count = np.unique(values).size
                            tie_rows.append(
                                {
                                    "dataset_id": record["dataset_id"],
                                    "patient_id": record["patient_id"],
                                    "recording_id": record["recording_id"],
                                    "channel_name": channel.channel_name_raw,
                                    "soz_label": channel.soz_label,
                                    "reference": reference_name,
                                    "window_id": window_id,
                                    "band": band_name,
                                    "n_samples": int(values.size),
                                    "n_unique_values": int(unique_count),
                                    "tied_sample_fraction": float(1.0 - unique_count / values.size),
                                    "maximum_absolute_rank_z_difference": float(
                                        np.max(np.abs(average - ordinal))
                                    ),
                                }
                            )
                        shifts = circular_shifts(
                            next(iter(downsampled.values())).size,
                            args.surrogates,
                            record["recording_id"],
                            channel.channel_name_raw,
                            window_id,
                            "aac",
                        )
                        for left_name, right_name in AAC_PAIRS:
                            ordinal_left = ordinal_ranks[left_name]
                            ordinal_right = ordinal_ranks[right_name]
                            average_left = average_ranks[left_name]
                            average_right = average_ranks[right_name]
                            ranks_identical = bool(
                                np.array_equal(ordinal_left, average_left)
                                and np.array_equal(ordinal_right, average_right)
                            )
                            ordinal_stats = correlation_stats(
                                ordinal_left, ordinal_right, shifts
                            )
                            if ranks_identical:
                                average_stats = ordinal_stats
                            else:
                                average_stats = correlation_stats(
                                    average_left, average_right, shifts
                                )
                            effect_rows.append(
                                {
                                    "dataset_id": record["dataset_id"],
                                    "patient_id": record["patient_id"],
                                    "recording_id": record["recording_id"],
                                    "channel_name": channel.channel_name_raw,
                                    "soz_label": channel.soz_label,
                                    "reference": reference_name,
                                    "window_id": window_id,
                                    "band_1": left_name,
                                    "band_2": right_name,
                                    "ranks_identical": ranks_identical,
                                    "ordinal_observed": ordinal_stats[0],
                                    "average_observed": average_stats[0],
                                    "observed_difference": average_stats[0] - ordinal_stats[0],
                                    "ordinal_surrogate_mean": ordinal_stats[1],
                                    "average_surrogate_mean": average_stats[1],
                                    "surrogate_mean_difference": average_stats[1] - ordinal_stats[1],
                                    "ordinal_surrogate_std": ordinal_stats[2],
                                    "average_surrogate_std": average_stats[2],
                                    "surrogate_std_difference": average_stats[2] - ordinal_stats[2],
                                    "ordinal_z": ordinal_stats[3],
                                    "average_z": average_stats[3],
                                    "z_difference": average_stats[3] - ordinal_stats[3],
                                }
                            )
            print(
                f"[{record_number + 1}/{len(chosen_records)}] "
                f"{record['dataset_id']} {record['recording_id']} complete",
                flush=True,
            )
        except Exception as exc:
            failures.append(
                {
                    "dataset_id": record["dataset_id"],
                    "patient_id": record["patient_id"],
                    "recording_id": record["recording_id"],
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                }
            )
            print(f"FAILED {record['recording_id']}: {exc}", flush=True)

    tie_table = pd.DataFrame(tie_rows)
    effect_table = pd.DataFrame(effect_rows)
    selected_table = pd.DataFrame(selected_channel_rows)
    failure_table = pd.DataFrame(failures)
    tie_table.to_parquet(data_dir / "aac_envelope_tie_audit.parquet", index=False)
    effect_table.to_parquet(data_dir / "aac_rank_method_effects.parquet", index=False)
    selected_table.to_csv(
        data_dir / "sampled_channels.csv", index=False, encoding="utf-8-sig"
    )
    failure_table.to_csv(data_dir / "audit_failures.csv", index=False, encoding="utf-8-sig")

    summary = {
        "records_requested": int(chosen_records.shape[0]),
        "records_completed": int(chosen_records.shape[0] - failure_table.shape[0]),
        "records_failed": int(failure_table.shape[0]),
        "channels_completed": int(selected_table.shape[0]),
        "references": ["CAR", "median"],
        "windows": [window[0] for window in WINDOWS],
        "bands": [band[0] for band in ALL_BANDS],
        "aac_pairs": len(AAC_PAIRS),
        "surrogates": args.surrogates,
        "envelope_vectors_checked": int(tie_table.shape[0]),
        "aac_estimations_compared": int(effect_table.shape[0]),
        "vectors_with_exact_ties": int((tie_table["tied_sample_fraction"] > 0).sum()),
        "maximum_tied_sample_fraction": float(tie_table["tied_sample_fraction"].max()),
        "maximum_absolute_rank_z_difference": float(
            tie_table["maximum_absolute_rank_z_difference"].max()
        ),
        "aac_estimations_with_nonidentical_ranks": int((~effect_table["ranks_identical"]).sum()),
        "maximum_absolute_observed_difference": float(effect_table["observed_difference"].abs().max()),
        "maximum_absolute_surrogate_mean_difference": float(
            effect_table["surrogate_mean_difference"].abs().max()
        ),
        "maximum_absolute_surrogate_std_difference": float(
            effect_table["surrogate_std_difference"].abs().max()
        ),
        "maximum_absolute_z_difference": float(effect_table["z_difference"].abs().max()),
    }
    (data_dir / "aac_tied_rank_audit_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    make_figure(tie_table, effect_table, figure_dir)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
