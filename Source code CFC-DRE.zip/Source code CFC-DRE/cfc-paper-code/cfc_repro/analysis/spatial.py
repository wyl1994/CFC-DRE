"""Experiment 1: patient-level regional effects and cross-cohort map agreement.

Scientific definitions follow the frozen author analysis; see REPRODUCE.md.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import shutil
from datetime import datetime
from pathlib import Path
from typing import Iterable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
from scipy import stats


plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False


COHORTS = ("Lanzhou", "ds003029", "ds004100")
FAMILIES = ("PAC", "PPC", "AAC", "Bicoherence", "CFC_coherence")
FAMILY_LABELS = {
    "PAC": "PAC",
    "PPC": "PPC",
    "AAC": "AAC",
    "Bicoherence": "Bicoherence",
    "CFC_coherence": "CFC coherence",
}
UPPER_RIPPLE_LEGACY_KEY = "fast_ripple_low"
UPPER_RIPPLE_RANGE_HZ = (150.0, 200.0)
UPPER_RIPPLE_LABEL = "Upper-ripple (150-200 Hz)"
COLORS = {
    "Lanzhou": "#D97941",
    "ds003029": "#2E8B8B",
    "ds004100": "#3B6FB6",
}
PAIR_DEFINITIONS = (
    ("Lanzhou", "ds003029"),
    ("Lanzhou", "ds004100"),
    ("ds003029", "ds004100"),
)
PART_NAMES = {
    1: "01_三队列独立SOZ与NSOZ分析",
    2: "02_三队列两两效应图一致性比较",
    3: "03_跨队列特征复现分层",
    4: "04_敏感性分析",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Revised Experiment 1 analysis")
    parser.add_argument("--patient-table", required=True, type=Path)
    parser.add_argument("--feature-catalog", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--output-root", required=True, type=Path)
    parser.add_argument("--feature-bootstrap", type=int, default=10000)
    parser.add_argument("--map-bootstrap", type=int, default=5000)
    parser.add_argument("--permutations", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=20260914)
    return parser.parse_args()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def bh_fdr(values: Iterable[float]) -> np.ndarray:
    p = np.asarray(list(values), dtype=float)
    q = np.full(p.shape, np.nan, dtype=float)
    valid = np.isfinite(p)
    if not valid.any():
        return q
    raw = p[valid]
    order = np.argsort(raw)
    ranked = raw[order]
    adjusted = ranked * len(ranked) / np.arange(1, len(ranked) + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    adjusted = np.clip(adjusted, 0, 1)
    restored = np.empty_like(adjusted)
    restored[order] = adjusted
    q[valid] = restored
    return q


def rank_biserial(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values) & ~np.isclose(values, 0)]
    if not len(values):
        return 0.0
    ranks = stats.rankdata(np.abs(values))
    positive = float(ranks[values > 0].sum())
    negative = float(ranks[values < 0].sum())
    return (positive - negative) / (positive + negative)


def bca_median_ci(
    values: np.ndarray, repeats: int, rng: np.random.Generator
) -> tuple[float, float]:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if len(values) < 2:
        return math.nan, math.nan
    if np.allclose(values, values[0]):
        return float(values[0]), float(values[0])
    try:
        result = stats.bootstrap(
            (values,),
            np.median,
            n_resamples=repeats,
            confidence_level=0.95,
            method="BCa",
            vectorized=True,
            random_state=rng,
        )
        return float(result.confidence_interval.low), float(result.confidence_interval.high)
    except (TypeError, ValueError, FloatingPointError):
        sample = rng.choice(values, size=(repeats, len(values)), replace=True)
        return tuple(np.quantile(np.median(sample, axis=1), [0.025, 0.975]).astype(float))


def summarize_group(
    patient: pd.DataFrame,
    catalog: pd.DataFrame,
    group_name: str,
    repeats: int,
    seed: int,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows: list[dict[str, object]] = []
    for feature_id in catalog["feature_id"]:
        group = patient[patient["feature_id"].eq(feature_id)]
        values = group["diff_median"].to_numpy(dtype=float)
        if np.allclose(values, 0):
            statistic, p_value = 0.0, 1.0
        else:
            test = stats.wilcoxon(
                values, alternative="two-sided", zero_method="wilcox", method="auto"
            )
            statistic, p_value = float(test.statistic), float(test.pvalue)
        ci_low, ci_high = bca_median_ci(values, repeats, rng)
        spec = catalog.loc[catalog["feature_id"].eq(feature_id)].iloc[0]
        rows.append(
            {
                "analysis_group": group_name,
                "cfc_family": spec["cfc_family"],
                "method": spec["method"],
                "feature_id": feature_id,
                "n_patients": int(group["patient_id"].nunique()),
                "soz_group_median": float(np.median(group["z_region_median_soz"])),
                "nsoz_group_median": float(np.median(group["z_region_median_nsoz"])),
                "median_difference": float(np.median(values)),
                "mean_difference": float(np.mean(values)),
                "ci95_low": ci_low,
                "ci95_high": ci_high,
                "wilcoxon_statistic": statistic,
                "p_value": p_value,
                "rank_biserial": rank_biserial(values),
                "positive_patients": int(np.sum(values > 0)),
                "negative_patients": int(np.sum(values < 0)),
                "positive_fraction": float(np.mean(values > 0)),
            }
        )
    result = pd.DataFrame(rows)
    result["q_value_global"] = bh_fdr(result["p_value"])
    result["robust_soz_advantage"] = (
        result["q_value_global"].lt(0.05)
        & result["ci95_low"].gt(0)
        & result["rank_biserial"].gt(0)
    )
    result["robust_nsoz_advantage"] = (
        result["q_value_global"].lt(0.05)
        & result["ci95_high"].lt(0)
        & result["rank_biserial"].lt(0)
    )
    return result


def build_matrix(patient: pd.DataFrame, catalog: pd.DataFrame) -> np.ndarray:
    wide = patient.pivot(index="patient_id", columns="feature_id", values="diff_median")
    wide = wide.reindex(columns=catalog["feature_id"])
    if wide.isna().any().any():
        raise RuntimeError("Missing patient-feature values in matrix")
    return wide.to_numpy(dtype=float)


def safe_spearman(x: np.ndarray, y: np.ndarray) -> float:
    keep = np.isfinite(x) & np.isfinite(y)
    if keep.sum() < 3:
        return math.nan
    return float(stats.spearmanr(x[keep], y[keep]).statistic)


def rowwise_spearman(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    rx = stats.rankdata(x, axis=1)
    ry = stats.rankdata(y, axis=1)
    rx -= rx.mean(axis=1, keepdims=True)
    ry -= ry.mean(axis=1, keepdims=True)
    denominator = np.sqrt(np.sum(rx * rx, axis=1) * np.sum(ry * ry, axis=1))
    return np.divide(
        np.sum(rx * ry, axis=1),
        denominator,
        out=np.full(len(rx), np.nan),
        where=denominator > 0,
    )


def scope_indices(catalog: pd.DataFrame) -> list[tuple[str, str, np.ndarray]]:
    scopes = [("overall", f"All {len(catalog)} features", np.arange(len(catalog)))]
    for family in FAMILIES:
        idx = np.flatnonzero(catalog["cfc_family"].eq(family).to_numpy())
        if len(idx) >= 3:
            scopes.append(("family", FAMILY_LABELS[family], idx))
    return scopes


def fisher_macro(rhos: list[float]) -> float:
    finite = np.asarray([x for x in rhos if np.isfinite(x)], dtype=float)
    if not len(finite):
        return math.nan
    return float(np.tanh(np.mean(np.arctanh(np.clip(finite, -0.999999, 0.999999)))))


def pairwise_comparisons(
    patient: pd.DataFrame,
    catalog: pd.DataFrame,
    definitions: list[tuple[str, str, str]],
    group_column: str,
    bootstrap_repeats: int,
    permutation_repeats: int,
    seed: int,
) -> pd.DataFrame:
    matrices = {
        name: build_matrix(patient[patient[group_column].eq(name)], catalog)
        for name in sorted(set([x[0] for x in definitions] + [x[1] for x in definitions]))
    }
    scopes = scope_indices(catalog)
    rows: list[dict[str, object]] = []
    for pair_index, (left, right, label) in enumerate(definitions):
        left_matrix = matrices[left]
        right_matrix = matrices[right]
        left_map = np.median(left_matrix, axis=0)
        right_map = np.median(right_matrix, axis=0)
        rng = np.random.default_rng(seed + pair_index * 100)
        batch_size = 100
        bootstrap_values = {name: np.empty(bootstrap_repeats) for _, name, _ in scopes}
        direction_values = {name: np.empty(bootstrap_repeats) for _, name, _ in scopes}
        family_bootstrap = {
            FAMILY_LABELS[f]: np.empty(bootstrap_repeats) for f in FAMILIES
            if np.sum(catalog["cfc_family"].eq(f)) >= 3
        }
        for start in range(0, bootstrap_repeats, batch_size):
            stop = min(start + batch_size, bootstrap_repeats)
            size = stop - start
            li = rng.integers(0, len(left_matrix), size=(size, len(left_matrix)))
            ri = rng.integers(0, len(right_matrix), size=(size, len(right_matrix)))
            lm = np.median(left_matrix[li], axis=1)
            rm = np.median(right_matrix[ri], axis=1)
            for _, scope_name, idx in scopes:
                vals = rowwise_spearman(lm[:, idx], rm[:, idx])
                bootstrap_values[scope_name][start:stop] = vals
                direction_values[scope_name][start:stop] = np.mean(
                    np.sign(lm[:, idx]) == np.sign(rm[:, idx]), axis=1
                )
                if scope_name in family_bootstrap:
                    family_bootstrap[scope_name][start:stop] = vals

        p_values: dict[str, float] = {}
        permutation_values = {name: np.empty(permutation_repeats) for _, name, _ in scopes}
        for start in range(0, permutation_repeats, batch_size):
            stop = min(start + batch_size, permutation_repeats)
            size = stop - start
            signs = rng.choice(np.array([-1.0, 1.0]), size=(size, len(right_matrix), 1))
            permuted = np.median(right_matrix[None, :, :] * signs, axis=1)
            fixed = np.repeat(left_map[None, :], size, axis=0)
            for _, scope_name, idx in scopes:
                permutation_values[scope_name][start:stop] = rowwise_spearman(
                    fixed[:, idx], permuted[:, idx]
                )

        point_family_rhos: list[float] = []
        point_family_directions: list[float] = []
        for scope_type, scope_name, idx in scopes:
            rho = safe_spearman(left_map[idx], right_map[idx])
            direction = float(np.mean(np.sign(left_map[idx]) == np.sign(right_map[idx])))
            p_value = float(
                (1 + np.sum(np.abs(permutation_values[scope_name]) >= abs(rho)))
                / (permutation_repeats + 1)
            )
            p_values[scope_name] = p_value
            rows.append(
                {
                    "comparison": label,
                    "left_group": left,
                    "right_group": right,
                    "scope_type": scope_type,
                    "scope_name": scope_name,
                    "n_features": int(len(idx)),
                    "n_patients_left": int(len(left_matrix)),
                    "n_patients_right": int(len(right_matrix)),
                    "spearman_rho": rho,
                    "rho_ci95_low": float(np.quantile(bootstrap_values[scope_name], 0.025)),
                    "rho_ci95_high": float(np.quantile(bootstrap_values[scope_name], 0.975)),
                    "direction_agreement": direction,
                    "direction_ci95_low": float(np.quantile(direction_values[scope_name], 0.025)),
                    "direction_ci95_high": float(np.quantile(direction_values[scope_name], 0.975)),
                    "median_absolute_error": float(np.median(np.abs(left_map[idx] - right_map[idx]))),
                    "permutation_p": p_value,
                }
            )
            if scope_type == "family":
                point_family_rhos.append(rho)
                point_family_directions.append(direction)

        macro_boot = np.array(
            [fisher_macro([family_bootstrap[name][i] for name in family_bootstrap]) for i in range(bootstrap_repeats)]
        )
        macro_rho = fisher_macro(point_family_rhos)
        rows.append(
            {
                "comparison": label,
                "left_group": left,
                "right_group": right,
                "scope_type": "macro",
                "scope_name": "Five-family equal-weight macro",
                "n_features": 5,
                "n_patients_left": int(len(left_matrix)),
                "n_patients_right": int(len(right_matrix)),
                "spearman_rho": macro_rho,
                "rho_ci95_low": float(np.quantile(macro_boot, 0.025)),
                "rho_ci95_high": float(np.quantile(macro_boot, 0.975)),
                "direction_agreement": float(np.mean(point_family_directions)),
                "direction_ci95_low": math.nan,
                "direction_ci95_high": math.nan,
                "median_absolute_error": math.nan,
                "permutation_p": math.nan,
            }
        )

    result = pd.DataFrame(rows)
    result["permutation_q"] = np.nan
    for scope_type in ("overall", "family"):
        mask = result["scope_type"].eq(scope_type)
        result.loc[mask, "permutation_q"] = bh_fdr(result.loc[mask, "permutation_p"])
    return result


def family_summary(feature_stats: pd.DataFrame) -> pd.DataFrame:
    summary = (
        feature_stats.groupby(["analysis_group", "cfc_family"], observed=True)
        .agg(
            n_features=("feature_id", "size"),
            fdr_significant=("q_value_global", lambda x: int(np.sum(x < 0.05))),
            robust_soz=("robust_soz_advantage", "sum"),
            robust_nsoz=("robust_nsoz_advantage", "sum"),
            median_effect=("median_difference", "median"),
            median_positive_fraction=("positive_fraction", "median"),
        )
        .reset_index()
    )
    summary["robust_soz_fraction"] = summary["robust_soz"] / summary["n_features"]
    return summary


def cohort_summary(feature_stats: pd.DataFrame) -> pd.DataFrame:
    return (
        feature_stats.groupby("analysis_group", observed=True)
        .agg(
            n_patients=("n_patients", "max"),
            n_features=("feature_id", "size"),
            fdr_significant=("q_value_global", lambda x: int(np.sum(x < 0.05))),
            robust_soz=("robust_soz_advantage", "sum"),
            robust_nsoz=("robust_nsoz_advantage", "sum"),
        )
        .reset_index()
    )


def replication_classification(feature_stats: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Keep all-cohort direction and joint statistical support as separate sets.

    This yields the 228 and 75 definitions. LOCO's 82-feature validation set
    comes from a different discovery/held-out question in loco.py.
    """
    columns = [
        "cfc_family", "method", "feature_id", "analysis_group", "median_difference",
        "q_value_global", "ci95_low", "ci95_high", "rank_biserial",
        "robust_soz_advantage", "robust_nsoz_advantage", "positive_fraction",
    ]
    wide_parts = []
    for cohort in COHORTS:
        part = feature_stats[feature_stats["analysis_group"].eq(cohort)][columns].copy()
        part = part.drop(columns="analysis_group").rename(
            columns={c: f"{cohort}_{c}" for c in part.columns if c not in ["cfc_family", "method", "feature_id"]}
        )
        wide_parts.append(part)
    merged = wide_parts[0]
    for part in wide_parts[1:]:
        merged = merged.merge(part, on=["cfc_family", "method", "feature_id"], validate="one_to_one")

    robust_count = sum(merged[f"{c}_robust_soz_advantage"].astype(int) for c in COHORTS)
    positive_all = np.logical_and.reduce([merged[f"{c}_median_difference"].gt(0) for c in COHORTS])
    negative_all = np.logical_and.reduce([merged[f"{c}_median_difference"].lt(0) for c in COHORTS])
    classification = np.full(len(merged), "三队列方向混合", dtype=object)
    classification[negative_all] = "三队列均为NSOZ方向"
    classification[positive_all & (robust_count < 2)] = "三队列同为SOZ方向但稳健不足两队列"
    classification[positive_all & (robust_count == 2)] = "两队列稳健且第三队列同为SOZ方向"
    classification[positive_all & (robust_count == 3)] = "三队列均稳健SOZ优势"
    merged["robust_soz_cohort_count"] = robust_count
    merged["replication_class"] = classification

    order = [
        "三队列均稳健SOZ优势",
        "两队列稳健且第三队列同为SOZ方向",
        "三队列同为SOZ方向但稳健不足两队列",
        "三队列均为NSOZ方向",
        "三队列方向混合",
    ]
    summary = (
        merged.groupby(["cfc_family", "replication_class"], observed=True)
        .size().rename("n_features").reset_index()
    )
    overall = merged.groupby("replication_class").size().rename("n_features").reset_index()
    overall.insert(0, "cfc_family", "Overall")
    summary = pd.concat([overall, summary], ignore_index=True)
    summary["replication_class"] = pd.Categorical(summary["replication_class"], order, ordered=True)
    summary = summary.sort_values(["cfc_family", "replication_class"]).reset_index(drop=True)
    summary["replication_class"] = summary["replication_class"].astype(str)
    return merged, summary


def setup_output(root: Path) -> dict[int, dict[str, Path]]:
    root.mkdir(parents=True, exist_ok=True)
    paths: dict[int, dict[str, Path]] = {}
    for number, name in PART_NAMES.items():
        part = root / name
        data = part / "01_统计数据"
        figures = part / "02_结果图"
        code = part / "03_分析代码"
        for folder in (data, figures, code):
            folder.mkdir(parents=True, exist_ok=True)
        paths[number] = {"root": part, "data": data, "figures": figures, "code": code}
    return paths


def save_figure(fig: plt.Figure, path: Path) -> None:
    fig.savefig(path.with_suffix(".png"), dpi=240, bbox_inches="tight", facecolor="white")
    fig.savefig(path.with_suffix(".pdf"), bbox_inches="tight", facecolor="white")
    plt.close(fig)


def plot_robust_proportions(summary: pd.DataFrame, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(10.5, 5.2))
    x = np.arange(len(FAMILIES))
    width = 0.24
    for offset, cohort in enumerate(COHORTS):
        group = summary[summary["analysis_group"].eq(cohort)].set_index("cfc_family")
        values = [100 * group.loc[f, "robust_soz_fraction"] for f in FAMILIES]
        ax.bar(x + (offset - 1) * width, values, width, label=cohort, color=COLORS[cohort])
    ax.set_xticks(x, [FAMILY_LABELS[f] for f in FAMILIES])
    ax.set_ylabel("Robust SOZ-advantage features (%)")
    ax.set_ylim(0, 105)
    ax.legend(frameon=False, ncol=3, loc="upper center")
    ax.grid(axis="y", alpha=0.2)
    ax.set_title("Cohort-specific robust CFC feature proportions", weight="bold")
    fig.tight_layout()
    save_figure(fig, path)


def plot_pairwise_forest(comparisons: pd.DataFrame, path: Path, title: str) -> None:
    scopes = [f"All {comparisons.loc[comparisons.scope_type.eq('overall'), 'n_features'].max()} features"]
    scopes += [FAMILY_LABELS[f] for f in FAMILIES]
    scopes += ["Five-family equal-weight macro"]
    comparison_labels = comparisons["comparison"].drop_duplicates().tolist()
    fig, axes = plt.subplots(1, len(comparison_labels), figsize=(15.8, 5.4), sharey=True)
    axes = np.atleast_1d(axes)
    for ax, comparison in zip(axes, comparison_labels):
        group = comparisons[comparisons["comparison"].eq(comparison)].set_index("scope_name")
        y = np.arange(len(scopes))
        rho = np.array([group.loc[s, "spearman_rho"] for s in scopes])
        low = np.array([group.loc[s, "rho_ci95_low"] for s in scopes])
        high = np.array([group.loc[s, "rho_ci95_high"] for s in scopes])
        valid = np.isfinite(low) & np.isfinite(high)
        ax.hlines(y[valid], low[valid], high[valid], color="#8DAFC4", linewidth=2)
        ax.plot(low[valid], y[valid], "|", color="#8DAFC4", markersize=7)
        ax.plot(high[valid], y[valid], "|", color="#8DAFC4", markersize=7)
        ax.plot(rho[valid], y[valid], "o", color="#315F7D")
        ax.plot(rho[~valid], y[~valid], "D", color="#D97941")
        ax.axvline(0, color="#8B949E", ls="--", lw=1)
        ax.set_xlim(-1, 1)
        ax.set_title(comparison)
        ax.set_xlabel("Spearman rho (95% patient bootstrap CI)")
        ax.grid(axis="x", alpha=0.2)
    axes[0].set_yticks(np.arange(len(scopes)), scopes)
    fig.suptitle(title, weight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    save_figure(fig, path)


def plot_pairwise_scatter(patient: pd.DataFrame, catalog: pd.DataFrame, path: Path) -> None:
    maps = {
        cohort: np.median(build_matrix(patient[patient["dataset_id"].eq(cohort)], catalog), axis=0)
        for cohort in COHORTS
    }
    fig, axes = plt.subplots(1, 3, figsize=(14.8, 4.8))
    for ax, (left, right) in zip(axes, PAIR_DEFINITIONS):
        ax.scatter(maps[left], maps[right], s=16, alpha=0.55, color="#315F7D", edgecolors="none")
        lim = max(np.max(np.abs(maps[left])), np.max(np.abs(maps[right]))) * 1.04
        ax.plot([-lim, lim], [-lim, lim], color="#999999", ls="--", lw=1)
        ax.axhline(0, color="#D0D0D0", lw=0.8)
        ax.axvline(0, color="#D0D0D0", lw=0.8)
        ax.set_xlim(-lim, lim)
        ax.set_ylim(-lim, lim)
        ax.set_xlabel(f"{left} median SOZ-NSOZ Z")
        ax.set_ylabel(f"{right} median SOZ-NSOZ Z")
        ax.set_title(f"rho = {safe_spearman(maps[left], maps[right]):.3f}")
    fig.suptitle("Pairwise cohort effect maps", weight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    save_figure(fig, path)


def plot_replication(summary: pd.DataFrame, path: Path) -> None:
    order = ["Overall"] + list(FAMILIES)
    classes = [
        "三队列均稳健SOZ优势",
        "两队列稳健且第三队列同为SOZ方向",
        "三队列同为SOZ方向但稳健不足两队列",
        "三队列均为NSOZ方向",
        "三队列方向混合",
    ]
    colors = ["#2E8B8B", "#76B7B2", "#B8D8D5", "#D97941", "#9B9B9B"]
    pivot = summary.pivot(index="cfc_family", columns="replication_class", values="n_features").fillna(0)
    fig, ax = plt.subplots(figsize=(11.5, 6.4))
    left = np.zeros(len(order))
    for cls, color in zip(classes, colors):
        values = np.array([pivot.loc[group, cls] if group in pivot.index and cls in pivot.columns else 0 for group in order])
        display_order = ["Overall" if group == "Overall" else FAMILY_LABELS[group] for group in order]
        ax.barh(display_order, values, left=left, label=cls, color=color)
        left += values
    ax.set_xlabel("Number of features")
    ax.set_title("Cross-cohort feature replication classes", weight="bold")
    ax.legend(
        frameon=False,
        fontsize=8,
        ncol=2,
        loc="upper center",
        bbox_to_anchor=(0.5, -0.14),
    )
    ax.grid(axis="x", alpha=0.2)
    fig.tight_layout(rect=(0, 0.13, 1, 1))
    save_figure(fig, path)


def plot_upper_ripple_sensitivity(
    primary: pd.DataFrame, sensitivity: pd.DataFrame, path: Path
) -> None:
    p = primary[primary["scope_type"].eq("overall")].set_index("comparison")
    s = sensitivity[sensitivity["scope_type"].eq("overall")].set_index("comparison")
    labels = list(p.index)
    x = np.arange(len(labels))
    fig, ax = plt.subplots(figsize=(9.8, 5.0))
    ax.plot(x, p.loc[labels, "spearman_rho"], "o-", lw=2, label="All 312 features", color="#315F7D")
    ax.plot(x, s.loc[labels, "spearman_rho"], "s-", lw=2, label="Exclude upper-ripple (150-200 Hz)", color="#D97941")
    ax.set_xticks(x, labels, rotation=12, ha="right")
    ax.set_ylabel("Spearman rho")
    ax.set_ylim(0, 1)
    ax.set_title("Upper-ripple exclusion sensitivity", weight="bold")
    ax.legend(frameon=False)
    ax.grid(axis="y", alpha=0.2)
    fig.tight_layout()
    save_figure(fig, path)


def markdown_table(frame: pd.DataFrame, columns: list[str], digits: int = 3) -> str:
    view = frame[columns].copy()
    for column in view.columns:
        if pd.api.types.is_float_dtype(view[column]):
            view[column] = view[column].map(lambda x: "" if not np.isfinite(x) else f"{x:.{digits}f}")
    lines = ["| " + " | ".join(columns) + " |", "|" + "|".join(["---"] * len(columns)) + "|"]
    for row in view.astype(str).itertuples(index=False, name=None):
        lines.append("| " + " | ".join(str(x) for x in row) + " |")
    return "\n".join(lines)


def write_text(path: Path, text: str) -> None:
    path.write_text(text.strip() + "\n", encoding="utf-8")


def write_reports(
    paths: dict[int, dict[str, Path]],
    feature_stats: pd.DataFrame,
    fam_summary: pd.DataFrame,
    coh_summary: pd.DataFrame,
    pairwise: pd.DataFrame,
    replication_summary: pd.DataFrame,
    high_stats: pd.DataFrame,
    high_pairwise: pd.DataFrame,
    modality_pairwise: pd.DataFrame,
    removed_features: int,
) -> None:
    cohort_table = markdown_table(
        coh_summary,
        ["analysis_group", "n_patients", "n_features", "fdr_significant", "robust_soz", "robust_nsoz"],
        0,
    )
    family_table = markdown_table(
        fam_summary,
        ["analysis_group", "cfc_family", "n_features", "robust_soz", "robust_soz_fraction", "median_effect", "median_positive_fraction"],
    )
    overall_pair = pairwise[pairwise["scope_type"].eq("overall")]
    pair_table = markdown_table(
        overall_pair,
        ["comparison", "n_patients_left", "n_patients_right", "n_features", "spearman_rho", "rho_ci95_low", "rho_ci95_high", "direction_agreement", "permutation_p", "permutation_q"],
    )
    family_pair = pairwise[pairwise["scope_type"].isin(["family", "macro"])]
    family_pair_table = markdown_table(
        family_pair,
        ["comparison", "scope_name", "n_features", "spearman_rho", "rho_ci95_low", "rho_ci95_high", "direction_agreement", "permutation_q"],
    )
    replication_table = markdown_table(
        replication_summary,
        ["cfc_family", "replication_class", "n_features"],
        0,
    )
    high_cohort = cohort_summary(high_stats)
    high_table = markdown_table(
        high_cohort,
        ["analysis_group", "n_patients", "n_features", "fdr_significant", "robust_soz", "robust_nsoz"],
        0,
    )
    high_pair_table = markdown_table(
        high_pairwise[high_pairwise["scope_type"].eq("overall")],
        ["comparison", "n_features", "spearman_rho", "rho_ci95_low", "rho_ci95_high", "direction_agreement", "permutation_q"],
    )
    modality_table = markdown_table(
        modality_pairwise[modality_pairwise["scope_type"].isin(["overall", "family", "macro"])],
        ["comparison", "scope_name", "n_patients_left", "n_patients_right", "n_features", "spearman_rho", "rho_ci95_low", "rho_ci95_high", "direction_agreement", "permutation_q"],
    )

    reports = {
        1: f"""
# 三个队列独立SOZ与NSOZ分析 详细结果

## 目的

分别检验Lanzhou、ds003029和ds004100在发作起始后0至30秒内的患者级SOZ与NSOZ CFC差异。分析单位为患者；同一接触点先跨发作取中位数，再在患者内分别汇总SOZ和NSOZ接触点。

## 队列整体结果

{cohort_table}

## 五类CFC结果

{family_table}

## 解释原则

- 稳健SOZ优势要求全局BH-FDR q小于0.05、BCa患者bootstrap置信区间下限大于0，并且配对秩二列效应量为正。
- 显著特征数只描述各家族内部覆盖范围。由于五类CFC的特征数量不同，不能直接用数量判断哪种方法更强。
- NSOZ表示临床标记的非SOZ接触点，不代表正常脑组织。
- 该窗口统一称为post-onset 0至30秒，因为没有统一可靠的发作终止时间。
""",
        2: f"""
# 三个队列两两效应图一致性比较 详细结果

## 目的

比较三个队列的312维患者中位SOZ减NSOZ效应图，判断频率特征的强弱排序和效应方向能否跨队列复现。本部分不设置发现集或验证集，也不称为外部验证。

## 完整效应图结果

{pair_table}

## 五类CFC及等权结果

{family_pair_table}

## 解释

- Spearman相关是主要一致性指标，反映两个队列中312个特征的效应排序是否相似。
- 方向一致率反映SOZ减NSOZ效应符号相同的特征比例。
- 置信区间在每次bootstrap中同时重采样两个队列的患者，因此包含两侧队列的抽样不确定性。
- 三组整体比较的置换P值单独进行BH校正；15组家族比较的置换P值另行BH校正。
- 五家族等权相关先分别计算PAC、PPC、AAC、Bicoherence和CFC coherence相关，再在Fisher变换尺度等权平均，避免特征较多的家族主导结论。
""",
        3: f"""
# 跨队列特征复现分层 详细结果

## 目的

将显著性复现与方向复现分开。样本较小的队列可能因统计功效不足而未达到显著，但仍可与其他队列表现出相同方向。

## 分层结果

{replication_table}

## 分类规则

- 三队列均稳健SOZ优势：三个队列均满足q、置信区间和效应方向标准。
- 两队列稳健且第三队列同方向：两个队列达到稳健标准，另一个队列中位效应仍为正。
- 三队列同方向但稳健不足两队列：方向一致，但统计证据较弱。
- 三队列均为NSOZ方向：三个队列的患者中位效应均为负。
- 三队列方向混合：至少一个队列与其他队列方向不同。

该分层是描述性复现结果，不替代实验二的留一队列验证。
""",
        4: f"""
# 实验一敏感性分析 详细结果

## Upper-ripple频段排除敏感性

本分析删除所有涉及Upper-ripple（150至200 Hz）的{removed_features}个特征，在剩余282个特征上重新执行队列内统计和队列间比较。原始特征表为保持历史结果可追溯，仍保留内部键`fast_ripple_low`；该键在本项目中的真实数值范围始终为150至200 Hz，并不代表经典定义的fast ripple。

{high_table}

{high_pair_table}

如果排除该频段后主要相关、方向一致率和优势家族保持接近，说明实验一结论不依赖150至200 Hz上部ripple频段。

## 电极类型匹配分析

{modality_table}

比较包括Lanzhou SEEG与ds004100 SEEG、ds003029 ECoG与ds004100 ECoG，以及ds004100内部SEEG与ECoG。该分析用于区分中心差异和植入方式差异。

## 统计修订

主分析增加五家族等权相关，并对三组整体比较和15组家族比较分别进行BH校正。原实验一已同时bootstrap两侧患者，因此该部分不需要额外修正。
""",
    }

    file_descriptions = {
        1: "本目录保存三个队列各自的患者级SOZ与NSOZ统计结果。01_统计数据为CSV结果，02_结果图为PNG和PDF，03_分析代码保存本轮可复现程序。详细结果分析.md解释主要指标和结论边界。",
        2: "本目录保存三个独立队列两两效应图比较，包括完整特征、五类CFC和五家族等权结果。整体与家族置换检验分别进行BH校正。",
        3: "本目录保存312个特征在三个队列中的复现分类。该分类区分稳健显著、仅方向一致、NSOZ方向和方向混合。",
        4: "本目录保存排除Upper-ripple（150至200 Hz）特征和电极类型匹配分析。原始内部键fast_ripple_low仅为历史键名。所有分析使用现有患者级CFC数据，不重新计算原始CFC或surrogate。",
    }
    for number in PART_NAMES:
        write_text(paths[number]["root"] / "README_文件说明.md", "# 文件说明\n\n" + file_descriptions[number])
        write_text(paths[number]["root"] / "详细结果分析.md", reports[number])
        write_text(
            paths[number]["code"] / "运行说明.md",
            "# 运行说明\n\n本目录中的程序是实验一统一分析程序。使用xiaoluozai环境运行，并提供患者级Parquet、特征目录CSV、冻结发作清单和输出目录。程序会同时生成实验一四个部分，因此不应分别手工修改结果表。",
        )

    full_report = f"""
# 实验一 三个队列发作起始后SOZ与NSOZ的五类CFC差异及跨队列一致性

## 研究目的

本实验检验三个队列各自的SOZ与NSOZ CFC差异、队列间完整效应图一致性、特征复现层级及关键敏感性。全部分析以患者为独立单位，使用既有post-onset 0至30秒、CAR参考、500 Hz和1000次surrogate标准化数据。

## 主要队列结果

{cohort_table}

## 主要跨队列结果

{pair_table}

## 结果边界

实验一能够回答三个队列是否存在SOZ与NSOZ差异及其频率图谱是否相似；不能回答发作前后变化、临床分类性能或严格外部验证。单队列与包含自身的总体比较、显著特征交集和中位绝对误差不再作为正文主要证据。
"""
    write_text(paths[1]["root"].parent / "实验一_完整结果报告.md", full_report)


def main() -> None:
    args = parse_args()
    patient = pd.read_parquet(args.patient_table)
    catalog = pd.read_csv(args.feature_catalog).drop_duplicates("feature_id").reset_index(drop=True)
    manifest = pd.read_csv(args.manifest)
    if len(catalog) != 312 or patient["feature_id"].nunique() != 312:
        raise RuntimeError("Expected 312 features")
    if set(patient["dataset_id"].unique()) != set(COHORTS):
        raise RuntimeError("Expected exactly three cohorts")
    if patient.duplicated(["dataset_id", "patient_id", "feature_id"]).any():
        raise RuntimeError("Duplicate patient-feature rows")

    paths = setup_output(args.output_root)

    cohort_stats = []
    for index, cohort in enumerate(COHORTS):
        print(f"Part 1: {cohort}", flush=True)
        cohort_stats.append(
            summarize_group(
                patient[patient["dataset_id"].eq(cohort)],
                catalog,
                cohort,
                args.feature_bootstrap,
                args.seed + index,
            )
        )
    feature_stats = pd.concat(cohort_stats, ignore_index=True)
    fam_summary = family_summary(feature_stats)
    coh_summary = cohort_summary(feature_stats)
    feature_stats.to_csv(paths[1]["data"] / "cohort_feature_statistics.csv", index=False, encoding="utf-8-sig")
    fam_summary.to_csv(paths[1]["data"] / "cohort_family_summary.csv", index=False, encoding="utf-8-sig")
    coh_summary.to_csv(paths[1]["data"] / "cohort_summary.csv", index=False, encoding="utf-8-sig")
    top = (
        feature_stats[feature_stats["robust_soz_advantage"]]
        .sort_values(["analysis_group", "cfc_family", "median_difference"], ascending=[True, True, False])
        .groupby(["analysis_group", "cfc_family"], observed=True).head(5)
    )
    top.to_csv(paths[1]["data"] / "top_robust_features_by_cohort_and_family.csv", index=False, encoding="utf-8-sig")
    plot_robust_proportions(fam_summary, paths[1]["figures"] / "cohort_robust_feature_proportions")

    print("Part 2: pairwise comparisons", flush=True)
    definitions = [(a, b, f"{a} vs {b}") for a, b in PAIR_DEFINITIONS]
    pairwise = pairwise_comparisons(
        patient, catalog, definitions, "dataset_id", args.map_bootstrap,
        args.permutations, args.seed + 1000,
    )
    pairwise.to_csv(paths[2]["data"] / "pairwise_map_comparisons_revised.csv", index=False, encoding="utf-8-sig")
    plot_pairwise_forest(pairwise, paths[2]["figures"] / "pairwise_family_equal_weight_correlations", "Cross-cohort CFC effect-map agreement")
    plot_pairwise_scatter(patient, catalog, paths[2]["figures"] / "pairwise_effect_scatter")

    print("Part 3: feature replication", flush=True)
    replication_detail, replication_summary = replication_classification(feature_stats)
    replication_detail.to_csv(paths[3]["data"] / "feature_replication_classification.csv", index=False, encoding="utf-8-sig")
    replication_summary.to_csv(paths[3]["data"] / "feature_replication_summary.csv", index=False, encoding="utf-8-sig")
    plot_replication(replication_summary, paths[3]["figures"] / "feature_replication_classes")

    print("Part 4: upper-ripple exclusion sensitivity", flush=True)
    high_mask = catalog[["band_1", "band_2"]].eq(UPPER_RIPPLE_LEGACY_KEY).any(axis=1)
    high_catalog = catalog.loc[~high_mask].reset_index(drop=True)
    high_patient = patient[patient["feature_id"].isin(high_catalog["feature_id"])].copy()
    high_stats_parts = []
    for index, cohort in enumerate(COHORTS):
        high_stats_parts.append(
            summarize_group(
                high_patient[high_patient["dataset_id"].eq(cohort)], high_catalog,
                cohort, args.feature_bootstrap, args.seed + 3000 + index,
            )
        )
    high_stats = pd.concat(high_stats_parts, ignore_index=True)
    high_pairwise = pairwise_comparisons(
        high_patient, high_catalog, definitions, "dataset_id", args.map_bootstrap,
        args.permutations, args.seed + 4000,
    )
    high_stats.to_csv(paths[4]["data"] / "exclude_upper_ripple_150_200Hz_cohort_feature_statistics.csv", index=False, encoding="utf-8-sig")
    high_pairwise.to_csv(paths[4]["data"] / "exclude_upper_ripple_150_200Hz_pairwise_comparisons.csv", index=False, encoding="utf-8-sig")
    catalog.loc[high_mask].to_csv(paths[4]["data"] / "excluded_upper_ripple_150_200Hz_features.csv", index=False, encoding="utf-8-sig")
    plot_upper_ripple_sensitivity(pairwise, high_pairwise, paths[4]["figures"] / "upper_ripple_exclusion_sensitivity")

    print("Part 4: implant-type sensitivity", flush=True)
    implant = (
        manifest.groupby(["dataset_id", "patient_id"], observed=True)["implant_type"]
        .first().rename("implant_type").reset_index()
    )
    sensitivity_patient = patient.merge(implant, on=["dataset_id", "patient_id"], how="left", validate="many_to_one")
    if sensitivity_patient["implant_type"].isna().any():
        raise RuntimeError("Missing implant type after manifest merge")
    sensitivity_patient["analysis_subgroup"] = sensitivity_patient["dataset_id"] + "_" + sensitivity_patient["implant_type"].str.upper()
    modality_definitions = [
        ("Lanzhou_SEEG", "ds004100_SEEG", "Lanzhou SEEG vs ds004100 SEEG"),
        ("ds003029_ECOG", "ds004100_ECOG", "ds003029 ECoG vs ds004100 ECoG"),
        ("ds004100_SEEG", "ds004100_ECOG", "ds004100 SEEG vs ds004100 ECoG"),
    ]
    modality_pairwise = pairwise_comparisons(
        sensitivity_patient, catalog, modality_definitions, "analysis_subgroup",
        args.map_bootstrap, args.permutations, args.seed + 5000,
    )
    modality_pairwise.to_csv(paths[4]["data"] / "implant_type_matched_comparisons.csv", index=False, encoding="utf-8-sig")
    plot_pairwise_forest(modality_pairwise, paths[4]["figures"] / "implant_type_matched_family_correlations", "Implant-type matched CFC agreement")

    write_reports(
        paths, feature_stats, fam_summary, coh_summary, pairwise,
        replication_summary, high_stats, high_pairwise, modality_pairwise,
        int(high_mask.sum()),
    )

    for number in PART_NAMES:
        shutil.copy2(Path(__file__), paths[number]["code"] / "run_experiment1_revised.py")

    metadata = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "input_patient_table": str(args.patient_table),
        "input_patient_table_sha256": sha256_file(args.patient_table),
        "feature_catalog": str(args.feature_catalog),
        "feature_catalog_sha256": sha256_file(args.feature_catalog),
        "manifest": str(args.manifest),
        "manifest_sha256": sha256_file(args.manifest),
        "patients": int(patient["patient_id"].nunique()),
        "patient_feature_rows": int(len(patient)),
        "features_primary": int(len(catalog)),
        "features_without_upper_ripple_150_200Hz": int(len(high_catalog)),
        "frequency_band_definition": {
            "legacy_internal_key": UPPER_RIPPLE_LEGACY_KEY,
            "display_name": UPPER_RIPPLE_LABEL,
            "low_hz": UPPER_RIPPLE_RANGE_HZ[0],
            "high_hz": UPPER_RIPPLE_RANGE_HZ[1],
        },
        "feature_bootstrap_repeats": args.feature_bootstrap,
        "map_bootstrap_repeats": args.map_bootstrap,
        "permutation_repeats": args.permutations,
        "seed": args.seed,
        "window": "post-onset 0-30 s",
        "reference": "CAR",
        "sampling_rate_hz": 500,
        "surrogates": 1000,
        "python": platform.python_version(),
        "pandas": pd.__version__,
        "numpy": np.__version__,
        "scipy": scipy.__version__,
    }
    (args.output_root / "run_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    write_text(
        args.output_root / "README_实验一总说明.md",
        "# 实验一总说明\n\n本目录仅包含修订后的正式实验一。四个编号目录依次对应三个队列独立分析、队列两两一致性、特征复现分层和敏感性分析。旧版单队列与总体比较、总体效应散点图及旧摘要不再保留。各部分均含统计数据、结果图、分析代码、文件说明和详细中文结果分析。",
    )
    print(json.dumps({"status": "complete", "output": str(args.output_root)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
