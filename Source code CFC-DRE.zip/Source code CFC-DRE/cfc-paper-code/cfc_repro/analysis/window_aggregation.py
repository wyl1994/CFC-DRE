"""Seizures within contacts, then contacts within regions; preserve this aggregation order.

Scientific definitions follow the frozen author analysis; see REPRODUCE.md.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
from scipy import stats


COHORTS = ("Lanzhou", "ds003029", "ds004100")
FAMILIES = ("AAC", "Bicoherence", "CFC_coherence", "PAC", "PPC")
WINDOWS = (
    "pre_temporal_early",
    "pre_temporal_middle",
    "pre_cumulative_10",
    "post_cumulative_10",
    "post_temporal_middle",
    "post_temporal_late",
)
WINDOW_LABELS = {
    "pre_temporal_early": "-30 to -20",
    "pre_temporal_middle": "-20 to -10",
    "pre_cumulative_10": "-10 to 0",
    "post_cumulative_10": "0 to 10",
    "post_temporal_middle": "10 to 20",
    "post_temporal_late": "20 to 30",
}
PRE_NEAR = "pre_cumulative_10"
POST_EARLY = "post_cumulative_10"
VALUE_COLUMNS = ("z_value", "observed_value", "surrogate_mean", "surrogate_std")
FEATURE_COLUMNS = (
    "cfc_family",
    "method",
    "feature_id",
    "frequency_1",
    "frequency_2",
    "frequency_3",
    "band_1",
    "band_2",
    "ratio_label",
)
READ_COLUMNS = (
    "dataset_id",
    "patient_id",
    "recording_id",
    "implant_type",
    "source_sampling_frequency_hz",
    "channel_name",
    "channel_index_1based",
    "soz_label",
    "window_id",
    "window_start_sec",
    "window_end_sec",
    "cfc_family",
    "method",
    "feature_id",
    "frequency_1",
    "frequency_2",
    "frequency_3",
    "band_1",
    "band_2",
    "ratio_label",
    "observed_value",
    "surrogate_mean",
    "surrogate_std",
    "z_value",
    "finite_pass",
    "zero_surrogate_variance",
)


@dataclass(frozen=True)
class Paths:
    root: Path
    patient: Path
    primary: Path
    trajectory: Path
    cross: Path
    sensitivity: Path
    report: Path
    code: Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Latest six-window Experiment 3 analysis")
    parser.add_argument("--run-root", type=Path, required=True)
    parser.add_argument("--bootstrap-repeats", type=int, default=3000)
    parser.add_argument("--loco-bootstrap-repeats", type=int, default=1500)
    parser.add_argument("--seed", type=int, default=20260917)
    parser.add_argument(
        "--reuse-patient-tables",
        action="store_true",
        help="Reuse validated patient-level parquet files and rerun statistics only.",
    )
    return parser.parse_args()


def make_paths(root: Path) -> Paths:
    paths = Paths(
        root=root,
        patient=root / "04_患者级六窗数据",
        primary=root / "05_主要早期交互",
        trajectory=root / "06_完整时间轨迹",
        cross=root / "07_跨队列动态验证",
        sensitivity=root / "08_来源诊断与敏感性",
        report=root / "09_正式图表与报告",
        code=root / "10_分析代码与运行记录",
    )
    for path in paths.__dict__.values():
        Path(path).mkdir(parents=True, exist_ok=True)
    return paths


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def bh_fdr(values: pd.Series | np.ndarray) -> np.ndarray:
    p = np.asarray(values, dtype=float)
    q = np.full(p.shape, np.nan, dtype=float)
    good = np.isfinite(p)
    if not good.any():
        return q
    pv = p[good]
    order = np.argsort(pv)
    ranked = pv[order]
    adjusted = ranked * len(ranked) / np.arange(1, len(ranked) + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    restored = np.empty_like(adjusted)
    restored[order] = np.minimum(adjusted, 1.0)
    q[good] = restored
    return q


def signed_wilcoxon(values: np.ndarray) -> tuple[float, float]:
    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    x = x[~np.isclose(x, 0.0)]
    if len(x) == 0:
        return 0.0, 1.0
    try:
        result = stats.wilcoxon(x, alternative="two-sided", method="auto")
        return float(result.statistic), float(result.pvalue)
    except ValueError:
        return math.nan, 1.0


def rank_biserial(values: np.ndarray) -> float:
    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    x = x[~np.isclose(x, 0.0)]
    if len(x) == 0:
        return 0.0
    ranks = stats.rankdata(np.abs(x), method="average")
    denominator = float(ranks.sum())
    if denominator == 0:
        return 0.0
    return float((ranks[x > 0].sum() - ranks[x < 0].sum()) / denominator)


def bootstrap_median_ci(
    values: np.ndarray, repeats: int, rng: np.random.Generator
) -> tuple[float, float]:
    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) < 2:
        return math.nan, math.nan
    if np.allclose(x, x[0]):
        return float(x[0]), float(x[0])
    try:
        result = stats.bootstrap(
            (x,),
            np.median,
            vectorized=True,
            n_resamples=repeats,
            method="BCa",
            confidence_level=0.95,
            random_state=rng,
        )
        return float(result.confidence_interval.low), float(result.confidence_interval.high)
    except (ValueError, FloatingPointError):
        samples = rng.choice(x, size=(repeats, len(x)), replace=True)
        return tuple(np.quantile(np.median(samples, axis=1), [0.025, 0.975]))


def summarize_effects(
    frame: pd.DataFrame,
    keys: list[str],
    value: str,
    repeats: int,
    seed: int,
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    rng = np.random.default_rng(seed)
    for key, group in frame.groupby(keys, observed=True, sort=False):
        key_values = key if isinstance(key, tuple) else (key,)
        x = group[value].to_numpy(float)
        x = x[np.isfinite(x)]
        stat, p = signed_wilcoxon(x)
        low, high = bootstrap_median_ci(x, repeats, rng)
        row = dict(zip(keys, key_values))
        row.update(
            n_patients=len(x),
            median_effect=float(np.median(x)) if len(x) else math.nan,
            mean_effect=float(np.mean(x)) if len(x) else math.nan,
            ci95_low=low,
            ci95_high=high,
            wilcoxon_statistic=stat,
            p_value=p,
            rank_biserial=rank_biserial(x),
            positive_patient_proportion=float(np.mean(x > 0)) if len(x) else math.nan,
        )
        rows.append(row)
    return pd.DataFrame(rows)


def apply_grouped_fdr(frame: pd.DataFrame, group_keys: list[str]) -> pd.DataFrame:
    out = frame.copy()
    out["q_value"] = np.nan
    if not group_keys:
        out["q_value"] = bh_fdr(out["p_value"])
        return out
    for _, index in out.groupby(group_keys, observed=True).groups.items():
        out.loc[index, "q_value"] = bh_fdr(out.loc[index, "p_value"])
    return out


def catalog_from_file(path: Path) -> pd.DataFrame:
    frame = pd.read_parquet(path, columns=list(FEATURE_COLUMNS))
    catalog = frame.drop_duplicates("feature_id").copy()
    if len(catalog) != 312:
        raise RuntimeError(f"Expected 312 features, found {len(catalog)} in {path}")
    return catalog.sort_values(["cfc_family", "method", "feature_id"]).reset_index(drop=True)


def build_record_sets(eligibility: pd.DataFrame) -> tuple[set[tuple[str, str]], set[tuple[str, str]], set[tuple[str, str]]]:
    post = eligibility[eligibility["start_sec"].astype(float).ge(0)].copy()
    early_bad = post[
        post["start_sec"].astype(float).eq(0)
        & post["window_state_status"].eq("extends_beyond_annotated_offset")
    ]
    full_bad = post[post["window_state_status"].eq("extends_beyond_annotated_offset")]
    all_records = set(zip(eligibility["dataset_id"], eligibility["recording_id"]))
    early_records = all_records - set(zip(early_bad["dataset_id"], early_bad["recording_id"]))
    full_records = all_records - set(zip(full_bad["dataset_id"], full_bad["recording_id"]))
    confirmed = eligibility[
        eligibility["offset_status"].eq("confirmed_ge30")
    ][["dataset_id", "recording_id"]].drop_duplicates()
    confirmed_records = set(zip(confirmed["dataset_id"], confirmed["recording_id"]))
    return early_records, full_records, confirmed_records


def aggregate_zone_window(
    frame: pd.DataFrame,
    record_set: set[tuple[str, str]],
    method: str = "median",
) -> pd.DataFrame:
    """Summarize eligible seizures within contact, then contacts within region.

    Repeated seizures do not give a contact extra weight. Each output row is
    one patient/region/window/feature; mean is the explicit sensitivity mode.
    """
    selected = frame[
        pd.MultiIndex.from_frame(frame[["dataset_id", "recording_id"]]).isin(record_set)
    ].copy()
    selected["channel_key"] = (
        selected["channel_index_1based"].astype(str)
        + "|"
        + selected["channel_name"].fillna("").astype(str)
    )
    contact_keys = [
        "dataset_id",
        "patient_id",
        "channel_key",
        "soz_label",
        "window_id",
        "cfc_family",
        "method",
        "feature_id",
    ]
    region_keys = [
        "dataset_id",
        "patient_id",
        "soz_label",
        "window_id",
        "cfc_family",
        "method",
        "feature_id",
    ]
    aggregation = "median" if method == "median" else "mean"
    contact = (
        selected.groupby(contact_keys, observed=True, sort=False)[list(VALUE_COLUMNS)]
        .agg(aggregation)
        .reset_index()
    )
    region = (
        contact.groupby(region_keys, observed=True, sort=False)[list(VALUE_COLUMNS)]
        .agg(aggregation)
        .reset_index()
    )
    counts = (
        contact.groupby(region_keys, observed=True, sort=False)
        .agg(n_channels=("channel_key", "nunique"))
        .reset_index()
    )
    return region.merge(counts, on=region_keys, how="left", validate="one_to_one")


def spatial_contrast(region: pd.DataFrame) -> pd.DataFrame:
    """Pair SOZ and NSOZ within patient/window/feature and subtract SOZ-NSOZ."""
    keys = ["dataset_id", "patient_id", "window_id", "cfc_family", "method", "feature_id"]
    value_cols = list(VALUE_COLUMNS) + ["n_channels"]
    soz = region[region["soz_label"].eq("SOZ")][keys + value_cols]
    nsoz = region[region["soz_label"].eq("NSOZ")][keys + value_cols]
    paired = soz.merge(nsoz, on=keys, how="inner", suffixes=("_soz", "_nsoz"), validate="one_to_one")
    for column in VALUE_COLUMNS:
        paired[f"spatial_{column}"] = paired[f"{column}_soz"] - paired[f"{column}_nsoz"]
    return paired


def early_interaction(spatial: pd.DataFrame) -> pd.DataFrame:
    """Compute paired post-minus-pre regional contrasts for matched 10-s windows."""
    keys = ["dataset_id", "patient_id", "cfc_family", "method", "feature_id"]
    columns = [f"spatial_{column}" for column in VALUE_COLUMNS]
    pre = spatial[spatial["window_id"].eq(PRE_NEAR)][keys + columns]
    post = spatial[spatial["window_id"].eq(POST_EARLY)][keys + columns]
    paired = pre.merge(post, on=keys, how="inner", suffixes=("_pre", "_post"), validate="one_to_one")
    for column in VALUE_COLUMNS:
        paired[f"interaction_{column}"] = (
            paired[f"spatial_{column}_post"] - paired[f"spatial_{column}_pre"]
        )
    paired["diff_median"] = paired["interaction_z_value"]
    return paired


def process_patients(
    shard_root: Path,
    eligibility: pd.DataFrame,
    paths: Paths,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    files = sorted(shard_root.rglob("*.parquet"))
    if len(files) != 269:
        raise RuntimeError(f"Expected 269 final shards, found {len(files)}")
    catalog = catalog_from_file(files[0])
    early_set, full_set, confirmed_set = build_record_sets(eligibility)

    grouped: dict[tuple[str, str], list[Path]] = {}
    for path in files:
        rel = path.relative_to(shard_root)
        grouped.setdefault((rel.parts[0], rel.parts[1]), []).append(path)

    early_regions: list[pd.DataFrame] = []
    full_regions: list[pd.DataFrame] = []
    mean_regions: list[pd.DataFrame] = []
    confirmed_regions: list[pd.DataFrame] = []
    qc_rows: list[dict[str, object]] = []
    total = len(grouped)
    for index, ((dataset_id, patient_id), patient_files) in enumerate(sorted(grouped.items()), 1):
        parts = [pd.read_parquet(path, columns=list(READ_COLUMNS)) for path in sorted(patient_files)]
        frame = pd.concat(parts, ignore_index=True)
        frame = frame[
            frame["soz_label"].isin(["SOZ", "NSOZ"])
            & frame["window_id"].isin(WINDOWS)
            & frame["finite_pass"].eq(1)
            & frame["zero_surrogate_variance"].eq(0)
        ].copy()
        for column in VALUE_COLUMNS:
            frame = frame[np.isfinite(frame[column])]
        patient_record_keys = set(zip(frame["dataset_id"], frame["recording_id"]))
        patient_early = patient_record_keys & early_set
        patient_full = patient_record_keys & full_set
        patient_confirmed = patient_record_keys & confirmed_set
        early = aggregate_zone_window(
            frame[frame["window_id"].isin([PRE_NEAR, POST_EARLY])], patient_early, "median"
        )
        full = aggregate_zone_window(frame, patient_full, "median")
        mean = aggregate_zone_window(frame, patient_full, "mean")
        confirmed = aggregate_zone_window(frame, patient_confirmed, "median")
        early_regions.append(early)
        full_regions.append(full)
        mean_regions.append(mean)
        if not confirmed.empty:
            confirmed_regions.append(confirmed)
        qc_rows.append(
            {
                "dataset_id": dataset_id,
                "patient_id": patient_id,
                "records_total": len(patient_files),
                "records_early_primary": len(patient_early),
                "records_full_trajectory": len(patient_full),
                "records_confirmed_ge30": len(patient_confirmed),
                "channels_soz": int(frame.loc[frame["soz_label"].eq("SOZ"), "channel_name"].nunique()),
                "channels_nsoz": int(frame.loc[frame["soz_label"].eq("NSOZ"), "channel_name"].nunique()),
                "features": int(frame["feature_id"].nunique()),
            }
        )
        print(
            f"[patient {index:02d}/{total}] {dataset_id}/{patient_id}: "
            f"early={len(patient_early)}, full={len(patient_full)}, confirmed30={len(patient_confirmed)}",
            flush=True,
        )

    early_region = pd.concat(early_regions, ignore_index=True)
    full_region = pd.concat(full_regions, ignore_index=True)
    mean_region = pd.concat(mean_regions, ignore_index=True)
    confirmed_region = pd.concat(confirmed_regions, ignore_index=True)
    early = early_interaction(spatial_contrast(early_region))
    full_spatial = spatial_contrast(full_region)
    mean_spatial = spatial_contrast(mean_region)
    confirmed_spatial = spatial_contrast(confirmed_region)
    qc = pd.DataFrame(qc_rows)

    catalog.to_csv(paths.patient / "feature_catalog.csv", index=False, encoding="utf-8-sig")
    eligibility.to_csv(paths.patient / "window_state_eligibility_used.csv", index=False, encoding="utf-8-sig")
    qc.to_csv(paths.patient / "patient_processing_qc.csv", index=False, encoding="utf-8-sig")
    early_region.to_parquet(paths.patient / "patient_zone_early_windows.parquet", index=False)
    full_region.to_parquet(paths.patient / "patient_zone_six_windows.parquet", index=False)
    full_spatial.to_parquet(paths.patient / "patient_spatial_contrast_six_windows.parquet", index=False)
    early.to_parquet(paths.patient / "patient_early_interaction_312_features.parquet", index=False)
    mean_spatial.to_parquet(paths.patient / "sensitivity_mean_patient_spatial_contrast.parquet", index=False)
    confirmed_spatial.to_parquet(paths.patient / "sensitivity_confirmed_ge30_spatial_contrast.parquet", index=False)
    return catalog, early, full_region, full_spatial, mean_spatial, confirmed_spatial


def family_effects(frame: pd.DataFrame, value: str, output_name: str = "family_effect") -> pd.DataFrame:
    keys = [column for column in ["dataset_id", "patient_id", "window_id", "cfc_family"] if column in frame.columns]
    return (
        frame.groupby(keys, observed=True, sort=False)[value]
        .median()
        .rename(output_name)
        .reset_index()
    )


def run_primary(
    early: pd.DataFrame,
    catalog: pd.DataFrame,
    paths: Paths,
    repeats: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    family_patient = family_effects(early, "interaction_z_value", "family_interaction")
    groups = []
    for label in ("Overall",) + COHORTS:
        subset = family_patient if label == "Overall" else family_patient[family_patient["dataset_id"].eq(label)]
        stats_frame = summarize_effects(subset, ["cfc_family"], "family_interaction", repeats, seed + len(groups))
        stats_frame.insert(0, "analysis_group", label)
        groups.append(stats_frame)
    family_stats = apply_grouped_fdr(pd.concat(groups, ignore_index=True), ["analysis_group"])
    family_stats["robust_soz_increase"] = (
        family_stats["q_value"].lt(0.05)
        & family_stats["ci95_low"].gt(0)
        & family_stats["rank_biserial"].gt(0)
    )
    family_stats["robust_nsoz_increase"] = (
        family_stats["q_value"].lt(0.05)
        & family_stats["ci95_high"].lt(0)
        & family_stats["rank_biserial"].lt(0)
    )

    feature_groups = []
    for index, label in enumerate(("Overall",) + COHORTS):
        subset = early if label == "Overall" else early[early["dataset_id"].eq(label)]
        stats_frame = summarize_effects(subset, ["cfc_family", "method", "feature_id"], "interaction_z_value", repeats, seed + 100 + index)
        stats_frame.insert(0, "analysis_group", label)
        feature_groups.append(stats_frame)
    feature_stats = apply_grouped_fdr(pd.concat(feature_groups, ignore_index=True), ["analysis_group"])
    feature_stats = feature_stats.merge(catalog, on=["cfc_family", "method", "feature_id"], how="left", validate="many_to_one")
    feature_stats["robust_positive"] = feature_stats["q_value"].lt(0.05) & feature_stats["ci95_low"].gt(0) & feature_stats["rank_biserial"].gt(0)
    feature_stats["robust_negative"] = feature_stats["q_value"].lt(0.05) & feature_stats["ci95_high"].lt(0) & feature_stats["rank_biserial"].lt(0)

    family_patient.to_csv(paths.primary / "patient_level_family_early_interaction.csv", index=False, encoding="utf-8-sig")
    family_stats.to_csv(paths.primary / "family_primary_statistics.csv", index=False, encoding="utf-8-sig")
    feature_stats.to_csv(paths.primary / "feature_secondary_statistics.csv", index=False, encoding="utf-8-sig")
    return family_patient, family_stats, feature_stats


def run_trajectory(
    full_region: pd.DataFrame,
    full_spatial: pd.DataFrame,
    paths: Paths,
    repeats: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    region_family = (
        full_region.groupby(["dataset_id", "patient_id", "soz_label", "window_id", "cfc_family"], observed=True)["z_value"]
        .median()
        .rename("family_z")
        .reset_index()
    )
    spatial_family = family_effects(full_spatial, "spatial_z_value", "family_spatial_contrast")
    trajectory_stats = summarize_effects(
        spatial_family, ["window_id", "cfc_family"], "family_spatial_contrast", repeats, seed
    )
    trajectory_stats["window_order"] = trajectory_stats["window_id"].map({w: i for i, w in enumerate(WINDOWS)})

    pre = spatial_family[spatial_family["window_id"].eq(PRE_NEAR)][
        ["dataset_id", "patient_id", "cfc_family", "family_spatial_contrast"]
    ].rename(columns={"family_spatial_contrast": "near_pre_spatial"})
    post = spatial_family[spatial_family["window_id"].isin(WINDOWS[3:])].merge(
        pre, on=["dataset_id", "patient_id", "cfc_family"], how="inner", validate="many_to_one"
    )
    post["post_vs_near_pre_interaction"] = post["family_spatial_contrast"] - post["near_pre_spatial"]
    contrast_stats = summarize_effects(
        post,
        ["window_id", "cfc_family"],
        "post_vs_near_pre_interaction",
        repeats,
        seed + 100,
    )
    contrast_stats = apply_grouped_fdr(contrast_stats, [])
    contrast_stats["robust_positive"] = contrast_stats["q_value"].lt(0.05) & contrast_stats["ci95_low"].gt(0)
    contrast_stats["robust_negative"] = contrast_stats["q_value"].lt(0.05) & contrast_stats["ci95_high"].lt(0)

    region_family.to_csv(paths.trajectory / "patient_zone_family_six_window_values.csv", index=False, encoding="utf-8-sig")
    spatial_family.to_csv(paths.trajectory / "patient_family_spatial_trajectory.csv", index=False, encoding="utf-8-sig")
    trajectory_stats.to_csv(paths.trajectory / "family_spatial_trajectory_statistics.csv", index=False, encoding="utf-8-sig")
    post.to_csv(paths.trajectory / "patient_post_vs_near_pre_family_contrasts.csv", index=False, encoding="utf-8-sig")
    contrast_stats.to_csv(paths.trajectory / "fifteen_post_vs_near_pre_tests.csv", index=False, encoding="utf-8-sig")
    return region_family, spatial_family, contrast_stats


def safe_spearman(first: np.ndarray, second: np.ndarray) -> float:
    mask = np.isfinite(first) & np.isfinite(second)
    if mask.sum() < 3 or np.allclose(first[mask], first[mask][0]) or np.allclose(second[mask], second[mask][0]):
        return math.nan
    return float(stats.spearmanr(first[mask], second[mask]).statistic)


def map_metrics(first: pd.Series, second: pd.Series) -> dict[str, float]:
    joined = pd.concat([first.rename("first"), second.rename("second")], axis=1).dropna()
    if joined.empty:
        return {"n_features": 0, "spearman_rho": math.nan, "direction_agreement": math.nan, "median_absolute_difference": math.nan}
    return {
        "n_features": len(joined),
        "spearman_rho": safe_spearman(joined["first"].to_numpy(), joined["second"].to_numpy()),
        "direction_agreement": float(np.mean(np.sign(joined["first"]) == np.sign(joined["second"]))),
        "median_absolute_difference": float(np.median(np.abs(joined["first"] - joined["second"]))),
    }


def cohort_feature_maps(frame: pd.DataFrame, value: str, extra_keys: list[str] | None = None) -> pd.DataFrame:
    extra_keys = extra_keys or []
    return (
        frame.groupby(["dataset_id"] + extra_keys + ["cfc_family", "feature_id"], observed=True)[value]
        .median()
        .rename("effect")
        .reset_index()
    )


def bootstrap_loco(
    early: pd.DataFrame,
    heldout: str,
    feature_ids: list[str],
    repeats: int,
    rng: np.random.Generator,
) -> tuple[float, float]:
    matrices: dict[str, np.ndarray] = {}
    for cohort in COHORTS:
        table = early[early["dataset_id"].eq(cohort)].pivot(index="patient_id", columns="feature_id", values="interaction_z_value")
        matrices[cohort] = table.reindex(columns=feature_ids).to_numpy(float)
    rhos = []
    discovery = [cohort for cohort in COHORTS if cohort != heldout]
    for _ in range(repeats):
        maps = {}
        for cohort, matrix in matrices.items():
            sampled = matrix[rng.integers(0, len(matrix), len(matrix))]
            maps[cohort] = np.nanmedian(sampled, axis=0)
        discovery_map = np.nanmean(np.vstack([maps[c] for c in discovery]), axis=0)
        rhos.append(safe_spearman(discovery_map, maps[heldout]))
    good = np.asarray(rhos, dtype=float)
    good = good[np.isfinite(good)]
    if len(good) == 0:
        return math.nan, math.nan
    return tuple(np.quantile(good, [0.025, 0.975]))


def run_cross_cohort(
    early: pd.DataFrame,
    full_spatial: pd.DataFrame,
    catalog: pd.DataFrame,
    paths: Paths,
    repeats: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    early_maps = cohort_feature_maps(early, "interaction_z_value")
    catalog_family = catalog.set_index("feature_id")["cfc_family"]
    map_series = {
        cohort: group.set_index("feature_id")["effect"].reindex(catalog["feature_id"])
        for cohort, group in early_maps.groupby("dataset_id", observed=True)
    }
    rows = []
    scopes = [("Overall", list(catalog["feature_id"]))]
    scopes += [(family, list(catalog.loc[catalog["cfc_family"].eq(family), "feature_id"])) for family in FAMILIES]
    for i, first in enumerate(COHORTS):
        for second in COHORTS[i + 1 :]:
            for scope, feature_ids in scopes:
                metrics = map_metrics(map_series[first].reindex(feature_ids), map_series[second].reindex(feature_ids))
                rows.append({"comparison": f"{first} vs {second}", "scope": scope, **metrics})
    pairwise = pd.DataFrame(rows)

    loco_rows = []
    rng = np.random.default_rng(seed)
    for heldout in COHORTS:
        discovery = [cohort for cohort in COHORTS if cohort != heldout]
        discovery_map = pd.concat([map_series[cohort] for cohort in discovery], axis=1).mean(axis=1)
        validation_map = map_series[heldout]
        for scope, feature_ids in scopes:
            metrics = map_metrics(discovery_map.reindex(feature_ids), validation_map.reindex(feature_ids))
            low, high = bootstrap_loco(early, heldout, feature_ids, repeats, rng)
            loco_rows.append(
                {
                    "heldout_cohort": heldout,
                    "discovery_cohorts": "+".join(discovery),
                    "scope": scope,
                    "rho_ci95_low_both_sides_bootstrap": low,
                    "rho_ci95_high_both_sides_bootstrap": high,
                    **metrics,
                }
            )
    loco = pd.DataFrame(loco_rows)

    trajectory_maps = cohort_feature_maps(full_spatial, "spatial_z_value", ["window_id"])
    trajectory_rows = []
    for window in WINDOWS:
        window_data = trajectory_maps[trajectory_maps["window_id"].eq(window)]
        series = {
            cohort: group.set_index("feature_id")["effect"].reindex(catalog["feature_id"])
            for cohort, group in window_data.groupby("dataset_id", observed=True)
        }
        for heldout in COHORTS:
            discovery = [cohort for cohort in COHORTS if cohort != heldout]
            discovery_map = pd.concat([series[c] for c in discovery], axis=1).mean(axis=1)
            for scope, feature_ids in scopes:
                metrics = map_metrics(discovery_map.reindex(feature_ids), series[heldout].reindex(feature_ids))
                trajectory_rows.append({"window_id": window, "heldout_cohort": heldout, "scope": scope, **metrics})
    trajectory_loco = pd.DataFrame(trajectory_rows)

    early_maps.to_csv(paths.cross / "cohort_early_interaction_maps.csv", index=False, encoding="utf-8-sig")
    pairwise.to_csv(paths.cross / "pairwise_early_map_correlations.csv", index=False, encoding="utf-8-sig")
    loco.to_csv(paths.cross / "dynamic_loco_early_interaction_validation.csv", index=False, encoding="utf-8-sig")
    trajectory_loco.to_csv(paths.cross / "dynamic_loco_six_window_spatial_maps.csv", index=False, encoding="utf-8-sig")
    return pairwise, loco


def derive_early_from_spatial(spatial: pd.DataFrame, value: str) -> pd.DataFrame:
    keys = ["dataset_id", "patient_id", "cfc_family", "method", "feature_id"]
    pre = spatial[spatial["window_id"].eq(PRE_NEAR)][keys + [value]].rename(columns={value: "pre"})
    post = spatial[spatial["window_id"].eq(POST_EARLY)][keys + [value]].rename(columns={value: "post"})
    paired = pre.merge(post, on=keys, how="inner", validate="one_to_one")
    paired["effect"] = paired["post"] - paired["pre"]
    return paired


def run_sensitivity(
    early: pd.DataFrame,
    mean_spatial: pd.DataFrame,
    confirmed_spatial: pd.DataFrame,
    catalog: pd.DataFrame,
    paths: Paths,
    repeats: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    source_rows = []
    for index, column in enumerate(VALUE_COLUMNS):
        effect_column = f"interaction_{column}"
        family = family_effects(early, effect_column, "effect")
        summary = summarize_effects(family, ["cfc_family"], "effect", repeats, seed + index)
        summary.insert(0, "source_metric", column)
        source_rows.append(summary)
    source_stats = apply_grouped_fdr(pd.concat(source_rows, ignore_index=True), ["source_metric"])

    primary = early[["dataset_id", "patient_id", "cfc_family", "method", "feature_id", "interaction_z_value"]].rename(columns={"interaction_z_value": "effect"})
    mean_early = derive_early_from_spatial(mean_spatial, "spatial_z_value")
    confirmed_early = derive_early_from_spatial(confirmed_spatial, "spatial_z_value")
    catalog_index = catalog.set_index("feature_id")
    # Band-based measures store the frozen 150--200 Hz definition in the band
    # label rather than in the optional numeric center-frequency columns.
    high_frequency = catalog_index[["band_1", "band_2"]].eq("fast_ripple_low").any(axis=1)
    low_feature_ids = set(high_frequency.index[~high_frequency])
    analyses = {
        "primary_median_all_reliable_onset_records": primary,
        "mean_hierarchy_full_trajectory_records": mean_early,
        "confirmed_duration_ge30_only": confirmed_early,
        "exclude_150_200_hz_features": primary[primary["feature_id"].isin(low_feature_ids)],
    }
    sensitivity_rows = []
    maps = {}
    for index, (name, data) in enumerate(analyses.items()):
        family = family_effects(data, "effect", "effect")
        summary = summarize_effects(family, ["cfc_family"], "effect", repeats, seed + 100 + index)
        summary.insert(0, "analysis", name)
        sensitivity_rows.append(summary)
        maps[name] = data.groupby("feature_id", observed=True)["effect"].median()
    sensitivity_stats = pd.concat(sensitivity_rows, ignore_index=True)
    sensitivity_stats["q_value_within_analysis"] = np.nan
    for name, indices in sensitivity_stats.groupby("analysis").groups.items():
        sensitivity_stats.loc[indices, "q_value_within_analysis"] = bh_fdr(sensitivity_stats.loc[indices, "p_value"])

    agreement_rows = []
    reference = maps["primary_median_all_reliable_onset_records"]
    for name, effect_map in maps.items():
        agreement_rows.append({"analysis": name, **map_metrics(reference, effect_map)})
    agreement = pd.DataFrame(agreement_rows)

    source_stats.to_csv(paths.sensitivity / "surrogate_source_component_family_statistics.csv", index=False, encoding="utf-8-sig")
    sensitivity_stats.to_csv(paths.sensitivity / "family_sensitivity_statistics.csv", index=False, encoding="utf-8-sig")
    agreement.to_csv(paths.sensitivity / "sensitivity_map_agreement_with_primary.csv", index=False, encoding="utf-8-sig")
    return source_stats, sensitivity_stats


def save_figure(fig: plt.Figure, base: Path) -> None:
    fig.savefig(base.with_suffix(".png"), dpi=300, bbox_inches="tight")
    fig.savefig(base.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)


def make_figures(
    family_stats: pd.DataFrame,
    feature_stats: pd.DataFrame,
    region_family: pd.DataFrame,
    pairwise: pd.DataFrame,
    loco: pd.DataFrame,
    source_stats: pd.DataFrame,
    paths: Paths,
) -> None:
    plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
    overall = family_stats[family_stats["analysis_group"].eq("Overall")].set_index("cfc_family").reindex(FAMILIES)
    fig, ax = plt.subplots(figsize=(7.4, 4.5))
    x = np.arange(len(FAMILIES))
    values = overall["median_effect"].to_numpy(float)
    low = values - overall["ci95_low"].to_numpy(float)
    high = overall["ci95_high"].to_numpy(float) - values
    colors = ["#D95F59" if value < 0 else "#2A9D8F" for value in values]
    ax.errorbar(values, x, xerr=np.vstack([low, high]), fmt="none", ecolor="#24364B", capsize=4, lw=1.5)
    ax.scatter(values, x, c=colors, s=55, zorder=3)
    ax.axvline(0, color="#6B7280", ls="--", lw=1)
    ax.set_yticks(x, [family.replace("_", " ") for family in FAMILIES])
    ax.set_xlabel("Median patient-level zone-by-time interaction (Z)")
    ax.set_title("Early peri-onset interaction by CFC family")
    ax.invert_yaxis()
    fig.tight_layout()
    save_figure(fig, paths.report / "Fig3A_五类CFC早期交互森林图")

    ordered = feature_stats[feature_stats["analysis_group"].isin(["Overall", *COHORTS])].copy()
    group_order = ["Overall", *COHORTS]
    feature_order = list(
        ordered[ordered["analysis_group"].eq("Overall")]
        .sort_values(["cfc_family", "feature_id"])["feature_id"]
    )
    matrix = ordered.pivot(index="analysis_group", columns="feature_id", values="median_effect").reindex(index=group_order, columns=feature_order)
    limit = float(np.nanpercentile(np.abs(matrix.to_numpy()), 98)) or 1.0
    fig, ax = plt.subplots(figsize=(14, 3.2))
    image = ax.imshow(matrix, aspect="auto", cmap="RdBu_r", vmin=-limit, vmax=limit)
    ax.set_yticks(np.arange(len(group_order)), group_order)
    ax.set_xticks([])
    ax.set_title("Early SOZ-specific interaction map across cohorts")
    fig.colorbar(image, ax=ax, label="Median interaction Z", fraction=0.025, pad=0.02)
    fig.tight_layout()
    save_figure(fig, paths.report / "Fig3B_312特征早期交互图谱")

    summary = (
        region_family.groupby(["soz_label", "window_id", "cfc_family"], observed=True)["family_z"]
        .median()
        .reset_index()
    )
    fig, axes = plt.subplots(1, 5, figsize=(16, 3.6), sharey=True)
    for ax, family in zip(axes, FAMILIES):
        subset = summary[summary["cfc_family"].eq(family)]
        for zone, color in [("SOZ", "#E76F51"), ("NSOZ", "#277DA1")]:
            values = subset[subset["soz_label"].eq(zone)].set_index("window_id")["family_z"].reindex(WINDOWS)
            ax.plot(np.arange(6), values, marker="o", lw=2, color=color, label=zone)
        ax.axvline(2.5, color="#6B7280", ls="--", lw=1)
        ax.set_title(family.replace("_", " "))
        ax.set_xticks(np.arange(6), ["-30", "-20", "-10", "0", "10", "20"], rotation=45)
        ax.set_xlabel("Window start (s)")
    axes[0].set_ylabel("Median standardized CFC")
    axes[-1].legend(frameon=False)
    fig.suptitle("Six-window onset-locked trajectories", y=1.02)
    fig.tight_layout()
    save_figure(fig, paths.report / "Fig3C_五类CFC六时间窗轨迹")

    overall_pairs = pairwise[pairwise["scope"].eq("Overall")]
    matrix = pd.DataFrame(np.eye(3), index=COHORTS, columns=COHORTS)
    for _, row in overall_pairs.iterrows():
        first, second = row["comparison"].split(" vs ")
        matrix.loc[first, second] = row["spearman_rho"]
        matrix.loc[second, first] = row["spearman_rho"]
    fig, ax = plt.subplots(figsize=(5.4, 4.5))
    image = ax.imshow(matrix, vmin=-1, vmax=1, cmap="RdBu_r")
    ax.set_xticks(np.arange(3), COHORTS, rotation=25, ha="right")
    ax.set_yticks(np.arange(3), COHORTS)
    for i in range(3):
        for j in range(3):
            ax.text(j, i, f"{matrix.iloc[i, j]:.2f}", ha="center", va="center")
    ax.set_title("Cross-cohort early-map agreement")
    fig.colorbar(image, ax=ax, label="Spearman rho")
    fig.tight_layout()
    save_figure(fig, paths.report / "Fig3D_三队列早期图谱相关")

    source = source_stats.pivot(index="cfc_family", columns="source_metric", values="median_effect").reindex(FAMILIES)
    fig, ax = plt.subplots(figsize=(8.2, 4.5))
    width = 0.18
    for index, metric in enumerate(VALUE_COLUMNS):
        ax.bar(np.arange(5) + (index - 1.5) * width, source[metric], width, label=metric.replace("_", " "))
    ax.axhline(0, color="#6B7280", lw=1)
    ax.set_xticks(np.arange(5), [family.replace("_", " ") for family in FAMILIES])
    ax.set_ylabel("Median family interaction")
    ax.set_title("Observed and surrogate-source decomposition")
    ax.legend(frameon=False, ncol=2)
    fig.tight_layout()
    save_figure(fig, paths.report / "Fig3E_标准化值来源分解")

    overall_loco = loco[loco["scope"].eq("Overall")]
    fig, ax = plt.subplots(figsize=(7.2, 4.2))
    x = np.arange(len(overall_loco))
    values = overall_loco["spearman_rho"].to_numpy(float)
    low = values - overall_loco["rho_ci95_low_both_sides_bootstrap"].to_numpy(float)
    high = overall_loco["rho_ci95_high_both_sides_bootstrap"].to_numpy(float) - values
    ax.bar(x, values, color=["#4C78A8", "#F58518", "#54A24B"])
    ax.errorbar(x, values, yerr=np.vstack([low, high]), fmt="none", ecolor="#263238", capsize=4)
    ax.axhline(0, color="#6B7280", lw=1)
    ax.set_xticks(x, overall_loco["heldout_cohort"], rotation=15)
    ax.set_ylabel("Spearman rho")
    ax.set_title("Two-cohort discovery to held-out-cohort validation")
    fig.tight_layout()
    save_figure(fig, paths.report / "Fig3F_动态LOCO验证")


def fmt(value: object, digits: int = 3) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)
    if not np.isfinite(number):
        return "NA"
    if 0 < abs(number) < 0.001:
        return f"{number:.2e}"
    return f"{number:.{digits}f}"


def markdown_table(frame: pd.DataFrame, columns: list[str]) -> str:
    lines = ["| " + " | ".join(columns) + " |", "|" + "|".join(["---"] * len(columns)) + "|"]
    for _, row in frame[columns].iterrows():
        lines.append("| " + " | ".join(fmt(row[column]) for column in columns) + " |")
    return "\n".join(lines)


def write_report(
    qc: pd.DataFrame,
    family_stats: pd.DataFrame,
    feature_stats: pd.DataFrame,
    contrast_stats: pd.DataFrame,
    pairwise: pd.DataFrame,
    loco: pd.DataFrame,
    source_stats: pd.DataFrame,
    sensitivity_stats: pd.DataFrame,
    paths: Paths,
) -> None:
    overall = family_stats[family_stats["analysis_group"].eq("Overall")].copy()
    feature_overall = feature_stats[feature_stats["analysis_group"].eq("Overall")]
    counts = feature_overall.groupby("cfc_family", observed=True).agg(
        robust_positive=("robust_positive", "sum"), robust_negative=("robust_negative", "sum")
    ).reset_index()
    report = f"""# 实验三详细结果报告：发作起始前后区域特异性 CFC 变化

生成时间：{datetime.now().isoformat(timespec='seconds')}

## 1. 本轮分析是否完整

- 原始标准化结果：269/269 条记录完成，失败 0 条。
- 分析患者：{len(qc)} 例；Lanzhou 32 例、ds003029 14 例、ds004100 35 例。
- 早期主分析排除已知在 10 s 前结束的 6 条记录；结束时间未知者按 onset-locked 记录保留，不称为“全程发作期”。
- 六窗口完整轨迹排除所有已知不足 30 s 的记录，并另做仅使用确认持续至少 30 s 记录的敏感性分析。
- 统计单位始终为患者。层级汇总为：发作记录 -> 接触点 -> SOZ/NSOZ 区域 -> 患者。

## 2. 主要问题与统计定义

主问题是 SOZ 相对 NSOZ 的 CFC 空间差异是否在发作起始后 0--10 s 相比起始前 -10--0 s 发生改变。每个患者、每个特征计算：

`I = (SOZ - NSOZ)_[0,10] - (SOZ - NSOZ)_[-10,0]`。

正值表示发作起始后 CFC 更偏向 SOZ；负值表示更偏向 NSOZ。五个家族是预先冻结的主检验，家族值为该患者在家族内全部特征交互效应的中位数；312 个特征是次级频率定位分析。

## 3. 五个 CFC 家族的早期主结果

{markdown_table(overall, ['cfc_family','n_patients','median_effect','ci95_low','ci95_high','p_value','q_value','rank_biserial','positive_patient_proportion'])}

解释规则：`q < 0.05` 控制五个家族的多重比较；95% bootstrap CI 不跨 0 且秩二列效应量方向一致时，才称为稳健方向性结果。不能只根据原始 p 值或正向患者比例下结论。

## 4. 312 个频率特征图谱

{markdown_table(counts, ['cfc_family','robust_positive','robust_negative'])}

这些数量用于定位效应来源，不承担整篇论文的主要结论。详细频率、方法、效应量和 FDR 结果见 `05_主要早期交互/feature_secondary_statistics.csv`。

## 5. 六窗口动态与 15 个预设比较

完整轨迹使用六个不重叠 10 s 窗。正式比较为五个家族乘以三个起始后窗口，共 15 个检验，统一 BH-FDR 校正：

{markdown_table(contrast_stats, ['window_id','cfc_family','n_patients','median_effect','ci95_low','ci95_high','p_value','q_value','rank_biserial'])}

轨迹只能解释为“发作起始锁定的时空演变”，本实验没有募集时间或电极距离信息，因此不使用“传播机制”措辞。

## 6. 跨队列可迁移性

三队列两两早期交互图谱相关：

{markdown_table(pairwise[pairwise['scope'].eq('Overall')], ['comparison','n_features','spearman_rho','direction_agreement','median_absolute_difference'])}

两队列发现、一个队列留出验证：

{markdown_table(loco[loco['scope'].eq('Overall')], ['heldout_cohort','discovery_cohorts','n_features','spearman_rho','rho_ci95_low_both_sides_bootstrap','rho_ci95_high_both_sides_bootstrap','direction_agreement'])}

这里应称为“跨数据集内部-外部验证”或“跨队列可迁移性验证”，不称为从未查看过的完全独立外部验证。bootstrap 同时重采样发现侧和验证侧患者。

## 7. 标准化来源与敏感性

标准化值 `Z = (observed - surrogate mean) / surrogate SD`。来源分解如下：

{markdown_table(source_stats, ['source_metric','cfc_family','median_effect','ci95_low','ci95_high','p_value','q_value'])}

主要敏感性包括均值层级、仅确认持续至少 30 s、以及排除 150--200 Hz 特征：

{markdown_table(sensitivity_stats, ['analysis','cfc_family','n_patients','median_effect','ci95_low','ci95_high','p_value','q_value_within_analysis'])}

## 8. 当前不能过度解释的内容

本轮已完成最新版方案的主要早期交互、完整轨迹、跨队列动态验证、surrogate 来源分解和可直接由标准化结果完成的敏感性分析。功率、尖波去除、波形不对称、谐波诊断及保护窗 `[-12,-2]` 对 `[2,12]` 需要重新读取原始信号，不能从现有 CFC 表反推；它们应作为下一轮伪 CFC 诊断单独运行并归档，不能在当前报告中伪装成已完成。

## 9. 文件导航

- `04_患者级六窗数据`：患者级区域值、空间差值、早期交互和资格/QC。
- `05_主要早期交互`：五家族主检验与 312 特征次级图谱。
- `06_完整时间轨迹`：六窗轨迹和 15 个预设比较。
- `07_跨队列动态验证`：两两比较、动态 LOCO 和 bootstrap 区间。
- `08_来源诊断与敏感性`：observed/surrogate 分解及直接可做的敏感性分析。
- `09_正式图表与报告`：正式图表和本报告。
- `10_分析代码与运行记录`：程序、参数、版本和哈希。
"""
    (paths.report / "实验三_详细结果报告.md").write_text(report, encoding="utf-8")


def write_method_freeze(paths: Paths) -> None:
    text = """# 实验三统计口径冻结说明

本文件在查看正式统计结果前写入并随结果归档。

1. 统计单位为患者，不把接触点或发作当作独立样本。
2. 主效应：`[(SOZ-NSOZ) 0--10 s] - [(SOZ-NSOZ) -10--0 s]`。
3. 层级汇总：先在接触点内跨发作取中位数，再在区域内跨接触点取中位数。
4. 家族级主检验：患者内对该 CFC 家族全部特征取中位数，五个家族 BH-FDR。
5. 312 特征仅作为次级频率图谱，单独对 312 个检验 BH-FDR。
6. 早期主分析排除已知不足 10 s 的发作；结束未知者保留并使用 post-onset 措辞。
7. 六窗主轨迹排除已知不足 30 s 的发作；确认持续至少 30 s 为敏感性分析。
8. 跨队列验证采用两个队列中心等权发现图谱对一个留出队列，并同时 bootstrap 发现侧和验证侧患者。
9. 不把本实验称为完全未见外部验证，也不把 SOZ/NSOZ 六窗差异称为传播机制。
"""
    (paths.code / "统计口径冻结说明.md").write_text(text, encoding="utf-8")


def main() -> None:
    args = parse_args()
    paths = make_paths(args.run_root)
    write_method_freeze(paths)
    shard_root = args.run_root / "03_六时间窗CFC标准化" / "shards"
    eligibility_path = args.run_root / "02_计算输入" / "window_state_eligibility.csv"
    eligibility = pd.read_csv(eligibility_path, dtype={"recording_id": str})
    if args.reuse_patient_tables:
        print("Reusing validated patient-level six-window tables...", flush=True)
        catalog = pd.read_csv(paths.patient / "feature_catalog.csv")
        early = pd.read_parquet(paths.patient / "patient_early_interaction_312_features.parquet")
        full_region = pd.read_parquet(paths.patient / "patient_zone_six_windows.parquet")
        full_spatial = pd.read_parquet(paths.patient / "patient_spatial_contrast_six_windows.parquet")
        mean_spatial = pd.read_parquet(paths.patient / "sensitivity_mean_patient_spatial_contrast.parquet")
        confirmed_spatial = pd.read_parquet(paths.patient / "sensitivity_confirmed_ge30_spatial_contrast.parquet")
    else:
        print("Building patient-level six-window tables...", flush=True)
        catalog, early, full_region, full_spatial, mean_spatial, confirmed_spatial = process_patients(
            shard_root, eligibility, paths
        )
    qc = pd.read_csv(paths.patient / "patient_processing_qc.csv")
    print("Running primary early interaction...", flush=True)
    family_patient, family_stats, feature_stats = run_primary(
        early, catalog, paths, args.bootstrap_repeats, args.seed
    )
    print("Running six-window trajectory analysis...", flush=True)
    region_family, spatial_family, contrast_stats = run_trajectory(
        full_region, full_spatial, paths, args.bootstrap_repeats, args.seed + 1000
    )
    print("Running cross-cohort dynamic validation...", flush=True)
    pairwise, loco = run_cross_cohort(
        early, full_spatial, catalog, paths, args.loco_bootstrap_repeats, args.seed + 2000
    )
    print("Running source and sensitivity analyses...", flush=True)
    source_stats, sensitivity_stats = run_sensitivity(
        early,
        mean_spatial,
        confirmed_spatial,
        catalog,
        paths,
        args.bootstrap_repeats,
        args.seed + 3000,
    )
    print("Rendering figures and report...", flush=True)
    make_figures(
        family_stats,
        feature_stats,
        region_family,
        pairwise,
        loco,
        source_stats,
        paths,
    )
    write_report(
        qc,
        family_stats,
        feature_stats,
        contrast_stats,
        pairwise,
        loco,
        source_stats,
        sensitivity_stats,
        paths,
    )
    metadata = {
        "status": "complete",
        "completed_at": datetime.now().isoformat(timespec="seconds"),
        "run_root": str(args.run_root),
        "patients": int(len(qc)),
        "records_total": int(qc["records_total"].sum()),
        "records_early_primary": int(qc["records_early_primary"].sum()),
        "records_full_trajectory": int(qc["records_full_trajectory"].sum()),
        "records_confirmed_ge30": int(qc["records_confirmed_ge30"].sum()),
        "features": int(len(catalog)),
        "bootstrap_repeats": args.bootstrap_repeats,
        "loco_bootstrap_repeats": args.loco_bootstrap_repeats,
        "seed": args.seed,
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "scipy": scipy.__version__,
        "eligibility_sha256": sha256_file(eligibility_path),
        "script_sha256": sha256_file(Path(__file__)),
    }
    (paths.code / "analysis_run_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
