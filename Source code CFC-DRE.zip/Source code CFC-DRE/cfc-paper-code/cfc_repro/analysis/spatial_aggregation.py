"""Post-onset 0-30 s contact and paired patient regional summaries.

Scientific definitions follow the frozen author analysis; see REPRODUCE.md.
"""
from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats


FEATURE_COLUMNS = [
    "cfc_family",
    "method",
    "feature_id",
    "frequency_1",
    "frequency_2",
    "frequency_3",
    "band_1",
    "band_2",
    "ratio_label",
]

READ_COLUMNS = [
    "dataset_id",
    "patient_id",
    "recording_id",
    "channel_name",
    "channel_index_1based",
    "soz_label",
    "state",
    "window_start_sec",
    "window_end_sec",
    "cfc_family",
    "method",
    "feature_id",
    "frequency_1",
    "frequency_2",
    "frequency_3",
    "band_1",
    "band_2",
    "ratio_label",
    "z_value",
    "finite_pass",
    "zero_surrogate_variance",
]

METHOD_ORDER = [
    ("PAC", "tort_mi"),
    ("PAC", "mvl"),
    ("PAC", "glm_pac"),
    ("PPC", "phase_locking_value"),
    ("AAC", "pearson"),
    ("AAC", "spearman"),
    ("Bicoherence", "squared_bicoherence"),
    ("CFC_coherence", "coherence_peak"),
]

METHOD_LABELS = {
    ("PAC", "tort_mi"): "PAC: Tort MI",
    ("PAC", "mvl"): "PAC: MVL",
    ("PAC", "glm_pac"): "PAC: GLM-PAC",
    ("PPC", "phase_locking_value"): "PPC",
    ("AAC", "pearson"): "AAC: Pearson",
    ("AAC", "spearman"): "AAC: Spearman",
    ("Bicoherence", "squared_bicoherence"): "Bicoherence",
    ("CFC_coherence", "coherence_peak"): "CFC coherence",
}

BAND_ORDER = [
    "delta",
    "theta",
    "alpha",
    "beta",
    "low_gamma",
    "high_gamma",
    "ripple",
    "fast_ripple",
]


@dataclass
class AnalysisPaths:
    input_root: Path
    output_root: Path

    @property
    def tables(self) -> Path:
        return self.output_root / "tables"

    @property
    def figures(self) -> Path:
        return self.output_root / "figures"

    @property
    def logs(self) -> Path:
        return self.output_root / "logs"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Aggregate spatial contact features")
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260911)
    return parser.parse_args()


def prepare_output(paths: AnalysisPaths) -> None:
    for path in [paths.output_root, paths.tables, paths.figures, paths.logs]:
        path.mkdir(parents=True, exist_ok=True)


def read_ictal_shard(path: Path) -> pd.DataFrame:
    frame = pd.read_parquet(
        path,
        columns=READ_COLUMNS,
        filters=[("state", "==", "ictal")],
    )
    frame = frame[
        frame["soz_label"].isin(["SOZ", "NSOZ"])
        & frame["finite_pass"].eq(1)
        & frame["zero_surrogate_variance"].eq(0)
        & np.isfinite(frame["z_value"])
    ].copy()
    if frame.empty:
        return frame
    valid_window = np.isclose(frame["window_start_sec"], 0.0) & np.isclose(
        frame["window_end_sec"], 30.0
    )
    if not bool(valid_window.all()):
        bad = frame.loc[~valid_window, ["window_start_sec", "window_end_sec"]]
        raise ValueError(f"Unexpected ictal window in {path}: {bad.drop_duplicates().to_dict('records')}")
    frame["channel_key"] = (
        frame["channel_index_1based"].astype(str)
        + "|"
        + frame["channel_name"].fillna("").astype(str)
    )
    return frame


def feature_catalog_from_frame(frame: pd.DataFrame) -> pd.DataFrame:
    return frame[FEATURE_COLUMNS].drop_duplicates(subset=["feature_id"]).copy()


def summarize_patient_frames(frames: list[pd.DataFrame]) -> tuple[pd.DataFrame, pd.DataFrame]:
    data = pd.concat(frames, ignore_index=True)
    contact_keys = [
        "dataset_id",
        "patient_id",
        "channel_key",
        "soz_label",
        "cfc_family",
        "method",
        "feature_id",
    ]
    contact = (
        data.groupby(contact_keys, observed=True, sort=False)
        .agg(
            z_contact_median=("z_value", "median"),
            z_contact_mean=("z_value", "mean"),
            n_seizures=("recording_id", "nunique"),
        )
        .reset_index()
    )

    region_keys = ["dataset_id", "patient_id", "cfc_family", "method", "feature_id", "soz_label"]
    region = (
        contact.groupby(region_keys, observed=True, sort=False)
        .agg(
            z_region_median=("z_contact_median", "median"),
            z_region_mean=("z_contact_mean", "mean"),
            n_channels=("channel_key", "nunique"),
        )
        .reset_index()
    )

    index_keys = ["dataset_id", "patient_id", "cfc_family", "method", "feature_id"]
    soz = region[region["soz_label"].eq("SOZ")].drop(columns="soz_label")
    nsoz = region[region["soz_label"].eq("NSOZ")].drop(columns="soz_label")
    patient = soz.merge(nsoz, on=index_keys, how="inner", suffixes=("_soz", "_nsoz"))
    patient["diff_median"] = patient["z_region_median_soz"] - patient["z_region_median_nsoz"]
    patient["diff_mean"] = patient["z_region_mean_soz"] - patient["z_region_mean_nsoz"]
    return contact, patient


def collect_patient_summaries(
    shard_root: Path,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    files = sorted(shard_root.rglob("*.parquet"))
    if not files:
        raise FileNotFoundError(f"No parquet shards found under {shard_root}")

    patient_dirs: dict[tuple[str, str], list[Path]] = {}
    for path in files:
        dataset_id = path.relative_to(shard_root).parts[0]
        patient_id = path.parent.name
        patient_dirs.setdefault((dataset_id, patient_id), []).append(path)

    all_contacts: list[pd.DataFrame] = []
    all_patients: list[pd.DataFrame] = []
    strict_patients: list[pd.DataFrame] = []
    qc_rows: list[dict[str, object]] = []
    feature_catalog: pd.DataFrame | None = None

    total_patients = len(patient_dirs)
    for patient_number, ((dataset_id, patient_id), patient_files) in enumerate(
        sorted(patient_dirs.items()), start=1
    ):
        primary_frames: list[pd.DataFrame] = []
        strict_frames: list[pd.DataFrame] = []
        for path in patient_files:
            frame = read_ictal_shard(path)
            if frame.empty:
                qc_rows.append(
                    {
                        "dataset_id": dataset_id,
                        "patient_id": patient_id,
                        "recording_id": path.stem,
                        "n_soz_channels": 0,
                        "n_nsoz_channels": 0,
                        "primary_included": 0,
                        "minimum_3_included": 0,
                    }
                )
                continue
            if feature_catalog is None:
                feature_catalog = feature_catalog_from_frame(frame)
            channel_rows = frame[["channel_key", "soz_label"]].drop_duplicates()
            counts = channel_rows.groupby("soz_label")["channel_key"].nunique()
            n_soz = int(counts.get("SOZ", 0))
            n_nsoz = int(counts.get("NSOZ", 0))
            primary_ok = n_soz >= 1 and n_nsoz >= 1
            strict_ok = n_soz >= 3 and n_nsoz >= 3
            qc_rows.append(
                {
                    "dataset_id": dataset_id,
                    "patient_id": patient_id,
                    "recording_id": str(frame["recording_id"].iloc[0]),
                    "n_soz_channels": n_soz,
                    "n_nsoz_channels": n_nsoz,
                    "primary_included": int(primary_ok),
                    "minimum_3_included": int(strict_ok),
                }
            )
            if primary_ok:
                primary_frames.append(frame)
            if strict_ok:
                strict_frames.append(frame)

        if primary_frames:
            contact, patient = summarize_patient_frames(primary_frames)
            all_contacts.append(contact)
            all_patients.append(patient)
        if strict_frames:
            _, patient_strict = summarize_patient_frames(strict_frames)
            strict_patients.append(patient_strict)
        print(
            f"[{patient_number:02d}/{total_patients}] {dataset_id}/{patient_id}: "
            f"{len(primary_frames)} primary records, {len(strict_frames)} minimum-3 records",
            flush=True,
        )

    if feature_catalog is None:
        raise RuntimeError("No usable ictal CFC rows were found.")
    return (
        pd.concat(all_contacts, ignore_index=True),
        pd.concat(all_patients, ignore_index=True),
        pd.concat(strict_patients, ignore_index=True) if strict_patients else pd.DataFrame(),
        pd.DataFrame(qc_rows),
    ), feature_catalog


def bh_fdr(p_values: Iterable[float]) -> np.ndarray:
    p = np.asarray(list(p_values), dtype=float)
    q = np.full(p.shape, np.nan, dtype=float)
    valid = np.isfinite(p)
    if not valid.any():
        return q
    values = p[valid]
    order = np.argsort(values)
    ranked = values[order]
    adjusted = ranked * len(ranked) / np.arange(1, len(ranked) + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    adjusted = np.clip(adjusted, 0.0, 1.0)
    restored = np.empty_like(adjusted)
    restored[order] = adjusted
    q[valid] = restored
    return q


def rank_biserial(differences: np.ndarray) -> float:
    values = differences[np.isfinite(differences) & ~np.isclose(differences, 0.0)]
    if len(values) == 0:
        return 0.0
    ranks = stats.rankdata(np.abs(values))
    positive = float(ranks[values > 0].sum())
    negative = float(ranks[values < 0].sum())
    return (positive - negative) / (positive + negative)


def bootstrap_median_ci(
    values: np.ndarray, repeats: int, rng: np.random.Generator
) -> tuple[float, float]:
    values = values[np.isfinite(values)]
    if len(values) == 0 or repeats <= 0:
        return math.nan, math.nan
    samples = rng.choice(values, size=(repeats, len(values)), replace=True)
    medians = np.median(samples, axis=1)
    return tuple(np.quantile(medians, [0.025, 0.975]).tolist())


def summarize_feature_statistics(
    patient: pd.DataFrame,
    difference_column: str,
    soz_column: str,
    nsoz_column: str,
    feature_catalog: pd.DataFrame,
    analysis_name: str,
    bootstrap_repeats: int,
    seed: int,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows: list[dict[str, object]] = []
    for (family, method, feature_id), group in patient.groupby(
        ["cfc_family", "method", "feature_id"], observed=True, sort=False
    ):
        differences = group[difference_column].to_numpy(dtype=float)
        differences = differences[np.isfinite(differences)]
        if len(differences) == 0:
            continue
        if np.allclose(differences, 0.0):
            statistic, p_value = 0.0, 1.0
        else:
            test = stats.wilcoxon(
                differences,
                alternative="two-sided",
                zero_method="wilcox",
                method="auto",
            )
            statistic, p_value = float(test.statistic), float(test.pvalue)
        ci_low, ci_high = bootstrap_median_ci(differences, bootstrap_repeats, rng)
        rows.append(
            {
                "analysis": analysis_name,
                "cfc_family": family,
                "method": method,
                "feature_id": feature_id,
                "n_patients": int(len(differences)),
                "soz_group_median": float(np.nanmedian(group[soz_column])),
                "nsoz_group_median": float(np.nanmedian(group[nsoz_column])),
                "median_difference": float(np.nanmedian(differences)),
                "mean_difference": float(np.nanmean(differences)),
                "ci95_low": ci_low,
                "ci95_high": ci_high,
                "wilcoxon_statistic": statistic,
                "p_value": p_value,
                "rank_biserial": rank_biserial(differences),
                "positive_patients": int(np.sum(differences > 0)),
                "negative_patients": int(np.sum(differences < 0)),
                "zero_patients": int(np.sum(np.isclose(differences, 0.0))),
                "positive_fraction": float(np.mean(differences > 0)),
            }
        )
    result = pd.DataFrame(rows)
    result["q_value_global"] = bh_fdr(result["p_value"])
    result["significant_fdr05"] = result["q_value_global"].lt(0.05)
    result["soz_advantage_fdr05"] = result["significant_fdr05"] & result[
        "median_difference"
    ].gt(0)
    result["nsoz_advantage_fdr05"] = result["significant_fdr05"] & result[
        "median_difference"
    ].lt(0)
    result["soz_advantage_fdr05_ci95"] = (
        result["soz_advantage_fdr05"] & result["ci95_low"].gt(0)
    )
    result["nsoz_advantage_fdr05_ci95"] = (
        result["nsoz_advantage_fdr05"] & result["ci95_high"].lt(0)
    )
    result = result.merge(feature_catalog, on=["cfc_family", "method", "feature_id"], how="left")
    return result.sort_values(["q_value_global", "p_value", "feature_id"]).reset_index(drop=True)


def method_summary(primary: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for family, method in METHOD_ORDER:
        group = primary[(primary["cfc_family"] == family) & (primary["method"] == method)]
        rows.append(
            {
                "cfc_family": family,
                "method": method,
                "method_label": METHOD_LABELS[(family, method)],
                "n_features": int(len(group)),
                "n_soz_advantage_fdr05": int(group["soz_advantage_fdr05"].sum()),
                "n_nsoz_advantage_fdr05": int(group["nsoz_advantage_fdr05"].sum()),
                "n_soz_advantage_fdr05_ci95": int(
                    group["soz_advantage_fdr05_ci95"].sum()
                ),
                "n_nsoz_advantage_fdr05_ci95": int(
                    group["nsoz_advantage_fdr05_ci95"].sum()
                ),
                "median_effect_across_features": float(group["median_difference"].median()),
                "largest_positive_effect": float(group["median_difference"].max()),
                "smallest_q_value": float(group["q_value_global"].min()),
            }
        )
    return pd.DataFrame(rows)


def feature_short_label(row: pd.Series) -> str:
    family = row["cfc_family"]
    if family in {"PAC", "AAC", "CFC_coherence"}:
        b1 = str(row.get("band_1", "")).replace("_", "-")
        b2 = str(row.get("band_2", "")).replace("_", "-")
        return f"{METHOD_LABELS[(family, row['method'])]} | {b1}/{b2}"
    if family == "PPC":
        return f"PPC | {row['frequency_1']:g}/{row['frequency_2']:g} Hz"
    return (
        f"Bicoherence | {row['frequency_1']:g}+{row['frequency_2']:g}"
        f"={row['frequency_3']:g} Hz"
    )


def save_method_summary_figure(summary: pd.DataFrame, output: Path) -> None:
    fig, ax = plt.subplots(figsize=(10.5, 5.4))
    y = np.arange(len(summary))
    positive = summary["n_soz_advantage_fdr05_ci95"].to_numpy()
    negative = summary["n_nsoz_advantage_fdr05_ci95"].to_numpy()
    ax.barh(y, positive, color="#2C7FB8", label="SOZ > NSOZ")
    ax.barh(y, -negative, color="#D95F5F", label="NSOZ > SOZ")
    ax.axvline(0, color="#243447", linewidth=1)
    ax.set_yticks(y, summary["method_label"])
    ax.invert_yaxis()
    ax.set_xlabel("Number of features meeting global FDR and bootstrap-CI criteria")
    ax.set_title("Ictal 0-30 s CFC: robust SOZ-NSOZ differences")
    ax.grid(axis="x", alpha=0.2)
    ax.legend(frameon=False, loc="lower right")
    fig.tight_layout()
    fig.savefig(output.with_suffix(".png"), dpi=300)
    fig.savefig(output.with_suffix(".pdf"))
    plt.close(fig)


def save_top_feature_figure(primary: pd.DataFrame, output: Path, limit: int = 20) -> None:
    selected = primary[primary["soz_advantage_fdr05_ci95"]].copy()
    if selected.empty:
        selected = primary[primary["median_difference"] > 0].nsmallest(limit, "q_value_global")
    else:
        selected = selected.sort_values(
            ["q_value_global", "median_difference"], ascending=[True, False]
        ).head(limit)
    selected = selected.sort_values("median_difference")
    labels = [feature_short_label(row) for _, row in selected.iterrows()]
    y = np.arange(len(selected))
    x = selected["median_difference"].to_numpy()
    low = selected["ci95_low"].to_numpy()
    high = selected["ci95_high"].to_numpy()
    xerr = np.vstack([np.maximum(0, x - low), np.maximum(0, high - x)])
    fig_height = max(5.5, 0.34 * len(selected) + 1.8)
    fig, ax = plt.subplots(figsize=(11.5, fig_height))
    ax.errorbar(
        x,
        y,
        xerr=xerr,
        fmt="o",
        color="#1F5A94",
        ecolor="#7AA6C2",
        capsize=3,
        markersize=5,
    )
    ax.axvline(0, color="#243447", linestyle="--", linewidth=1)
    ax.set_yticks(y, labels)
    ax.set_xlabel("Patient-level median difference (SOZ - NSOZ), surrogate Z")
    ax.set_title("Top ictal CFC features with SOZ advantage")
    ax.grid(axis="x", alpha=0.2)
    fig.tight_layout()
    fig.savefig(output.with_suffix(".png"), dpi=300)
    fig.savefig(output.with_suffix(".pdf"))
    plt.close(fig)


def ordered_categories(values: pd.Series) -> list[str]:
    observed = [str(v) for v in values.dropna().unique()]
    ordered = [band for band in BAND_ORDER if band in observed]
    return ordered + sorted(set(observed) - set(ordered))


def map_matrix(group: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, str, str]:
    family = str(group["cfc_family"].iloc[0])
    if family in {"PAC", "AAC", "CFC_coherence"}:
        x_values = ordered_categories(group["band_1"])
        y_values = ordered_categories(group["band_2"])
        matrix = group.pivot_table(
            index="band_2", columns="band_1", values="median_difference", aggfunc="first"
        ).reindex(index=y_values, columns=x_values)
        significance = group.pivot_table(
            index="band_2", columns="band_1", values="soz_advantage_fdr05_ci95", aggfunc="first"
        ).reindex(index=y_values, columns=x_values)
        return matrix, significance, "Band 1", "Band 2"
    matrix = group.pivot_table(
        index="frequency_2", columns="frequency_1", values="median_difference", aggfunc="first"
    ).sort_index(ascending=True).sort_index(axis=1, ascending=True)
    significance = group.pivot_table(
        index="frequency_2", columns="frequency_1", values="soz_advantage_fdr05_ci95", aggfunc="first"
    ).reindex(index=matrix.index, columns=matrix.columns)
    return matrix, significance, "Frequency 1 (Hz)", "Frequency 2 (Hz)"


def value_matrix(group: pd.DataFrame, value_column: str) -> tuple[pd.DataFrame, str, str]:
    family = str(group["cfc_family"].iloc[0])
    if family in {"PAC", "AAC", "CFC_coherence"}:
        x_values = ordered_categories(group["band_1"])
        y_values = ordered_categories(group["band_2"])
        matrix = group.pivot_table(
            index="band_2", columns="band_1", values=value_column, aggfunc="first"
        ).reindex(index=y_values, columns=x_values)
        return matrix, "Band 1", "Band 2"
    matrix = group.pivot_table(
        index="frequency_2", columns="frequency_1", values=value_column, aggfunc="first"
    ).sort_index(ascending=True).sort_index(axis=1, ascending=True)
    return matrix, "Frequency 1 (Hz)", "Frequency 2 (Hz)"


def format_map_axes(ax: plt.Axes, matrix: pd.DataFrame, xlabel: str, ylabel: str) -> None:
    ax.set_xlabel(xlabel, fontsize=9)
    ax.set_ylabel(ylabel, fontsize=9)
    ax.set_xticks(np.arange(len(matrix.columns)))
    ax.set_xticklabels(
        [str(x).replace("_", "-") for x in matrix.columns], rotation=45, ha="right", fontsize=7
    )
    ax.set_yticks(np.arange(len(matrix.index)))
    ax.set_yticklabels(
        [str(y).replace("_", "-") for y in matrix.index], fontsize=7
    )


def save_region_pair_maps(primary: pd.DataFrame, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    for family, method in METHOD_ORDER:
        group = primary[(primary["cfc_family"] == family) & (primary["method"] == method)]
        soz_matrix, xlabel, ylabel = value_matrix(group, "soz_group_median")
        nsoz_matrix, _, _ = value_matrix(group, "nsoz_group_median")
        difference_matrix, _, _ = value_matrix(group, "median_difference")
        significance_matrix, _, _ = value_matrix(group, "soz_advantage_fdr05_ci95")

        raw_values = np.concatenate(
            [soz_matrix.to_numpy(dtype=float).ravel(), nsoz_matrix.to_numpy(dtype=float).ravel()]
        )
        raw_values = raw_values[np.isfinite(raw_values)]
        raw_low, raw_high = np.quantile(raw_values, [0.02, 0.98])
        if np.isclose(raw_low, raw_high):
            raw_low, raw_high = float(raw_values.min()), float(raw_values.max() + 1e-6)
        difference_limit = np.nanquantile(np.abs(difference_matrix.to_numpy(dtype=float)), 0.98)
        difference_limit = max(float(difference_limit), 1e-6)

        fig, axes = plt.subplots(1, 3, figsize=(13.6, 4.5), constrained_layout=True)
        soz_image = axes[0].imshow(
            soz_matrix.to_numpy(dtype=float),
            origin="lower",
            aspect="auto",
            cmap="viridis",
            vmin=raw_low,
            vmax=raw_high,
        )
        axes[0].set_title("SOZ")
        axes[1].imshow(
            nsoz_matrix.to_numpy(dtype=float),
            origin="lower",
            aspect="auto",
            cmap="viridis",
            vmin=raw_low,
            vmax=raw_high,
        )
        axes[1].set_title("NSOZ")
        difference_image = axes[2].imshow(
            difference_matrix.to_numpy(dtype=float),
            origin="lower",
            aspect="auto",
            cmap="RdBu_r",
            vmin=-difference_limit,
            vmax=difference_limit,
        )
        axes[2].set_title("SOZ - NSOZ")
        sig = significance_matrix.fillna(False).to_numpy(dtype=bool)
        ys, xs = np.where(sig)
        axes[2].scatter(
            xs,
            ys,
            marker="o",
            s=15,
            facecolors="none",
            edgecolors="#111111",
            linewidths=0.7,
        )
        for ax, matrix in zip(axes, [soz_matrix, nsoz_matrix, difference_matrix]):
            format_map_axes(ax, matrix, xlabel, ylabel)
        raw_bar = fig.colorbar(soz_image, ax=axes[:2], shrink=0.78, pad=0.02)
        raw_bar.set_label("Patient-level regional median, surrogate Z")
        difference_bar = fig.colorbar(difference_image, ax=axes[2], shrink=0.78, pad=0.02)
        difference_bar.set_label("Median difference, surrogate Z")
        fig.suptitle(
            f"{METHOD_LABELS[(family, method)]}: ictal 0-30 s SOZ and NSOZ maps",
            fontsize=14,
            fontweight="bold",
        )
        safe_name = f"{family}_{method}".replace(" ", "_").lower()
        fig.savefig(output_dir / f"{safe_name}_region_maps.png", dpi=300)
        fig.savefig(output_dir / f"{safe_name}_region_maps.pdf")
        plt.close(fig)


def save_effect_maps(primary: pd.DataFrame, output: Path) -> None:
    finite_effects = primary["median_difference"].to_numpy(dtype=float)
    finite_effects = np.abs(finite_effects[np.isfinite(finite_effects)])
    color_limit = float(np.quantile(finite_effects, 0.98)) if len(finite_effects) else 1.0
    color_limit = max(color_limit, 1e-6)

    fig, axes = plt.subplots(2, 4, figsize=(17.5, 9.2), constrained_layout=True)
    image = None
    for ax, (family, method) in zip(axes.flat, METHOD_ORDER):
        group = primary[(primary["cfc_family"] == family) & (primary["method"] == method)]
        matrix, significance, xlabel, ylabel = map_matrix(group)
        image = ax.imshow(
            matrix.to_numpy(dtype=float),
            origin="lower",
            aspect="auto",
            cmap="RdBu_r",
            vmin=-color_limit,
            vmax=color_limit,
        )
        ax.set_title(METHOD_LABELS[(family, method)], fontsize=11, fontweight="bold")
        ax.set_xlabel(xlabel, fontsize=9)
        ax.set_ylabel(ylabel, fontsize=9)
        ax.set_xticks(np.arange(len(matrix.columns)))
        ax.set_xticklabels(
            [str(x).replace("_", "-") for x in matrix.columns], rotation=45, ha="right", fontsize=7
        )
        ax.set_yticks(np.arange(len(matrix.index)))
        ax.set_yticklabels(
            [str(y).replace("_", "-") for y in matrix.index], fontsize=7
        )
        sig = significance.fillna(False).to_numpy(dtype=bool)
        ys, xs = np.where(sig)
        ax.scatter(xs, ys, marker="o", s=11, facecolors="none", edgecolors="#111111", linewidths=0.6)
    if image is not None:
        cbar = fig.colorbar(image, ax=axes, shrink=0.76, pad=0.02)
        cbar.set_label("Patient-level median difference (SOZ - NSOZ), surrogate Z")
    fig.suptitle("Ictal 0-30 s SOZ-NSOZ CFC effect maps", fontsize=15, fontweight="bold")
    fig.savefig(output.with_suffix(".png"), dpi=300)
    fig.savefig(output.with_suffix(".pdf"))
    plt.close(fig)


def save_median_mean_consistency(
    primary: pd.DataFrame, mean_sensitivity: pd.DataFrame, output: Path
) -> float:
    merged = primary[["feature_id", "median_difference", "cfc_family"]].merge(
        mean_sensitivity[["feature_id", "mean_difference"]], on="feature_id", how="inner"
    )
    rho, _ = stats.spearmanr(merged["median_difference"], merged["mean_difference"])
    colors = {
        "PAC": "#2C7FB8",
        "PPC": "#41AB5D",
        "AAC": "#F28E2B",
        "Bicoherence": "#8C6BB1",
        "CFC_coherence": "#D95F5F",
    }
    fig, ax = plt.subplots(figsize=(7.2, 6.4))
    for family, group in merged.groupby("cfc_family"):
        ax.scatter(
            group["median_difference"],
            group["mean_difference"],
            s=24,
            alpha=0.75,
            label=family.replace("_", " "),
            color=colors.get(family, "#666666"),
        )
    limits = np.array(
        [
            min(merged["median_difference"].min(), merged["mean_difference"].min()),
            max(merged["median_difference"].max(), merged["mean_difference"].max()),
        ]
    )
    ax.plot(limits, limits, linestyle="--", color="#657786", linewidth=1)
    ax.axhline(0, color="#B0B8C0", linewidth=0.8)
    ax.axvline(0, color="#B0B8C0", linewidth=0.8)
    ax.set_xlabel("Median-based SOZ-NSOZ effect")
    ax.set_ylabel("Mean-based SOZ-NSOZ effect")
    ax.set_title(f"Aggregation sensitivity across 312 features (Spearman rho={rho:.3f})")
    ax.legend(frameon=False, fontsize=8)
    ax.grid(alpha=0.18)
    fig.tight_layout()
    fig.savefig(output.with_suffix(".png"), dpi=300)
    fig.savefig(output.with_suffix(".pdf"))
    plt.close(fig)
    return float(rho)


def markdown_table(frame: pd.DataFrame, columns: list[str], limit: int | None = None) -> str:
    view = frame[columns].copy()
    if limit is not None:
        view = view.head(limit)
    headers = "| " + " | ".join(columns) + " |"
    separator = "|" + "|".join(["---"] * len(columns)) + "|"
    rows = []
    for _, row in view.iterrows():
        values = []
        for column in columns:
            value = row[column]
            if isinstance(value, (float, np.floating)):
                values.append(f"{value:.4g}")
            else:
                values.append(str(value).replace("|", r"\|"))
        rows.append("| " + " | ".join(values) + " |")
    return "\n".join([headers, separator, *rows])


def write_chinese_summary(
    paths: AnalysisPaths,
    primary: pd.DataFrame,
    mean_sensitivity: pd.DataFrame,
    strict: pd.DataFrame,
    public: pd.DataFrame,
    methods: pd.DataFrame,
    qc: pd.DataFrame,
    patient: pd.DataFrame,
    median_mean_rho: float,
) -> None:
    significant = primary[primary["significant_fdr05"]]
    positive = primary[primary["soz_advantage_fdr05"]]
    negative = primary[primary["nsoz_advantage_fdr05"]]
    robust_positive = primary[primary["soz_advantage_fdr05_ci95"]]
    robust_negative = primary[primary["nsoz_advantage_fdr05_ci95"]]
    mean_positive = set(mean_sensitivity.loc[mean_sensitivity["soz_advantage_fdr05"], "feature_id"])
    strict_positive = set(strict.loc[strict["soz_advantage_fdr05"], "feature_id"])
    public_positive = set(public.loc[public["soz_advantage_fdr05"], "feature_id"])
    primary_positive = set(robust_positive["feature_id"])

    top = robust_positive.sort_values(
        ["q_value_global", "median_difference"], ascending=[True, False]
    ).copy()
    if top.empty:
        top = primary.sort_values(["q_value_global", "median_difference"], ascending=[True, False])
    top["feature"] = top.apply(feature_short_label, axis=1)

    summary = f"""# 发作后0–30 s SOZ–NSOZ五类CFC系统分析

生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 分析范围

- 仅使用发作后0–30 s标准化CFC结果，不包含发作前窗口。
- 纳入{patient['patient_id'].nunique()}名患者、{int(qc['primary_included'].sum())}次发作记录。
- 共分析{len(primary)}个频率特征，覆盖5类CFC和8种估计器。
- 患者为统计单位：先在同一接触点内跨发作取中位数，再分别计算患者内SOZ与NSOZ接触点的中位数。
- 主要效应为患者级 `SOZ中位数 − NSOZ中位数`。
- 使用双侧Wilcoxon符号秩检验，并对全部{len(primary)}个特征统一进行BH-FDR校正。

## 主要结果概览

- 全局FDR显著特征：{len(significant)}个。
- 其中方向为SOZ高于NSOZ：{len(positive)}个；方向为NSOZ高于SOZ：{len(negative)}个。
- 同时满足全局FDR、效应方向和bootstrap置信区间标准的稳健SOZ优势特征：{len(robust_positive)}个。
- 同时满足上述标准的稳健NSOZ优势特征：{len(robust_negative)}个。
- 中位数与均值汇总的312特征效应排序相关：Spearman rho = {median_mean_rho:.3f}。
- SOZ通道不少于3个的敏感性分析保留{int(qc['minimum_3_included'].sum())}/{int(qc['primary_included'].sum())}次记录。

## 各方法结果

{markdown_table(methods, ['method_label', 'n_features', 'n_soz_advantage_fdr05_ci95', 'n_nsoz_advantage_fdr05_ci95', 'median_effect_across_features', 'smallest_q_value'])}

## 排名前20的SOZ优势频率

{markdown_table(top, ['feature', 'n_patients', 'soz_group_median', 'nsoz_group_median', 'median_difference', 'ci95_low', 'ci95_high', 'rank_biserial', 'positive_fraction', 'q_value_global'], 20)}

## 稳健性重叠

- 主要中位数分析与均值分析共同显著的SOZ优势特征：{len(primary_positive & mean_positive)}/{len(primary_positive)}。
- 主要分析与“每次记录至少3个SOZ通道”分析共同显著：{len(primary_positive & strict_positive)}/{len(primary_positive)}。
- 主要分析与仅公共临床SOZ标签分析共同显著：{len(primary_positive & public_positive)}/{len(primary_positive)}。

## 解释边界

本轮结果只能说明发作后0–30 s内SOZ与NSOZ之间存在空间CFC差异，不能说明该差异由发作诱发或相对发作前增强。兰州队列标签应表述为“手术切除区域定义的推定SOZ接触点”。不同CFC估计器的绝对Z值不直接比较大小，应以患者级效应方向、效应量、显著频率区域及多估计器一致性为主要依据。
"""
    (paths.output_root / "结果摘要_中文版.md").write_text(summary, encoding="utf-8")


def main() -> None:
    args = parse_args()
    paths = AnalysisPaths(args.input_root.resolve(), args.output_root.resolve())
    prepare_output(paths)
    print(f"Input: {paths.input_root}", flush=True)
    print(f"Output: {paths.output_root}", flush=True)

    collected, feature_catalog = collect_patient_summaries(paths.input_root)
    contact, patient, patient_strict, qc = collected

    feature_catalog.to_csv(paths.tables / "feature_catalog.csv", index=False, encoding="utf-8-sig")
    contact.to_parquet(paths.tables / "contact_level_ictal_summary.parquet", index=False)
    patient.to_parquet(paths.tables / "patient_level_ictal_soz_nsoz.parquet", index=False)
    patient_strict.to_parquet(
        paths.tables / "patient_level_ictal_soz_nsoz_minimum3.parquet", index=False
    )
    qc.to_csv(paths.tables / "recording_label_counts.csv", index=False, encoding="utf-8-sig")

    primary = summarize_feature_statistics(
        patient,
        "diff_median",
        "z_region_median_soz",
        "z_region_median_nsoz",
        feature_catalog,
        "primary_patient_median",
        args.bootstrap,
        args.seed,
    )
    mean_sensitivity = summarize_feature_statistics(
        patient,
        "diff_mean",
        "z_region_mean_soz",
        "z_region_mean_nsoz",
        feature_catalog,
        "sensitivity_patient_mean",
        0,
        args.seed + 1,
    )
    strict = summarize_feature_statistics(
        patient_strict,
        "diff_median",
        "z_region_median_soz",
        "z_region_median_nsoz",
        feature_catalog,
        "sensitivity_minimum_3_soz_nsoz_per_record",
        0,
        args.seed + 2,
    )
    public_patient = patient[patient["dataset_id"].isin(["ds003029", "ds004100"])].copy()
    public = summarize_feature_statistics(
        public_patient,
        "diff_median",
        "z_region_median_soz",
        "z_region_median_nsoz",
        feature_catalog,
        "sensitivity_public_clinical_soz_only",
        0,
        args.seed + 3,
    )

    primary.to_csv(paths.tables / "feature_statistics_primary_median.csv", index=False, encoding="utf-8-sig")
    mean_sensitivity.to_csv(
        paths.tables / "feature_statistics_sensitivity_mean.csv", index=False, encoding="utf-8-sig"
    )
    strict.to_csv(
        paths.tables / "feature_statistics_sensitivity_minimum3.csv", index=False, encoding="utf-8-sig"
    )
    public.to_csv(
        paths.tables / "feature_statistics_sensitivity_public_only.csv", index=False, encoding="utf-8-sig"
    )

    methods = method_summary(primary)
    methods.to_csv(paths.tables / "method_summary.csv", index=False, encoding="utf-8-sig")

    save_method_summary_figure(methods, paths.figures / "significant_feature_counts")
    save_top_feature_figure(primary, paths.figures / "top_soz_advantage_features")
    save_effect_maps(primary, paths.figures / "eight_estimator_effect_maps")
    save_region_pair_maps(primary, paths.figures / "individual_method_maps")
    median_mean_rho = save_median_mean_consistency(
        primary, mean_sensitivity, paths.figures / "median_vs_mean_consistency"
    )

    run_metadata = {
        "generated_at": datetime.now().isoformat(),
        "input_root": str(paths.input_root),
        "output_root": str(paths.output_root),
        "state": "ictal",
        "window_sec": [0.0, 30.0],
        "bootstrap_repeats_primary": args.bootstrap,
        "seed": args.seed,
        "patients_primary": int(patient["patient_id"].nunique()),
        "recordings_primary": int(qc["primary_included"].sum()),
        "recordings_minimum3": int(qc["minimum_3_included"].sum()),
        "features": int(len(primary)),
        "significant_global_fdr05": int(primary["significant_fdr05"].sum()),
        "soz_direction_global_fdr05": int(primary["soz_advantage_fdr05"].sum()),
        "nsoz_direction_global_fdr05": int(primary["nsoz_advantage_fdr05"].sum()),
        "soz_advantage_global_fdr05_ci95": int(
            primary["soz_advantage_fdr05_ci95"].sum()
        ),
        "nsoz_advantage_global_fdr05_ci95": int(
            primary["nsoz_advantage_fdr05_ci95"].sum()
        ),
        "median_mean_effect_spearman_rho": median_mean_rho,
        "gpu_note": "GPU is available in xiaoluozai, but this aggregation/statistical stage is CPU-bound.",
    }
    (paths.output_root / "run_metadata.json").write_text(
        json.dumps(run_metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    write_chinese_summary(
        paths,
        primary,
        mean_sensitivity,
        strict,
        public,
        methods,
        qc,
        patient,
        median_mean_rho,
    )
    print(json.dumps(run_metadata, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
