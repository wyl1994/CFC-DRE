"""Experiment 3: onset interactions, trajectories, trends, reliability and sensitivities.

Scientific definitions follow the frozen author analysis; see REPRODUCE.md.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import shutil
import sys
import warnings
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
from scipy import stats


COHORTS = ("Lanzhou", "ds003029", "ds004100")
FAMILIES = ("PAC", "CFC_coherence", "AAC", "Bicoherence", "PPC")
WINDOWS = (
    "pre_temporal_early",
    "pre_temporal_middle",
    "pre_cumulative_10",
    "post_cumulative_10",
    "post_temporal_middle",
    "post_temporal_late",
)
WINDOW_LABELS = {
    "pre_temporal_early": "-30 to -20 s",
    "pre_temporal_middle": "-20 to -10 s",
    "pre_cumulative_10": "-10 to 0 s",
    "post_cumulative_10": "0 to 10 s",
    "post_temporal_middle": "10 to 20 s",
    "post_temporal_late": "20 to 30 s",
}
PRE_NEAR = "pre_cumulative_10"
POST_WINDOWS = WINDOWS[3:]


@dataclass(frozen=True)
class Inputs:
    patient_root: Path
    early: Path
    spatial: Path
    zone: Path
    catalog: Path
    mean_spatial: Path
    confirmed_spatial: Path
    qc: Path


@dataclass(frozen=True)
class Section:
    root: Path
    data: Path
    figures: Path
    code: Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Revised Experiment 3 analysis")
    parser.add_argument("--source-experiment", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--bootstrap-repeats", type=int, default=3000)
    parser.add_argument("--permutation-repeats", type=int, default=10000)
    parser.add_argument("--global-permutation-repeats", type=int, default=5000)
    parser.add_argument("--split-half-repeats", type=int, default=2000)
    parser.add_argument("--loco-bootstrap-repeats", type=int, default=1500)
    parser.add_argument("--seed", type=int, default=20260918)
    return parser.parse_args()


def locate_inputs(source: Path) -> Inputs:
    # The public package accepts a flat patient-input directory produced by `aggregate`.
    patient_root = source if (source / "feature_catalog.csv").is_file() else source / "05_公共数据与计算底稿" / "04_患者级六窗数据"
    inputs = Inputs(
        patient_root=patient_root,
        early=patient_root / "patient_early_interaction_312_features.parquet",
        spatial=patient_root / "patient_spatial_contrast_six_windows.parquet",
        zone=patient_root / "patient_zone_six_windows.parquet",
        catalog=patient_root / "feature_catalog.csv",
        mean_spatial=patient_root / "sensitivity_mean_patient_spatial_contrast.parquet",
        confirmed_spatial=patient_root / "sensitivity_confirmed_ge30_spatial_contrast.parquet",
        qc=patient_root / "patient_processing_qc.csv",
    )
    missing = [str(path) for path in inputs.__dict__.values() if isinstance(path, Path) and not path.exists()]
    if missing:
        raise FileNotFoundError("Missing validated inputs:\n" + "\n".join(missing))
    return inputs


def make_section(root: Path, name: str) -> Section:
    section_root = root / name
    section = Section(
        root=section_root,
        data=section_root / "01_统计数据",
        figures=section_root / "02_结果图",
        code=section_root / "03_分析代码",
    )
    for path in section.__dict__.values():
        Path(path).mkdir(parents=True, exist_ok=True)
    return section


def make_structure(root: Path) -> dict[str, Section]:
    root.mkdir(parents=True, exist_ok=True)
    names = {
        "primary": "01_早期五家族区域时间交互",
        "cohort": "02_三队列独立与中心等权推断",
        "features": "03_312特征频率图谱",
        "trajectory": "04_六时间窗动态与发作前趋势",
        "transport": "05_跨队列动态稳健性",
        "sources": "06_标准化来源诊断",
        "sensitivity": "07_关键敏感性分析",
        "report": "08_正式报告与汇总",
    }
    return {key: make_section(root, value) for key, value in names.items()}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def bh_fdr(values: pd.Series | np.ndarray) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    result = np.full(arr.shape, np.nan)
    valid = np.isfinite(arr)
    if not valid.any():
        return result
    p = arr[valid]
    order = np.argsort(p)
    ranked = p[order]
    adjusted = ranked * len(ranked) / np.arange(1, len(ranked) + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    adjusted = np.clip(adjusted, 0, 1)
    restored = np.empty_like(adjusted)
    restored[order] = adjusted
    result[valid] = restored
    return result


def signed_wilcoxon(values: np.ndarray) -> tuple[float, float]:
    arr = np.asarray(values, dtype=float)
    arr = arr[np.isfinite(arr)]
    if len(arr) == 0 or np.allclose(arr, 0):
        return 0.0, 1.0
    test = stats.wilcoxon(arr, zero_method="wilcox", alternative="two-sided", method="auto")
    return float(test.statistic), float(test.pvalue)


def rank_biserial(values: np.ndarray) -> float:
    arr = np.asarray(values, dtype=float)
    arr = arr[np.isfinite(arr) & ~np.isclose(arr, 0)]
    if len(arr) == 0:
        return 0.0
    ranks = stats.rankdata(np.abs(arr))
    denominator = float(ranks.sum())
    return float((ranks[arr > 0].sum() - ranks[arr < 0].sum()) / denominator)


def bootstrap_ci(values: np.ndarray, repeats: int, rng: np.random.Generator) -> tuple[float, float]:
    arr = np.asarray(values, dtype=float)
    arr = arr[np.isfinite(arr)]
    if len(arr) < 2:
        return math.nan, math.nan
    samples = arr[rng.integers(0, len(arr), size=(repeats, len(arr)))]
    estimates = np.median(samples, axis=1)
    return tuple(float(value) for value in np.quantile(estimates, [0.025, 0.975]))


def summarize_values(values: np.ndarray, repeats: int, rng: np.random.Generator) -> dict[str, float | int]:
    arr = np.asarray(values, dtype=float)
    arr = arr[np.isfinite(arr)]
    statistic, p_value = signed_wilcoxon(arr)
    low, high = bootstrap_ci(arr, repeats, rng)
    return {
        "n_patients": int(len(arr)),
        "median_effect": float(np.median(arr)) if len(arr) else math.nan,
        "ci95_low": low,
        "ci95_high": high,
        "wilcoxon_statistic": statistic,
        "p_value": p_value,
        "rank_biserial": rank_biserial(arr),
        "positive_fraction": float(np.mean(arr > 0)) if len(arr) else math.nan,
    }


def summarize_grouped(
    frame: pd.DataFrame,
    group_columns: list[str],
    value_column: str,
    repeats: int,
    seed: int,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows: list[dict[str, object]] = []
    grouped = frame.groupby(group_columns, observed=True, sort=False) if group_columns else [((), frame)]
    for key, group in grouped:
        if not isinstance(key, tuple):
            key = (key,)
        row = dict(zip(group_columns, key))
        row.update(summarize_values(group[value_column].to_numpy(float), repeats, rng))
        rows.append(row)
    return pd.DataFrame(rows)


def family_patient_effects(early: pd.DataFrame, value: str = "interaction_z_value") -> pd.DataFrame:
    return (
        early.groupby(["dataset_id", "patient_id", "cfc_family"], observed=True)[value]
        .median()
        .rename("family_interaction")
        .reset_index()
    )


def run_primary(
    early: pd.DataFrame,
    section: Section,
    repeats: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    patient = family_patient_effects(early)
    outputs = []
    for index, label in enumerate(("Pooled_patients",) + COHORTS):
        subset = patient if label == "Pooled_patients" else patient[patient["dataset_id"].eq(label)]
        table = summarize_grouped(subset, ["cfc_family"], "family_interaction", repeats, seed + index)
        table.insert(0, "analysis_group", label)
        table["q_value"] = bh_fdr(table["p_value"])
        outputs.append(table)
    statistics = pd.concat(outputs, ignore_index=True)
    statistics["robust_positive"] = (
        statistics["q_value"].lt(0.05)
        & statistics["ci95_low"].gt(0)
        & statistics["rank_biserial"].gt(0)
    )
    statistics["robust_negative"] = (
        statistics["q_value"].lt(0.05)
        & statistics["ci95_high"].lt(0)
        & statistics["rank_biserial"].lt(0)
    )
    patient.to_csv(section.data / "患者级五家族早期交互.csv", index=False, encoding="utf-8-sig")
    statistics.to_csv(section.data / "五家族合并与分队列统计.csv", index=False, encoding="utf-8-sig")
    return patient, statistics


def center_equal_test(
    patient: pd.DataFrame,
    family: str,
    bootstrap_repeats: int,
    permutation_repeats: int,
    rng: np.random.Generator,
) -> dict[str, object]:
    arrays = {
        cohort: patient.loc[
            patient["dataset_id"].eq(cohort) & patient["cfc_family"].eq(family),
            "family_interaction",
        ].dropna().to_numpy(float)
        for cohort in COHORTS
    }
    cohort_medians = {cohort: float(np.median(values)) for cohort, values in arrays.items()}
    observed = float(np.mean(list(cohort_medians.values())))
    boot = np.empty(bootstrap_repeats, dtype=float)
    for index in range(bootstrap_repeats):
        values = []
        for cohort in COHORTS:
            arr = arrays[cohort]
            sampled = arr[rng.integers(0, len(arr), len(arr))]
            values.append(np.median(sampled))
        boot[index] = np.mean(values)
    null = np.empty(permutation_repeats, dtype=float)
    for index in range(permutation_repeats):
        values = []
        for cohort in COHORTS:
            arr = arrays[cohort]
            signs = rng.choice((-1.0, 1.0), size=len(arr))
            values.append(np.median(arr * signs))
        null[index] = np.mean(values)
    p_value = float((1 + np.sum(np.abs(null) >= abs(observed))) / (permutation_repeats + 1))
    return {
        "cfc_family": family,
        "center_equal_effect": observed,
        "ci95_low": float(np.quantile(boot, 0.025)),
        "ci95_high": float(np.quantile(boot, 0.975)),
        "permutation_p_value": p_value,
        "Lanzhou_median": cohort_medians["Lanzhou"],
        "ds003029_median": cohort_medians["ds003029"],
        "ds004100_median": cohort_medians["ds004100"],
        "all_cohorts_same_direction": len({np.sign(v) for v in cohort_medians.values() if not np.isclose(v, 0)}) == 1,
    }


def global_family_permutation(
    early: pd.DataFrame,
    family: str,
    repeats: int,
    rng: np.random.Generator,
) -> dict[str, object]:
    family_data = early[early["cfc_family"].eq(family)]
    matrices: dict[str, np.ndarray] = {}
    feature_ids = sorted(family_data["feature_id"].unique())
    for cohort in COHORTS:
        matrix = family_data[family_data["dataset_id"].eq(cohort)].pivot(
            index="patient_id", columns="feature_id", values="interaction_z_value"
        )
        matrices[cohort] = matrix.reindex(columns=feature_ids).to_numpy(float)

    def statistic_from(mats: dict[str, np.ndarray]) -> float:
        maps = [np.nanmedian(mats[cohort], axis=0) for cohort in COHORTS]
        return float(np.nanmedian(np.nanmean(np.vstack(maps), axis=0)))

    observed = statistic_from(matrices)
    null = np.empty(repeats, dtype=float)
    for index in range(repeats):
        permuted = {}
        for cohort, matrix in matrices.items():
            signs = rng.choice((-1.0, 1.0), size=len(matrix))[:, None]
            permuted[cohort] = matrix * signs
        null[index] = statistic_from(permuted)
    p_value = float((1 + np.sum(np.abs(null) >= abs(observed))) / (repeats + 1))
    return {
        "cfc_family": family,
        "n_features": len(feature_ids),
        "global_center_equal_statistic": observed,
        "global_sign_flip_p_value": p_value,
    }


def run_cohort_inference(
    early: pd.DataFrame,
    patient: pd.DataFrame,
    section: Section,
    bootstrap_repeats: int,
    permutation_repeats: int,
    global_repeats: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(seed)
    equal = pd.DataFrame(
        [
            center_equal_test(patient, family, bootstrap_repeats, permutation_repeats, rng)
            for family in FAMILIES
        ]
    )
    equal["q_value"] = bh_fdr(equal["permutation_p_value"])
    equal["robust_center_equal"] = (
        equal["q_value"].lt(0.05)
        & ((equal["ci95_low"].gt(0)) | (equal["ci95_high"].lt(0)))
        & equal["all_cohorts_same_direction"]
    )

    global_test = pd.DataFrame(
        [global_family_permutation(early, family, global_repeats, rng) for family in FAMILIES]
    )
    global_test["q_value"] = bh_fdr(global_test["global_sign_flip_p_value"])

    leave_rows = []
    for index, heldout in enumerate(COHORTS):
        subset = patient[~patient["dataset_id"].eq(heldout)]
        table = summarize_grouped(
            subset, ["cfc_family"], "family_interaction", bootstrap_repeats, seed + 100 + index
        )
        table.insert(0, "heldout_cohort", heldout)
        table["q_value"] = bh_fdr(table["p_value"])
        leave_rows.append(table)
    leave_one = pd.concat(leave_rows, ignore_index=True)

    equal.to_csv(section.data / "中心等权五家族置换检验.csv", index=False, encoding="utf-8-sig")
    global_test.to_csv(section.data / "家族联合特征符号翻转检验.csv", index=False, encoding="utf-8-sig")
    leave_one.to_csv(section.data / "留一队列家族稳健性.csv", index=False, encoding="utf-8-sig")
    return equal, global_test, leave_one


def run_features(
    early: pd.DataFrame,
    catalog: pd.DataFrame,
    section: Section,
    repeats: int,
    seed: int,
) -> pd.DataFrame:
    tables = []
    for index, label in enumerate(("Pooled_patients",) + COHORTS):
        subset = early if label == "Pooled_patients" else early[early["dataset_id"].eq(label)]
        table = summarize_grouped(
            subset,
            ["cfc_family", "method", "feature_id"],
            "interaction_z_value",
            repeats,
            seed + index,
        )
        table.insert(0, "analysis_group", label)
        table["q_value"] = bh_fdr(table["p_value"])
        tables.append(table)
    result = pd.concat(tables, ignore_index=True)
    result = result.merge(
        catalog,
        on=["cfc_family", "method", "feature_id"],
        how="left",
        validate="many_to_one",
    )
    result["robust_positive"] = result["q_value"].lt(0.05) & result["ci95_low"].gt(0)
    result["robust_negative"] = result["q_value"].lt(0.05) & result["ci95_high"].lt(0)

    cohort_maps = result[result["analysis_group"].isin(COHORTS)].pivot(
        index="feature_id", columns="analysis_group", values="median_effect"
    )
    directions = cohort_maps.apply(lambda row: len({np.sign(v) for v in row.dropna() if not np.isclose(v, 0)}) == 1, axis=1)
    pooled = result[result["analysis_group"].eq("Pooled_patients")].copy()
    pooled["all_cohorts_same_direction"] = pooled["feature_id"].map(directions).fillna(False)
    pooled["evidence_tier"] = "Exploratory"
    pooled.loc[pooled["all_cohorts_same_direction"], "evidence_tier"] = "Directionally_supported"
    pooled.loc[
        pooled["all_cohorts_same_direction"] & (pooled["robust_positive"] | pooled["robust_negative"]),
        "evidence_tier",
    ] = "Robust_frequency_localization"
    tier_map = pooled.set_index("feature_id")["evidence_tier"]
    result["evidence_tier"] = result["feature_id"].map(tier_map)

    result.to_csv(section.data / "312特征合并与分队列统计.csv", index=False, encoding="utf-8-sig")
    pooled.to_csv(section.data / "312特征证据分层.csv", index=False, encoding="utf-8-sig")
    return result


def family_spatial(spatial: pd.DataFrame, value: str = "spatial_z_value") -> pd.DataFrame:
    return (
        spatial.groupby(
            ["dataset_id", "patient_id", "window_id", "cfc_family"], observed=True
        )[value]
        .median()
        .rename("family_spatial_contrast")
        .reset_index()
    )


def run_trajectory(
    spatial: pd.DataFrame,
    confirmed_spatial: pd.DataFrame,
    section: Section,
    repeats: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    family = family_spatial(spatial)
    trajectory = summarize_grouped(
        family,
        ["window_id", "cfc_family"],
        "family_spatial_contrast",
        repeats,
        seed,
    )
    trajectory["window_order"] = trajectory["window_id"].map({w: i for i, w in enumerate(WINDOWS)})

    pre = family[family["window_id"].eq(PRE_NEAR)][
        ["dataset_id", "patient_id", "cfc_family", "family_spatial_contrast"]
    ].rename(columns={"family_spatial_contrast": "near_pre"})
    post = family[family["window_id"].isin(POST_WINDOWS)].merge(
        pre, on=["dataset_id", "patient_id", "cfc_family"], validate="many_to_one"
    )
    post["post_vs_near_pre"] = post["family_spatial_contrast"] - post["near_pre"]
    fifteen = summarize_grouped(
        post,
        ["window_id", "cfc_family"],
        "post_vs_near_pre",
        repeats,
        seed + 100,
    )
    fifteen["q_value"] = bh_fdr(fifteen["p_value"])

    pre_wide = family[family["window_id"].isin(WINDOWS[:3])].pivot(
        index=["dataset_id", "patient_id", "cfc_family"],
        columns="window_id",
        values="family_spatial_contrast",
    ).dropna()
    pre_wide["pretrend_per_10s"] = (
        pre_wide["pre_cumulative_10"] - pre_wide["pre_temporal_early"]
    ) / 2.0
    pretrend_patient = pre_wide.reset_index()[
        ["dataset_id", "patient_id", "cfc_family", "pretrend_per_10s"]
    ]
    pretrend = summarize_grouped(
        pretrend_patient, ["cfc_family"], "pretrend_per_10s", repeats, seed + 200
    )
    pretrend["q_value"] = bh_fdr(pretrend["p_value"])
    friedman_rows = []
    for family_name in FAMILIES:
        subset = pre_wide.reset_index()
        subset = subset[subset["cfc_family"].eq(family_name)]
        test = stats.friedmanchisquare(
            subset["pre_temporal_early"],
            subset["pre_temporal_middle"],
            subset["pre_cumulative_10"],
        )
        friedman_rows.append(
            {
                "cfc_family": family_name,
                "n_patients": len(subset),
                "friedman_statistic": float(test.statistic),
                "friedman_p_value": float(test.pvalue),
            }
        )
    friedman = pd.DataFrame(friedman_rows)
    friedman["friedman_q_value"] = bh_fdr(friedman["friedman_p_value"])
    pretrend = pretrend.merge(friedman, on=["cfc_family", "n_patients"], how="left")

    confirmed_family = family_spatial(confirmed_spatial)
    confirmed_pre = confirmed_family[confirmed_family["window_id"].eq(PRE_NEAR)][
        ["dataset_id", "patient_id", "cfc_family", "family_spatial_contrast"]
    ].rename(columns={"family_spatial_contrast": "near_pre"})
    confirmed_post = confirmed_family[confirmed_family["window_id"].isin(POST_WINDOWS)].merge(
        confirmed_pre, on=["dataset_id", "patient_id", "cfc_family"], validate="many_to_one"
    )
    confirmed_post["post_vs_near_pre"] = confirmed_post["family_spatial_contrast"] - confirmed_post["near_pre"]
    confirmed_stats = summarize_grouped(
        confirmed_post,
        ["window_id", "cfc_family"],
        "post_vs_near_pre",
        repeats,
        seed + 300,
    )
    confirmed_stats["q_value"] = bh_fdr(confirmed_stats["p_value"])

    family.to_csv(section.data / "患者级六窗五家族空间差异.csv", index=False, encoding="utf-8-sig")
    trajectory.to_csv(section.data / "六窗五家族轨迹统计.csv", index=False, encoding="utf-8-sig")
    fifteen.to_csv(section.data / "十五项发作后相对近端发作前检验.csv", index=False, encoding="utf-8-sig")
    pretrend_patient.to_csv(section.data / "患者级发作前三窗趋势.csv", index=False, encoding="utf-8-sig")
    pretrend.to_csv(section.data / "发作前趋势统计.csv", index=False, encoding="utf-8-sig")
    confirmed_stats.to_csv(section.data / "持续至少30秒严格子集动态检验.csv", index=False, encoding="utf-8-sig")
    return family, trajectory, pretrend


def safe_spearman(first: np.ndarray, second: np.ndarray) -> float:
    first = np.asarray(first, dtype=float)
    second = np.asarray(second, dtype=float)
    mask = np.isfinite(first) & np.isfinite(second)
    if mask.sum() < 3 or np.allclose(first[mask], first[mask][0]) or np.allclose(second[mask], second[mask][0]):
        return math.nan
    return float(stats.spearmanr(first[mask], second[mask]).statistic)


def map_metrics(first: np.ndarray, second: np.ndarray) -> dict[str, float]:
    first = np.asarray(first, dtype=float)
    second = np.asarray(second, dtype=float)
    mask = np.isfinite(first) & np.isfinite(second)
    return {
        "n_features": int(mask.sum()),
        "spearman_rho": safe_spearman(first, second),
        "direction_agreement": float(np.mean(np.sign(first[mask]) == np.sign(second[mask]))),
        "median_absolute_difference": float(np.median(np.abs(first[mask] - second[mask]))),
    }


def split_half_reliability(
    early: pd.DataFrame,
    catalog: pd.DataFrame,
    repeats: int,
    seed: int,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    scopes = [("Overall", list(catalog["feature_id"]))]
    scopes += [
        (family, list(catalog.loc[catalog["cfc_family"].eq(family), "feature_id"]))
        for family in FAMILIES
    ]
    rows = []
    for cohort in COHORTS:
        cohort_data = early[early["dataset_id"].eq(cohort)]
        matrix = cohort_data.pivot(index="patient_id", columns="feature_id", values="interaction_z_value")
        matrix = matrix.reindex(columns=catalog["feature_id"]).to_numpy(float)
        for scope, feature_ids in scopes:
            indices = [catalog.index[catalog["feature_id"].eq(fid)][0] for fid in feature_ids]
            values = []
            for _ in range(repeats):
                order = rng.permutation(len(matrix))
                half = len(order) // 2
                first = np.nanmedian(matrix[order[:half]][:, indices], axis=0)
                second = np.nanmedian(matrix[order[half:]][:, indices], axis=0)
                values.append(safe_spearman(first, second))
            arr = np.asarray(values, dtype=float)
            arr = arr[np.isfinite(arr)]
            median = float(np.median(arr)) if len(arr) else math.nan
            rows.append(
                {
                    "dataset_id": cohort,
                    "scope": scope,
                    "n_patients": len(matrix),
                    "split_half_rho_median": median,
                    "ci95_low": float(np.quantile(arr, 0.025)) if len(arr) else math.nan,
                    "ci95_high": float(np.quantile(arr, 0.975)) if len(arr) else math.nan,
                    "spearman_brown": float(2 * median / (1 + median)) if np.isfinite(median) and median > -1 else math.nan,
                }
            )
    return pd.DataFrame(rows)


def bootstrap_loco(
    matrices: dict[str, np.ndarray],
    heldout: str,
    feature_indices: list[int],
    repeats: int,
    rng: np.random.Generator,
) -> tuple[float, float]:
    discovery = [cohort for cohort in COHORTS if cohort != heldout]
    values = []
    for _ in range(repeats):
        maps = {}
        for cohort, matrix in matrices.items():
            sampled = matrix[rng.integers(0, len(matrix), len(matrix))]
            maps[cohort] = np.nanmedian(sampled[:, feature_indices], axis=0)
        discovery_map = np.nanmean(np.vstack([maps[cohort] for cohort in discovery]), axis=0)
        values.append(safe_spearman(discovery_map, maps[heldout]))
    arr = np.asarray(values, dtype=float)
    arr = arr[np.isfinite(arr)]
    return tuple(float(value) for value in np.quantile(arr, [0.025, 0.975]))


def run_transportability(
    early: pd.DataFrame,
    catalog: pd.DataFrame,
    section: Section,
    split_repeats: int,
    loco_repeats: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    feature_ids = list(catalog["feature_id"])
    scopes = [("Overall", feature_ids)] + [
        (family, list(catalog.loc[catalog["cfc_family"].eq(family), "feature_id"]))
        for family in FAMILIES
    ]
    maps = {
        cohort: early[early["dataset_id"].eq(cohort)]
        .groupby("feature_id", observed=True)["interaction_z_value"]
        .median()
        .reindex(feature_ids)
        for cohort in COHORTS
    }
    pair_rows = []
    for first_index, first in enumerate(COHORTS):
        for second in COHORTS[first_index + 1 :]:
            for scope, ids in scopes:
                idx = [feature_ids.index(fid) for fid in ids]
                metrics = map_metrics(maps[first].to_numpy()[idx], maps[second].to_numpy()[idx])
                pair_rows.append({"comparison": f"{first} vs {second}", "scope": scope, **metrics})
    pairwise = pd.DataFrame(pair_rows)

    matrices = {
        cohort: early[early["dataset_id"].eq(cohort)]
        .pivot(index="patient_id", columns="feature_id", values="interaction_z_value")
        .reindex(columns=feature_ids)
        .to_numpy(float)
        for cohort in COHORTS
    }
    rng = np.random.default_rng(seed)
    loco_rows = []
    for heldout in COHORTS:
        discovery = [cohort for cohort in COHORTS if cohort != heldout]
        discovery_map = np.nanmean(np.vstack([maps[c].to_numpy() for c in discovery]), axis=0)
        validation_map = maps[heldout].to_numpy()
        for scope, ids in scopes:
            idx = [feature_ids.index(fid) for fid in ids]
            low, high = bootstrap_loco(matrices, heldout, idx, loco_repeats, rng)
            metrics = map_metrics(discovery_map[idx], validation_map[idx])
            loco_rows.append(
                {
                    "heldout_cohort": heldout,
                    "discovery_cohorts": "+".join(discovery),
                    "scope": scope,
                    "ci95_low": low,
                    "ci95_high": high,
                    **metrics,
                }
            )
    loco = pd.DataFrame(loco_rows)
    reliability = split_half_reliability(early, catalog, split_repeats, seed + 100)

    pairwise.to_csv(section.data / "动态交互图谱两两相关.csv", index=False, encoding="utf-8-sig")
    loco.to_csv(section.data / "动态交互图谱LOCO.csv", index=False, encoding="utf-8-sig")
    reliability.to_csv(section.data / "队列内动态交互分半可靠性.csv", index=False, encoding="utf-8-sig")
    return pairwise, loco, reliability


def run_sources(
    early: pd.DataFrame,
    section: Section,
    repeats: int,
    seed: int,
) -> pd.DataFrame:
    columns = {
        "z_value": "interaction_z_value",
        "observed_value": "interaction_observed_value",
        "surrogate_mean": "interaction_surrogate_mean",
        "surrogate_std": "interaction_surrogate_std",
    }
    rows = []
    for index, (source_name, column) in enumerate(columns.items()):
        family = family_patient_effects(early, column)
        table = summarize_grouped(
            family, ["cfc_family"], "family_interaction", repeats, seed + index
        )
        table.insert(0, "source_metric", source_name)
        table["q_value"] = bh_fdr(table["p_value"])
        rows.append(table)
    result = pd.concat(rows, ignore_index=True)
    result.to_csv(section.data / "标准化值来源分解.csv", index=False, encoding="utf-8-sig")
    return result


def derive_early(spatial: pd.DataFrame) -> pd.DataFrame:
    keys = ["dataset_id", "patient_id", "cfc_family", "method", "feature_id"]
    pre = spatial[spatial["window_id"].eq(PRE_NEAR)][keys + ["spatial_z_value"]].rename(
        columns={"spatial_z_value": "pre"}
    )
    post = spatial[spatial["window_id"].eq("post_cumulative_10")][keys + ["spatial_z_value"]].rename(
        columns={"spatial_z_value": "post"}
    )
    result = pre.merge(post, on=keys, validate="one_to_one")
    result["interaction_z_value"] = result["post"] - result["pre"]
    return result


def run_cached_sensitivity(
    early: pd.DataFrame,
    mean_spatial: pd.DataFrame,
    confirmed_spatial: pd.DataFrame,
    catalog: pd.DataFrame,
    section: Section,
    repeats: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    high_mask = catalog[["band_1", "band_2"]].eq("fast_ripple_low").any(axis=1)
    allowed = set(catalog.loc[~high_mask, "feature_id"])
    analyses = {
        "Primary_median": early,
        "Mean_hierarchy": derive_early(mean_spatial),
        "Confirmed_duration_ge30": derive_early(confirmed_spatial),
        "Exclude_150_200_Hz": early[early["feature_id"].isin(allowed)],
    }
    rows = []
    for index, (name, frame) in enumerate(analyses.items()):
        family = family_patient_effects(frame)
        table = summarize_grouped(
            family, ["cfc_family"], "family_interaction", repeats, seed + index
        )
        table.insert(0, "analysis", name)
        table["q_value"] = bh_fdr(table["p_value"])
        rows.append(table)
    result = pd.concat(rows, ignore_index=True)
    result.to_csv(section.data / "可直接复用的敏感性分析.csv", index=False, encoding="utf-8-sig")

    pending = pd.DataFrame(
        [
            {
                "analysis": "Onset_guard_window_-12_-2_vs_2_12",
                "status": "not_run_requires_raw_signal_recomputation",
                "reason": "Existing standardized cache contains only fixed non-overlapping 10-s windows.",
                "planned_scope": "PAC and CFC_coherence",
            },
            {
                "analysis": "Power_adjustment",
                "status": "not_run_requires_raw_signal_features",
                "reason": "Matched low- and high-frequency power interactions are absent from the frozen patient tables.",
                "planned_scope": "PAC and CFC_coherence",
            },
            {
                "analysis": "Spike_masking_and_harmonic_diagnostics",
                "status": "not_run_requires_validated_detector",
                "reason": "No frozen spike detector or harmonic diagnostic definition is available in the archive.",
                "planned_scope": "Locked PAC frequency regions",
            },
            {
                "analysis": "Alternative_reference",
                "status": "not_run_requires_raw_signal_recomputation",
                "reason": "Median or bipolar re-referencing must be applied before CFC estimation.",
                "planned_scope": "PAC and CFC_coherence",
            },
        ]
    )
    pending.to_csv(section.data / "原始信号敏感性待运行状态.csv", index=False, encoding="utf-8-sig")
    return result, pending


def setup_plotting() -> None:
    candidates = ["Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"]
    plt.rcParams["font.sans-serif"] = candidates
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["figure.dpi"] = 150
    plt.rcParams["savefig.dpi"] = 300


def save_figure(fig: plt.Figure, path: Path) -> None:
    fig.tight_layout()
    fig.savefig(path.with_suffix(".png"), bbox_inches="tight")
    fig.savefig(path.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)


def make_figures(
    primary_stats: pd.DataFrame,
    equal: pd.DataFrame,
    feature_stats: pd.DataFrame,
    trajectory: pd.DataFrame,
    pretrend: pd.DataFrame,
    pairwise: pd.DataFrame,
    reliability: pd.DataFrame,
    sources: pd.DataFrame,
    sensitivity: pd.DataFrame,
    sections: dict[str, Section],
) -> None:
    setup_plotting()
    colors = {
        "PAC": "#2563A6",
        "CFC_coherence": "#17A6A6",
        "AAC": "#E49B26",
        "Bicoherence": "#D04A4A",
        "PPC": "#7A6AAE",
    }

    pooled = primary_stats[primary_stats["analysis_group"].eq("Pooled_patients")].set_index("cfc_family").reindex(FAMILIES)
    center = equal.set_index("cfc_family").reindex(FAMILIES)
    y = np.arange(len(FAMILIES))
    fig, ax = plt.subplots(figsize=(8.4, 4.8))
    ax.errorbar(
        pooled["median_effect"], y + 0.12,
        xerr=np.vstack([pooled["median_effect"] - pooled["ci95_low"], pooled["ci95_high"] - pooled["median_effect"]]),
        fmt="o", color="#4B5563", capsize=3, label="Patient pooled"
    )
    ax.errorbar(
        center["center_equal_effect"], y - 0.12,
        xerr=np.vstack([center["center_equal_effect"] - center["ci95_low"], center["ci95_high"] - center["center_equal_effect"]]),
        fmt="s", color="#0F766E", capsize=3, label="Cohort equal"
    )
    ax.axvline(0, color="black", lw=1, ls="--")
    ax.set_yticks(y, FAMILIES)
    ax.invert_yaxis()
    ax.set_xlabel("Early region-by-time interaction (standardized CFC)")
    ax.set_title("Five-family early interaction: pooled vs cohort-equal")
    ax.legend(frameon=False)
    save_figure(fig, sections["cohort"].figures / "Fig1_五家族合并与中心等权森林图")

    pooled_features = feature_stats[feature_stats["analysis_group"].eq("Pooled_patients")]
    counts = (
        pooled_features.assign(
            positive=pooled_features["robust_positive"].astype(int),
            negative=pooled_features["robust_negative"].astype(int),
        )
        .groupby("cfc_family", observed=True)[["positive", "negative"]]
        .sum()
        .reindex(FAMILIES)
    )
    fig, ax = plt.subplots(figsize=(8.4, 4.8))
    ax.bar(FAMILIES, counts["positive"], color="#2A9D8F", label="Robust positive")
    ax.bar(FAMILIES, -counts["negative"], color="#D65A4A", label="Robust negative")
    ax.axhline(0, color="black", lw=1)
    ax.set_ylabel("Number of robust frequency features")
    ax.set_title("Frequency-feature localization after 312-test FDR")
    ax.legend(frameon=False)
    save_figure(fig, sections["features"].figures / "Fig2_五家族稳健频率特征数")

    fig, ax = plt.subplots(figsize=(9.2, 5.2))
    for family in FAMILIES:
        subset = trajectory[trajectory["cfc_family"].eq(family)].sort_values("window_order")
        x = subset["window_order"].to_numpy()
        ax.plot(x, subset["median_effect"], marker="o", lw=2, color=colors[family], label=family)
        ax.fill_between(x, subset["ci95_low"], subset["ci95_high"], color=colors[family], alpha=0.13)
    ax.axhline(0, color="black", lw=1, ls="--")
    ax.axvline(2.5, color="#64748B", lw=1.2, ls=":")
    ax.set_xticks(range(6), [WINDOW_LABELS[w] for w in WINDOWS], rotation=20)
    ax.set_ylabel("SOZ - NSOZ family-level standardized CFC")
    ax.set_title("Six-window onset-locked spatial trajectories (matched patients)")
    ax.legend(frameon=False, ncol=2)
    save_figure(fig, sections["trajectory"].figures / "Fig3_六窗五家族空间轨迹")

    ordered_pre = pretrend.set_index("cfc_family").reindex(FAMILIES)
    fig, ax = plt.subplots(figsize=(8.2, 4.6))
    ax.errorbar(
        ordered_pre["median_effect"], y,
        xerr=np.vstack([ordered_pre["median_effect"] - ordered_pre["ci95_low"], ordered_pre["ci95_high"] - ordered_pre["median_effect"]]),
        fmt="o", color="#7C3AED", capsize=3
    )
    ax.axvline(0, color="black", lw=1, ls="--")
    ax.set_yticks(y, FAMILIES)
    ax.invert_yaxis()
    ax.set_xlabel("Pre-onset trend per 10-s step")
    ax.set_title("Pre-onset trend across three windows")
    save_figure(fig, sections["trajectory"].figures / "Fig4_发作前三窗趋势")

    overall_pairs = pairwise[pairwise["scope"].eq("Overall")]
    fig, ax = plt.subplots(figsize=(7.4, 4.5))
    ax.bar(overall_pairs["comparison"], overall_pairs["spearman_rho"], color="#3B82B6")
    ax.axhline(0, color="black", lw=1)
    ax.set_ylim(-0.2, 1.0)
    ax.set_ylabel("Spearman rho")
    ax.set_title("Cross-cohort dynamic-map agreement")
    ax.tick_params(axis="x", rotation=15)
    save_figure(fig, sections["transport"].figures / "Fig5_动态图谱跨队列相关")

    overall_reliability = reliability[reliability["scope"].eq("Overall")].set_index("dataset_id").reindex(COHORTS)
    fig, ax = plt.subplots(figsize=(7.6, 4.6))
    ax.bar(COHORTS, overall_reliability["split_half_rho_median"], color="#6B8E9B")
    ax.errorbar(
        np.arange(3), overall_reliability["split_half_rho_median"],
        yerr=np.vstack([
            overall_reliability["split_half_rho_median"] - overall_reliability["ci95_low"],
            overall_reliability["ci95_high"] - overall_reliability["split_half_rho_median"],
        ]), fmt="none", color="black", capsize=3
    )
    ax.axhline(0, color="black", lw=1)
    ax.set_ylim(-0.2, 1.0)
    ax.set_ylabel("Median split-half Spearman rho")
    ax.set_title("Within-cohort reliability ceiling of dynamic maps")
    save_figure(fig, sections["transport"].figures / "Fig6_动态图谱队列内可靠性")

    selected_sources = sources[sources["source_metric"].isin(["z_value", "observed_value", "surrogate_std"])]
    fig, axes = plt.subplots(1, 3, figsize=(13.2, 4.2), sharey=True)
    for ax, source_name in zip(axes, ["z_value", "observed_value", "surrogate_std"]):
        subset = selected_sources[selected_sources["source_metric"].eq(source_name)].set_index("cfc_family").reindex(FAMILIES)
        ax.axvline(0, color="black", lw=1, ls="--")
        ax.errorbar(
            subset["median_effect"], y,
            xerr=np.vstack([subset["median_effect"] - subset["ci95_low"], subset["ci95_high"] - subset["median_effect"]]),
            fmt="o", color="#334155", capsize=2
        )
        ax.set_title(source_name)
        ax.set_yticks(y, FAMILIES)
        ax.invert_yaxis()
    fig.suptitle("Source decomposition of standardized dynamic effects", y=1.02)
    save_figure(fig, sections["sources"].figures / "Fig7_标准化来源分解")

    selected = sensitivity[sensitivity["cfc_family"].isin(["PAC", "CFC_coherence"])]
    fig, ax = plt.subplots(figsize=(9.2, 4.8))
    analyses = list(selected["analysis"].drop_duplicates())
    x = np.arange(len(analyses))
    width = 0.34
    for offset, family in zip([-width / 2, width / 2], ["PAC", "CFC_coherence"]):
        subset = selected[selected["cfc_family"].eq(family)].set_index("analysis").reindex(analyses)
        ax.bar(x + offset, subset["median_effect"], width, label=family, color=colors[family])
    ax.axhline(0, color="black", lw=1)
    ax.set_xticks(x, analyses, rotation=18, ha="right")
    ax.set_ylabel("Median early interaction")
    ax.set_title("Cached-data sensitivity checks for primary positive families")
    ax.legend(frameon=False)
    save_figure(fig, sections["sensitivity"].figures / "Fig8_主要阳性家族敏感性")


def markdown_table(frame: pd.DataFrame, columns: list[str], digits: int = 3) -> str:
    table = frame[columns].copy()
    for column in table.columns:
        if pd.api.types.is_float_dtype(table[column]):
            table[column] = table[column].map(lambda value: "NA" if not np.isfinite(value) else f"{value:.{digits}f}")
    headers = "| " + " | ".join(columns) + " |"
    separator = "|" + "|".join(["---"] * len(columns)) + "|"
    rows = ["| " + " | ".join(map(str, row)) + " |" for row in table.itertuples(index=False, name=None)]
    return "\n".join([headers, separator] + rows)


def write_report(
    root: Path,
    primary: pd.DataFrame,
    equal: pd.DataFrame,
    global_test: pd.DataFrame,
    leave_one: pd.DataFrame,
    features: pd.DataFrame,
    trajectory: pd.DataFrame,
    pretrend: pd.DataFrame,
    pairwise: pd.DataFrame,
    loco: pd.DataFrame,
    reliability: pd.DataFrame,
    sources: pd.DataFrame,
    sensitivity: pd.DataFrame,
    pending: pd.DataFrame,
) -> None:
    pooled = primary[primary["analysis_group"].eq("Pooled_patients")].set_index("cfc_family").reindex(FAMILIES).reset_index()
    feature_pooled = features[features["analysis_group"].eq("Pooled_patients")]
    feature_counts = (
        feature_pooled.groupby("cfc_family", observed=True)
        .agg(
            total_features=("feature_id", "size"),
            robust_positive=("robust_positive", "sum"),
            robust_negative=("robust_negative", "sum"),
            same_direction=("evidence_tier", lambda x: int(np.sum(x.isin(["Directionally_supported", "Robust_frequency_localization"])))),
        )
        .reindex(FAMILIES)
        .reset_index()
    )
    overall_pairs = pairwise[pairwise["scope"].eq("Overall")]
    overall_loco = loco[loco["scope"].eq("Overall")]
    overall_reliability = reliability[reliability["scope"].eq("Overall")]
    source_selected = sources[sources["cfc_family"].isin(["PAC", "CFC_coherence", "AAC", "Bicoherence"])]

    report = f"""# 新版实验三详细实验报告

生成时间：{datetime.now().isoformat(timespec='seconds')}

## 一、实验目的

本实验在实验一静态 SOZ--NSOZ 差异和实验二跨队列静态迁移结果的基础上，检验发作起始前后 SOZ 相对 NSOZ 的 CFC 差异是否发生改变。主效应定义为：

`[(SOZ-NSOZ) 0--10 s] - [(SOZ-NSOZ) -10--0 s]`。

统计单位始终为患者。跨队列主推断增加中心等权置换，患者合并结果作为敏感性分析。精细动态频率图谱和 LOCO 被明确列为探索性结果，不用于证明传播机制。

## 二、五家族早期交互

{markdown_table(pooled, ['cfc_family','n_patients','median_effect','ci95_low','ci95_high','q_value','rank_biserial','positive_fraction'])}

![五家族合并与中心等权森林图](02_三队列独立与中心等权推断/02_结果图/Fig1_五家族合并与中心等权森林图.png)

## 三、中心等权与联合家族检验

{markdown_table(equal, ['cfc_family','center_equal_effect','ci95_low','ci95_high','q_value','all_cohorts_same_direction','robust_center_equal'])}

联合特征符号翻转检验在患者层面对一个家族内全部频率特征共同翻转，从而保留特征间相关结构：

{markdown_table(global_test, ['cfc_family','n_features','global_center_equal_statistic','global_sign_flip_p_value','q_value'])}

留一队列结果保存在 `02_三队列独立与中心等权推断/01_统计数据/留一队列家族稳健性.csv`。该结果用于检查结论是否被单个队列驱动，不称为独立外部验证。

## 四、312特征频率图谱

{markdown_table(feature_counts, ['cfc_family','total_features','robust_positive','robust_negative','same_direction'], digits=0)}

![五家族稳健频率特征数](03_312特征频率图谱/02_结果图/Fig2_五家族稳健频率特征数.png)

频率特征仅用于定位家族效应来源。由于五类 CFC 的特征数不同，显著特征数量不能直接作为家族生物学重要性的排序。

## 五、六窗动态与发作前趋势

![六窗五家族空间轨迹](04_六时间窗动态与发作前趋势/02_结果图/Fig3_六窗五家族空间轨迹.png)

![发作前三窗趋势](04_六时间窗动态与发作前趋势/02_结果图/Fig4_发作前三窗趋势.png)

发作前趋势检验：

{markdown_table(pretrend, ['cfc_family','n_patients','median_effect','ci95_low','ci95_high','q_value','friedman_p_value'], digits=4)}

六窗轨迹使用匹配患者。15项发作后相对近端发作前检验以及持续至少30秒严格子集结果均已单独保存。即使20--30秒继续增强，也只解释为起始锁定的持续演变，不解释为传播。

## 六、动态跨队列稳健性

{markdown_table(overall_pairs, ['comparison','spearman_rho','direction_agreement','median_absolute_difference'])}

{markdown_table(overall_loco, ['heldout_cohort','spearman_rho','ci95_low','ci95_high','direction_agreement'])}

队列内可靠性：

{markdown_table(overall_reliability, ['dataset_id','n_patients','split_half_rho_median','ci95_low','ci95_high','spearman_brown'])}

![动态图谱跨队列相关](05_跨队列动态稳健性/02_结果图/Fig5_动态图谱跨队列相关.png)

![动态图谱队列内可靠性](05_跨队列动态稳健性/02_结果图/Fig6_动态图谱队列内可靠性.png)

动态图谱跨队列相关必须结合队列内可靠性解释。若队列内分半相关本身较低，跨队列相关偏低不能单独归因于中心生理差异。

## 七、标准化来源

![标准化来源分解](06_标准化来源诊断/02_结果图/Fig7_标准化来源分解.png)

{markdown_table(source_selected, ['source_metric','cfc_family','median_effect','ci95_low','ci95_high','q_value'])}

只有 observed value 与标准化 Z 同方向，而 surrogate mean 和 surrogate SD 未出现足以解释结果的变化时，才能形成较完整的动态证据链。

## 八、敏感性分析

![主要阳性家族敏感性](07_关键敏感性分析/02_结果图/Fig8_主要阳性家族敏感性.png)

本轮已经运行现有冻结数据能够支持的均值层级、明确持续至少30秒和排除150--200 Hz分析。以下分析需要重新读取原始信号，未伪造结果：

{markdown_table(pending, ['analysis','status','planned_scope'])}

## 九、结论边界

本实验可以检验发作起始后 SOZ 相对 CFC 是否增强，以及这种家族级方向是否跨队列一致。它不能单独证明 CFC 从 SOZ 向 NSOZ 传播，也不能在尖波、谐波、功率和参考敏感性完成前，将 PAC 增强直接解释为真实振荡间机制。

## 十、文件导航

- `01_早期五家族区域时间交互`：患者级家族效应与合并/分队列统计。
- `02_三队列独立与中心等权推断`：中心等权、联合家族检验和留一队列结果。
- `03_312特征频率图谱`：完整特征统计和证据分层。
- `04_六时间窗动态与发作前趋势`：六窗轨迹、15项检验和发作前趋势。
- `05_跨队列动态稳健性`：两两相关、LOCO和队列内可靠性。
- `06_标准化来源诊断`：observed与surrogate来源分解。
- `07_关键敏感性分析`：已完成敏感性与原始信号待运行项目。
- `08_正式报告与汇总`：运行清单、校验值和总图表副本。
"""
    (root / "实验三_详细实验报告.md").write_text(report, encoding="utf-8")


def write_static_docs(root: Path) -> None:
    readme = """# 010 新实验三说明

本目录是重新规划后的实验三独立归档，不覆盖 `09_实验三_发作起始前后区域特异性CFC变化`。

第一轮使用旧实验三中已经通过质量控制的患者级六窗标准化数据，新增中心等权推断、家族联合置换、发作前趋势、留一队列稳健性和队列内可靠性。需要重新读取原始信号的保护窗、功率、尖波/谐波和参考方式分析被单独列入待运行状态，不会用近似结果替代。

每个分析部分均分为：

- `01_统计数据`
- `02_结果图`
- `03_分析代码`

运行入口为根目录 `run_new_experiment3.ps1`。
"""
    plan = """# 新版实验三冻结方案

## 主问题

检验发作前 `-10--0 s` 到发作后 `0--10 s`，SOZ 相对 NSOZ 的五类 CFC 是否改变。

## 主效应

`I = [(SOZ-NSOZ) 0--10 s] - [(SOZ-NSOZ) -10--0 s]`

## 推断层级

1. 五家族中心等权患者级置换为跨队列主推断。
2. 81例患者合并分析为总体敏感性结果。
3. 三队列分别报告，并执行留一队列稳健性分析。
4. 312特征为频率定位层。
5. 六窗轨迹为次级动态描述。
6. 动态图谱LOCO为探索性结果，必须结合队列内可靠性解释。

## 多重比较

- 五家族主检验：5项BH-FDR。
- 312特征：312项统一BH-FDR。
- 三个发作后窗口乘五家族：15项统一BH-FDR。
- 其余诊断和敏感性分析单独标记，不与主检验混写。

## 结论边界

不称为传播机制，不称为完全独立外部验证。在功率、尖波/谐波和参考敏感性完成前，不把PAC增强直接解释为真实振荡间机制。
"""
    (root / "README_说明.md").write_text(readme, encoding="utf-8")
    (root / "实验三_正式方案.md").write_text(plan, encoding="utf-8")


def copy_code_and_figures(root: Path, sections: dict[str, Section], script_path: Path) -> None:
    for section in sections.values():
        shutil.copy2(script_path, section.code / script_path.name)
    report_figures = sections["report"].figures
    for key, section in sections.items():
        if key == "report":
            continue
        for figure in section.figures.glob("*.png"):
            shutil.copy2(figure, report_figures / figure.name)


def write_manifest(root: Path, inputs: Inputs, args: argparse.Namespace) -> None:
    files = []
    for path in sorted(root.rglob("*")):
        if path.is_file():
            files.append(
                {
                    "relative_path": str(path.relative_to(root)),
                    "size_bytes": path.stat().st_size,
                    "sha256": sha256(path),
                }
            )
    pd.DataFrame(files).to_csv(root / "文件清单与校验值.csv", index=False, encoding="utf-8-sig")
    metadata = {
        "status": "complete_cached_patient_level_stage",
        "completed_at": datetime.now().isoformat(timespec="seconds"),
        "source_experiment": str(args.source_experiment),
        "output_root": str(root),
        "bootstrap_repeats": args.bootstrap_repeats,
        "permutation_repeats": args.permutation_repeats,
        "global_permutation_repeats": args.global_permutation_repeats,
        "split_half_repeats": args.split_half_repeats,
        "loco_bootstrap_repeats": args.loco_bootstrap_repeats,
        "seed": args.seed,
        "python": sys.version,
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "scipy": scipy.__version__,
        "inputs": {
            key: {"path": str(path), "sha256": sha256(path)}
            for key, path in inputs.__dict__.items()
            if isinstance(path, Path) and path.is_file()
        },
    }
    (root / "run_status.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> None:
    warnings.filterwarnings("ignore", category=RuntimeWarning)
    args = parse_args()
    inputs = locate_inputs(args.source_experiment)
    sections = make_structure(args.output_root)
    write_static_docs(args.output_root)

    print("[1/8] Loading validated patient-level inputs...", flush=True)
    early = pd.read_parquet(inputs.early)
    spatial = pd.read_parquet(inputs.spatial)
    catalog = pd.read_csv(inputs.catalog)
    mean_spatial = pd.read_parquet(inputs.mean_spatial)
    confirmed_spatial = pd.read_parquet(inputs.confirmed_spatial)

    print("[2/8] Running five-family early interaction...", flush=True)
    patient, primary = run_primary(
        early, sections["primary"], args.bootstrap_repeats, args.seed
    )

    print("[3/8] Running cohort-equal and global family inference...", flush=True)
    equal, global_test, leave_one = run_cohort_inference(
        early,
        patient,
        sections["cohort"],
        args.bootstrap_repeats,
        args.permutation_repeats,
        args.global_permutation_repeats,
        args.seed + 1000,
    )

    print("[4/8] Running 312-feature localization...", flush=True)
    features = run_features(
        early, catalog, sections["features"], args.bootstrap_repeats, args.seed + 2000
    )

    print("[5/8] Running six-window trajectories and pre-onset trends...", flush=True)
    family_trajectory, trajectory, pretrend = run_trajectory(
        spatial,
        confirmed_spatial,
        sections["trajectory"],
        args.bootstrap_repeats,
        args.seed + 3000,
    )

    print("[6/8] Running dynamic transportability and reliability...", flush=True)
    pairwise, loco, reliability = run_transportability(
        early,
        catalog,
        sections["transport"],
        args.split_half_repeats,
        args.loco_bootstrap_repeats,
        args.seed + 4000,
    )

    print("[7/8] Running source decomposition and cached sensitivities...", flush=True)
    sources = run_sources(
        early, sections["sources"], args.bootstrap_repeats, args.seed + 5000
    )
    sensitivity, pending = run_cached_sensitivity(
        early,
        mean_spatial,
        confirmed_spatial,
        catalog,
        sections["sensitivity"],
        args.bootstrap_repeats,
        args.seed + 6000,
    )

    print("[8/8] Rendering figures, report, and manifest...", flush=True)
    make_figures(
        primary,
        equal,
        features,
        trajectory,
        pretrend,
        pairwise,
        reliability,
        sources,
        sensitivity,
        sections,
    )
    write_report(
        args.output_root,
        primary,
        equal,
        global_test,
        leave_one,
        features,
        trajectory,
        pretrend,
        pairwise,
        loco,
        reliability,
        sources,
        sensitivity,
        pending,
    )
    copy_code_and_figures(args.output_root, sections, Path(__file__))
    write_manifest(args.output_root, inputs, args)
    print(json.dumps({"status": "complete", "output_root": str(args.output_root)}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
