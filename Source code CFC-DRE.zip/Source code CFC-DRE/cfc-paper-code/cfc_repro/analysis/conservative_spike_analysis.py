"""Paired comparison of conservative spike-masked PAC with the main pipeline.

Scientific definitions follow the frozen author analysis; see REPRODUCE.md.
"""
from __future__ import annotations

import shutil
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy.stats as stats

from . import raw_sensitivity_analysis as raw_analysis


COHORTS = raw_analysis.COHORTS


WORK = Path("outputs")
RAW = WORK / "exp3_conservative_spike" / "raw_cache"
ROOT = Path("outputs/dynamics")
SECTION = ROOT / "07_关键敏感性分析"
DATA_OUT = SECTION / "01_统计数据"
FIG_OUT = SECTION / "02_结果图"
CODE_OUT = SECTION / "03_分析代码"


def aggregate() -> tuple[pd.DataFrame, pd.DataFrame]:
    feature_parts = []
    audit_parts = []
    patient_dirs = sorted({p.parent for p in RAW.rglob("*_conservative_spike_PAC.parquet")})
    for i, patient_dir in enumerate(patient_dirs, 1):
        files = sorted(patient_dir.glob("*_conservative_spike_PAC.parquet"))
        frame = pd.concat([pd.read_parquet(p) for p in files], ignore_index=True)
        frame = frame[frame["soz_label"].isin(["SOZ", "NSOZ"]) & frame["finite_pass"].eq(1)].copy()
        frame["channel_key"] = frame["channel_index_1based"].astype(str) + "|" + frame["channel_name"].astype(str)

        audit_cols = ["dataset_id", "patient_id", "recording_id", "channel_key", "window_id",
                      "spike_event_count", "spike_event_rate_hz", "spike_mask_fraction", "median_peak_score"]
        audit_parts.append(frame[audit_cols].drop_duplicates())

        contact_keys = ["dataset_id", "patient_id", "channel_key", "soz_label", "window_id", "method", "feature_id"]
        contact = frame.groupby(contact_keys, observed=True)["z_value"].median().reset_index()
        zone_keys = ["dataset_id", "patient_id", "soz_label", "window_id", "method", "feature_id"]
        zone = contact.groupby(zone_keys, observed=True)["z_value"].median().reset_index()
        spatial = zone.pivot(index=["dataset_id", "patient_id", "window_id", "method", "feature_id"],
                             columns="soz_label", values="z_value").reset_index().dropna(subset=["SOZ", "NSOZ"])
        spatial["spatial_effect"] = spatial["SOZ"] - spatial["NSOZ"]
        keys = ["dataset_id", "patient_id", "method", "feature_id"]
        pre = spatial[spatial["window_id"].eq("pre_cumulative_10")][keys + ["spatial_effect"]].rename(
            columns={"spatial_effect": "spatial_effect_pre"})
        post = spatial[spatial["window_id"].eq("post_cumulative_10")][keys + ["spatial_effect"]].rename(
            columns={"spatial_effect": "spatial_effect_post"})
        paired = pre.merge(post, on=keys, validate="one_to_one")
        paired["interaction"] = paired["spatial_effect_post"] - paired["spatial_effect_pre"]
        feature_parts.append(paired)
        print(f"aggregate {i}/{len(patient_dirs)} {patient_dir.name}", flush=True)

    features = pd.concat(feature_parts, ignore_index=True)
    features["analysis_id"] = "conservative_spike_masked"
    features["cfc_family"] = "PAC"
    family = (features.groupby(["analysis_id", "dataset_id", "patient_id", "cfc_family"], observed=True)["interaction"]
              .median().rename("family_interaction").reset_index())
    audit = pd.concat(audit_parts, ignore_index=True).drop_duplicates()
    return features, family, audit


def find_baseline() -> pd.DataFrame:
    path = ROOT / "01_早期五家族区域时间交互" / "01_统计数据" / "患者级五家族早期交互.csv"
    return pd.read_csv(path).query("cfc_family == 'PAC'").copy()


def comparison(baseline: pd.DataFrame, family: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    merged = baseline.merge(family, on=["dataset_id", "patient_id", "cfc_family"], validate="one_to_one",
                            suffixes=("_baseline", "_conservative"))
    merged = merged.rename(columns={"family_interaction_baseline": "baseline_effect",
                                    "family_interaction_conservative": "conservative_effect"})
    merged["difference"] = merged["conservative_effect"] - merged["baseline_effect"]
    rows = []
    for group in ("Overall",) + COHORTS:
        part = merged if group == "Overall" else merged[merged["dataset_id"].eq(group)]
        rho, rho_p = stats.spearmanr(part["baseline_effect"], part["conservative_effect"])
        diff = part["difference"].to_numpy(float)
        paired_p = stats.wilcoxon(diff).pvalue if not np.allclose(diff, 0) else 1.0
        rows.append({
            "analysis_group": group,
            "n_patients": len(part),
            "baseline_median": part["baseline_effect"].median(),
            "conservative_median": part["conservative_effect"].median(),
            "median_change": np.median(diff),
            "spearman_rho": rho,
            "spearman_p": rho_p,
            "sign_agreement": np.mean(np.sign(part["baseline_effect"]) == np.sign(part["conservative_effect"])),
            "conservative_positive_fraction": np.mean(part["conservative_effect"] > 0),
            "paired_difference_p": paired_p,
        })
    return merged, pd.DataFrame(rows)


def audit_summary(audit: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for group in ("Overall",) + COHORTS:
        part = audit if group == "Overall" else audit[audit["dataset_id"].eq(group)]
        values = part["spike_mask_fraction"].to_numpy(float)
        rows.append({
            "analysis_group": group,
            "n_recording_channels_windows": len(part),
            "mean_mask_fraction": np.mean(values),
            "median_mask_fraction": np.median(values),
            "p90_mask_fraction": np.quantile(values, .90),
            "p95_mask_fraction": np.quantile(values, .95),
            "fraction_over_5pct": np.mean(values > .05),
            "fraction_over_10pct": np.mean(values > .10),
            "fraction_over_20pct": np.mean(values > .20),
            "median_event_rate_hz": np.median(part["spike_event_rate_hz"]),
        })
    return pd.DataFrame(rows)


def plot_comparison(merged: pd.DataFrame) -> None:
    colors = {"Lanzhou": "#2E86AB", "ds003029": "#F18F01", "ds004100": "#3A9D5D"}
    fig, ax = plt.subplots(figsize=(6.2, 5.2))
    for cohort, part in merged.groupby("dataset_id"):
        ax.scatter(part["baseline_effect"], part["conservative_effect"], s=38, alpha=.8,
                   color=colors[cohort], label=f"{cohort} (n={len(part)})")
    lo = min(merged[["baseline_effect", "conservative_effect"]].min())
    hi = max(merged[["baseline_effect", "conservative_effect"]].max())
    ax.plot([lo, hi], [lo, hi], "--", color="#6B7280", lw=1)
    ax.axhline(0, color="#9CA3AF", lw=.8)
    ax.axvline(0, color="#9CA3AF", lw=.8)
    rho = stats.spearmanr(merged["baseline_effect"], merged["conservative_effect"]).statistic
    ax.set(xlabel="Primary PAC family interaction", ylabel="Conservative spike-masked PAC interaction",
           title=f"Conservative spike sensitivity (Spearman rho={rho:.3f})")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG_OUT / "Fig12_保守尖波遮罩PAC与主分析一致性.png", dpi=300)
    fig.savefig(FIG_OUT / "Fig12_保守尖波遮罩PAC与主分析一致性.pdf")
    plt.close(fig)


def main() -> None:
    DATA_OUT.mkdir(parents=True, exist_ok=True)
    FIG_OUT.mkdir(parents=True, exist_ok=True)
    CODE_OUT.mkdir(parents=True, exist_ok=True)
    features, family, audit = aggregate()
    baseline = find_baseline()
    raw_analysis.FAMILIES = ("PAC",)
    stats_frame = raw_analysis.family_statistics(family, seed=20260919)
    cohort_equal = raw_analysis.cohort_equal_statistics(family, seed=20260920)
    stats_frame = stats_frame[stats_frame["cfc_family"].eq("PAC")].reset_index(drop=True)
    cohort_equal = cohort_equal[cohort_equal["cfc_family"].eq("PAC")].reset_index(drop=True)
    merged, compare = comparison(baseline, family)
    audit_stats = audit_summary(audit)

    features.to_parquet(DATA_OUT / "保守尖波遮罩PAC_患者级45特征.parquet", index=False)
    family.to_csv(DATA_OUT / "保守尖波遮罩PAC_患者级家族效应.csv", index=False, encoding="utf-8-sig")
    stats_frame.to_csv(DATA_OUT / "保守尖波遮罩PAC_合并与分队列统计.csv", index=False, encoding="utf-8-sig")
    cohort_equal.to_csv(DATA_OUT / "保守尖波遮罩PAC_中心等权推断.csv", index=False, encoding="utf-8-sig")
    merged.to_csv(DATA_OUT / "保守尖波遮罩PAC_与主结果患者级对照.csv", index=False, encoding="utf-8-sig")
    compare.to_csv(DATA_OUT / "保守尖波遮罩PAC_与主结果一致性统计.csv", index=False, encoding="utf-8-sig")
    audit.to_parquet(DATA_OUT / "保守尖波遮罩_逐记录通道窗口审计.parquet", index=False)
    audit_stats.to_csv(DATA_OUT / "保守尖波遮罩_遮罩负担汇总.csv", index=False, encoding="utf-8-sig")
    plot_comparison(merged)
    shutil.copy2(Path(__file__), CODE_OUT / Path(__file__).name)
    print("\n=== FAMILY STATS ===")
    print(stats_frame.to_string(index=False))
    print("\n=== COHORT EQUAL ===")
    print(cohort_equal.to_string(index=False))
    print("\n=== COMPARISON ===")
    print(compare.to_string(index=False))
    print("\n=== MASK AUDIT ===")
    print(audit_stats.to_string(index=False))


if __name__ == "__main__":
    main()
