"""Frozen patient-level inference and publication plotting implementations."""

