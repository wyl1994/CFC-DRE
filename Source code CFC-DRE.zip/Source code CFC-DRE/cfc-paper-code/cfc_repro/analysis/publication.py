"""Publication panels organized by estimand; no inference is recomputed here."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm, Normalize
from matplotlib.patches import Patch

PROJECT = Path('outputs/publication')
FAMILIES = ['PAC','PPC','AAC','Bicoherence','CFC_coherence']
LABELS = ['PAC','PPC','AAC','Bicoherence','CFC coherence']
COHORTS = ['Lanzhou','ds003029','ds004100']
PAIRS = ['Lanzhou vs ds003029','Lanzhou vs ds004100','ds003029 vs ds004100']
BANDS = ['delta','theta','alpha','beta','low_gamma','high_gamma','ripple','fast_ripple_low']
BAND_LABELS = ['D','T','A','B','LG','HG','R1','R2']
SOZ, NSOZ = '#B54A3A', '#26759A'

def style():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.labelsize':9,
        'axes.titlesize':10,'xtick.labelsize':9,'ytick.labelsize':9,'axes.linewidth':.65,
        'pdf.fonttype':42,'ps.fonttype':42,'savefig.facecolor':'white'})

def save(fig,name):
    fig.savefig(PROJECT/'figures'/'main'/(name+'.pdf'))
    preview = PROJECT.parent / 'previews'
    preview.mkdir(exist_ok=True)
    fig.savefig(preview/(name+'.png'),dpi=250)
    plt.close(fig)

def panel(ax,title):
    ax.set_title(title,loc='left',fontweight='bold',pad=8)

def frequency_grid(frame,family):
    method={'PAC':'tort_mi','AAC':'spearman'}.get(family)
    if method: frame=frame[frame.method==method]
    parts=[s.split('|') for s in frame.feature_id]
    if family in ['PAC','CFC_coherence']:
        xs,ys=BANDS[4:],BANDS[:4]; xl,yl=BAND_LABELS[4:],BAND_LABELS[:4]
        coords=[(p[-1],p[-2]) for p in parts]
    elif family=='AAC':
        xs=ys=BANDS; xl=yl=BAND_LABELS; coords=[(p[-1],p[-2]) for p in parts]
    else:
        xs=sorted({float(p[2]) for p in parts}); ys=sorted({float(p[1]) for p in parts})
        xl=[f'{x:g}' for x in xs]; yl=[f'{y:g}' for y in ys]
        coords=[(float(p[2]),float(p[1])) for p in parts]
    mat=np.full((len(ys),len(xs)),np.nan)
    for (x,y),v in zip(coords,frame.median_difference): mat[ys.index(y),xs.index(x)]=v
    return mat,xl,yl

def fig2(spatial):
    fig=plt.figure(figsize=(7.16,7.05))
    cmap=plt.get_cmap('RdBu_r').copy(); cmap.set_bad('#E5E7E9')
    grid=fig.add_gridspec(5,4,left=.105,right=.925,top=.902,bottom=.10,
        width_ratios=[1,1,1,.045],wspace=.22,hspace=.70)
    for i,f in enumerate(FAMILIES):
        matrices=[frequency_grid(spatial[(spatial.analysis_group==c)&(spatial.cfc_family==f)],f) for c in COHORTS]
        limit=max(np.nanmax(np.abs(m[0])) for m in matrices)
        for j,(mat,xl,yl) in enumerate(matrices):
            ax=fig.add_subplot(grid[i,j])
            im=ax.pcolormesh(np.arange(mat.shape[1]+1)-.5,
                np.arange(mat.shape[0]+1)-.5, np.ma.masked_invalid(mat),
                cmap=cmap,norm=TwoSlopeNorm(0,-limit,limit),rasterized=False)
            ax.set_facecolor('#E5E7E9')
            xi=np.arange(len(xl)) if len(xl)<=8 else np.arange(0,len(xl),3)
            yi=np.arange(len(yl)) if len(yl)<=8 else np.arange(0,len(yl),3)
            ax.set_xticks(xi,[xl[k] for k in xi]); ax.set_yticks(yi,[yl[k] for k in yi])
            ax.tick_params(length=2,pad=1,labelsize=8.5)
            if i==0:
                box=ax.get_position(); fig.text((box.x0+box.x1)/2,.965,COHORTS[j],ha='center',fontweight='bold')
            if j==0:
                title=f'({chr(97+i)}) '+LABELS[i]+{'PAC':' (Tort MI)','AAC':' (Spearman)'}.get(f,'')
                ax.text(0,1.14,title,transform=ax.transAxes,fontweight='bold',fontsize=9.5)
            if f in ['PPC','Bicoherence']:
                ax.set_xlabel('Higher frequency (Hz)' if f=='PPC' else '$f_2$ (Hz)',fontsize=8.5,labelpad=1)
                if j==0: ax.set_ylabel('Lower f (Hz)' if f=='PPC' else '$f_1$ (Hz)',fontsize=8.5,labelpad=1)
            elif f in ['PAC','CFC_coherence']:
                ax.set_xlabel('Amplitude band' if f=='PAC' else 'High-frequency carrier band',fontsize=8,labelpad=2)
                if j==0:
                    ax.set_ylabel('Phase band' if f=='PAC' else 'Low-frequency signal band',fontsize=8,labelpad=2)
            for spine in ax.spines.values(): spine.set_linewidth(.5)
        cb=fig.colorbar(im,cax=fig.add_subplot(grid[i,3]),ticks=[-limit,0,limit])
        cb.solids.set_rasterized(False)
        cb.ax.set_yticklabels([f'{-limit:.2g}','0',f'{limit:.2g}']); cb.ax.tick_params(labelsize=8.5,length=2,pad=2)
    fig.text(.515,.04,'Color: median patient SOZ - NSOZ contrast (standardized CFC)',ha='center',fontsize=9)
    fig.legend(handles=[Patch(facecolor='#E5E7E9',label='Not evaluated')],loc='lower left',bbox_to_anchor=(.105,.002),frameon=False,fontsize=8.5)
    save(fig,'Fig02_Frequency_Resolved_Regional_Contrasts')

def matrix(ax,values,rows,columns,vmin,vmax,cmap='YlGnBu',fmt='.2f',percent=False):
    values=np.asarray(values)
    im=ax.pcolormesh(np.arange(values.shape[1]+1)-.5,
        np.arange(values.shape[0]+1)-.5,values,cmap=cmap,vmin=vmin,vmax=vmax,rasterized=False)
    ax.set_ylim(len(rows)-.5,-.5)
    ax.set_yticks(range(len(rows)),rows); ax.set_xticks(range(len(columns)),columns)
    ax.tick_params(length=0,pad=5)
    ax.set_xticks(np.arange(-.5,len(columns),1),minor=True)
    ax.set_yticks(np.arange(-.5,len(rows),1),minor=True)
    ax.grid(which='minor',color='white',lw=1.8); ax.tick_params(which='minor',length=0)
    for spine in ax.spines.values(): spine.set_visible(False)
    colors=plt.get_cmap(cmap); norm=Normalize(vmin,vmax)
    for (i,j),val in np.ndenumerate(values):
        r,g,b,_=colors(norm(val)); luminance=.2126*r+.7152*g+.0722*b
        text=(f'{val:.4f}' if fmt=='.3f' and 0<abs(val)<.0005 else f'{val:{fmt}}')+('%' if percent else '')
        ax.text(j,i,text,ha='center',va='center',fontsize=9,color='white' if luminance<.46 else '#17242B')
    return im

def fig3(pair,loco,candidates):
    fig=plt.figure(figsize=(7.16,5.9))
    axa=fig.add_axes([.17,.59,.30,.32]); axb=fig.add_axes([.66,.59,.30,.32])
    axc=fig.add_axes([.17,.15,.30,.28]); axd=fig.add_axes([.66,.19,.30,.22])
    scopes=['All 312 features']+FAMILIES; labels=['All features']+LABELS
    values=lambda frame,group,keys,column: [[frame[(frame[group]==g)&(frame.scope_name==f)].iloc[0][column] for g in keys] for f in scopes]
    rho=values(pair,'comparison',PAIRS,'spearman_rho')
    direction=np.array(values(pair,'comparison',PAIRS,'direction_agreement'))*100
    im=matrix(axa,rho,labels,['LZ /\n3029','LZ /\n4100','3029 /\n4100'],-1,1,'RdBu_r')
    panel(axa,'(a) Pairwise map correlation')
    matrix(axb,direction,labels,['LZ /\n3029','LZ /\n4100','3029 /\n4100'],0,100,'YlGnBu','.1f',True)
    panel(axb,'(b) Pairwise sign agreement')
    matrix(axc,values(loco,'heldout_cohort',COHORTS,'spearman_rho'),labels,['LZ','3029','4100'],-1,1,'RdBu_r')
    axc.set_xlabel('Held-out cohort'); panel(axc,'(c) Held-out map correlation')
    rows=candidates[(candidates.cfc_family=='Overall')&(candidates.candidate_direction=='SOZ')].set_index('heldout_cohort').loc[COHORTS]
    left=np.zeros(3); colors=['#26757A','#CBD0D3','#B55343']
    for col,color in zip(['n_validation_passed','n_direction_only','n_reversed'],colors):
        widths=100*rows[col].values/rows.n_candidates.values
        axd.barh(range(3),widths,left=left,height=.49,color=color,edgecolor='white',linewidth=.5)
        if col=='n_validation_passed':
            for i,n in enumerate(rows[col]): axd.text(widths[i]/2,i,str(n),ha='center',va='center',color='white',fontsize=9)
        left+=widths
    axd.set_yticks(range(3),[f'{c} ({n})' for c,n in zip(['LZ','3029','4100'],rows.n_candidates)]); axd.invert_yaxis(); axd.set_xlim(0,100); axd.set_xticks([0,50,100])
    axd.set_xlabel('Discovery candidates (%)',labelpad=2)
    axd.spines[['top','right','left']].set_visible(False); axd.tick_params(axis='y',length=0)
    axd.text(0,1.16,'(d) Held-out candidate status',transform=axd.transAxes,fontweight='bold',fontsize=10)
    fig.legend([Patch(facecolor=c) for c in colors],['Passed','Same sign only','Reversed'],loc='lower center',bbox_to_anchor=(.55,.015),ncol=3,frameon=False,fontsize=9)
    save(fig,'Fig03_Cross_Cohort_Replication')

def fig4(primary,traj):
    fig=plt.figure(figsize=(7.16,6.05))
    gs=fig.add_gridspec(3,2,left=.105,right=.975,bottom=.105,top=.905,wspace=.31,hspace=.85)
    windows=['pre_temporal_early','pre_temporal_middle','pre_cumulative_10','post_cumulative_10','post_temporal_middle','post_temporal_late']
    time=np.array([-25,-15,-5,5,15,25])
    for i,f in enumerate(FAMILIES):
        ax=fig.add_subplot(gs[i//2,i%2]); ax.axvspan(-10,10,color='#F0F1F2',zorder=-2)
        for region,color,ls in [('SOZ',SOZ,'-'),('NSOZ',NSOZ,'--')]:
            d=traj[(traj.cfc_family==f)&(traj.soz_label==region)].set_index('window_id').loc[windows]
            ax.plot(time,d.median_z_value,color=color,ls=ls,lw=1.5,label=region)
            # A narrow band retains uncertainty without drawing a forest plot.
            ax.fill_between(time,d.ci95_low,d.ci95_high,color=color,alpha=.14,lw=0)
        ax.axvline(0,color='#717579',ls=':',lw=.8); ax.set_xlim(-30,30); ax.set_xticks([-30,-20,-10,0,10,20,30])
        ax.tick_params(length=2,pad=2,labelsize=8.5); ax.spines[['top','right']].set_visible(False)
        panel(ax,f'({chr(97+i)}) '+LABELS[i])
        if i%2==0: ax.set_ylabel('Standardized CFC',fontsize=8.5,labelpad=2)
    ax=fig.add_subplot(gs[2,1]); p=primary.set_index('cfc_family').loc[FAMILIES]
    data=p[['Lanzhou_median','ds003029_median','ds004100_median','center_equal_effect']].values
    limit=max(abs(data).max(),.001)
    matrix(ax,data,['PAC','PPC','AAC','BIC','COH'],['LZ','3029','4100','Equal'],-limit,limit,'RdBu_r','.3f')
    ax.tick_params(axis='y',pad=2,labelsize=8.5); ax.tick_params(axis='x',pad=2,labelsize=8.5)
    panel(ax,'(f) Early regional interaction'); ax.axvline(2.5,c='white',lw=3)
    # The values carry the scale; all cells share one linear, zero-centered map.
    ax.set_xlabel('Cohort medians and equal-weight estimate',fontsize=8,labelpad=4)
    fig.legend(handles=[plt.Line2D([],[],color=SOZ,lw=1.5,label='SOZ'),plt.Line2D([],[],color=NSOZ,lw=1.5,ls='--',label='NSOZ')],loc='upper center',bbox_to_anchor=(.53,1.0),ncol=2,frameon=False)
    fig.text(.315,.045,'Window midpoint relative to onset (s)',ha='center',fontsize=8.5)
    fig.text(.52,.012,'Trajectories: 79 matched patients; early interaction: 81 patients',ha='center',fontsize=8.5)
    save(fig,'Fig04_Regional_Dynamics_Around_Onset')

def number(v,digits=3):
    if 0<abs(v)<.5*10**(-digits): return f'{v:.5f}'
    return f'{v:.{digits}f}'

def sensitivity_table(data):
    order=['Primary CAR','Guard window','Median reference','Conservative mask','Aggressive mask','Exclude 150-200 Hz']
    suffix={'Primary CAR':'a','Guard window':'b','Median reference':'b','Conservative mask':'c','Aggressive mask':'b','Exclude 150-200 Hz':'a'}
    lines=[r'\begin{table*}[!t]',r'\caption{Sensitivity of Early Regional Interactions to Analysis Choices}',r'\label{tab:sensitivity}',r'\centering\small',r'\setlength{\tabcolsep}{5pt}',r'\begin{tabular}{lrrcrrc}',r'\toprule',r' & \multicolumn{3}{c}{PAC} & \multicolumn{3}{c}{CFC coherence} \\',r'\cmidrule(lr){2-4}\cmidrule(lr){5-7}',r'Condition & Estimate & 95\% CI & $q$ & Estimate & 95\% CI & $q$ \\',r'\midrule']
    for condition in order:
        row=[condition+r'$^{'+suffix[condition]+'}$']
        for f in ['PAC','CFC_coherence']:
            d=data[(data.family==f)&(data.condition==condition)]
            if d.empty: row += ['---','Not evaluated','---']; continue
            r=d.iloc[0]; q=r'$<0.001$' if r.q<.001 else f'{r.q:.3f}'
            row += [number(r.effect),'['+number(r.ci95_low)+', '+number(r.ci95_high)+']',q]
        lines.append(' & '.join(row)+r' \\')
    lines += [r'\bottomrule',r'\end{tabular}',r'\par\smallskip',r'\begin{minipage}{0.98\textwidth}\footnotesize',r'All estimates give equal weight to cohort medians of patient-level interactions. Intervals are patient-bootstrap percentiles. $^{a}$Five-family correction; $^{b}$targeted PAC/coherence correction; $^{c}$PAC-only test. The 150--200-Hz restriction retains 282 features. Conservative and aggressive masking modified 5.44\% and 14.7\% of samples on average; the algorithms also differed in event detection. PAC under aggressive masking is shown with extra precision. Full-precision values are in Supplementary Data Table S8.',r'\end{minipage}',r'\end{table*}']
    return '\n'.join(lines)

def uncertainty_tables(pair,loco,candidates):
    out=[]
    for table_no,frame,group,groups,lower,upper,title in [
        (2,pair,'comparison',PAIRS,'rho_ci95_low','rho_ci95_high','Pairwise Spatial-Map Agreement'),
        (3,loco,'heldout_cohort',COHORTS,'simultaneous_rho_ci95_low','simultaneous_rho_ci95_high','Leave-One-Cohort-Out Map Agreement')]:
        if table_no == 3:
            out.append(r'\clearpage')
        out += [r'\setcounter{table}{'+str(table_no-1)+'}',r'\begin{longtable}{llrcr}',r'\caption{'+title+r'}\\',r'\toprule',r'Comparison & Scope & $\rho$ & 95\% CI & Same sign (\%) \\',r'\midrule',r'\endfirsthead',r'\toprule',r'Comparison & Scope & $\rho$ & 95\% CI & Same sign (\%) \\',r'\midrule',r'\endhead']
        for g in groups:
            df=frame[frame[group]==g].set_index('scope_name')
            label=g.replace('Lanzhou','LZ').replace('ds003029','3029').replace('ds004100','4100')
            for i,scope in enumerate(['All 312 features']+FAMILIES):
                r=df.loc[scope]; name='All features' if i==0 else LABELS[i-1]
                out.append(f'{label if i==0 else ""} & {name} & {r.spearman_rho:.3f} & [{r[lower]:.3f}, {r[upper]:.3f}] & {100*r.direction_agreement:.1f}'+r' \\')
            out.append(r'\addlinespace')
        out += [r'\bottomrule',r'\end{longtable}']
    out += [r'\noindent Table S2 resamples the paired cohorts. Table S3 resamples discovery and held-out patients simultaneously; conditional intervals remain available in the corresponding CSV. These percentile intervals are reported as computed and can exclude the plug-in point estimate.',r'\setcounter{table}{3}',r'\begin{table}[H]',r'\centering\small',r'\caption{Held-Out Status of SOZ-Directed Candidates}',r'\begin{tabular}{lrrrr}',r'\toprule',r'Held-out cohort & Candidates & Passed & Same sign only & Reversed \\',r'\midrule']
    for c in COHORTS:
        r=candidates[(candidates.heldout_cohort==c)&(candidates.cfc_family=='Overall')&(candidates.candidate_direction=='SOZ')].iloc[0]
        out.append(f'{c} & {r.n_candidates} & {r.n_validation_passed} & {r.n_direction_only} & {r.n_reversed}'+r' \\')
    out += [r'\bottomrule',r'\end{tabular}',r'\end{table}']
    return '\n'.join(out)

def build(spatial,pair,loco,candidates,primary,traj,sensitivity):
    style(); fig2(spatial); fig3(pair,loco,candidates); fig4(primary,traj)
    assets=PROJECT/'results_assets'
    (assets/'table_sensitivity.tex').write_text(sensitivity_table(sensitivity),encoding='utf-8')
    (assets/'tables_map_uncertainty.tex').write_text(uncertainty_tables(pair,loco,candidates),encoding='utf-8')
    print('Reviewer layout: three result figures; primary inference and sensitivity tables.')
