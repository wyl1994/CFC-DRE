"""Experiment 2: three discovery/held-out rotations and locked candidate testing.

Scientific definitions follow the frozen author analysis; see REPRODUCE.md.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import shutil
from datetime import datetime
from pathlib import Path
from typing import Iterable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
from scipy import stats


plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

COHORTS = ("Lanzhou", "ds003029", "ds004100")
FAMILIES = ("PAC", "PPC", "AAC", "Bicoherence", "CFC_coherence")
FAMILY_LABELS = {
    "PAC": "PAC",
    "PPC": "PPC",
    "AAC": "AAC",
    "Bicoherence": "Bicoherence",
    "CFC_coherence": "CFC coherence",
}
UPPER_RIPPLE_LEGACY_KEY = "fast_ripple_low"
UPPER_RIPPLE_RANGE_HZ = (150.0, 200.0)
UPPER_RIPPLE_LABEL = "Upper-ripple (150-200 Hz)"
FOLDS = (
    ("Fold 1", ("ds003029", "ds004100"), "Lanzhou"),
    ("Fold 2", ("Lanzhou", "ds004100"), "ds003029"),
    ("Fold 3", ("Lanzhou", "ds003029"), "ds004100"),
)
PART_NAMES = {
    1: "01_完整效应图留一队列验证",
    2: "02_锁定候选特征留出队列验证",
    3: "03_双队列到三队列总体稳定性",
    4: "04_敏感性分析",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Revised Experiment II leave-one-cohort-out validation")
    parser.add_argument("--patient-table", required=True, type=Path)
    parser.add_argument("--feature-catalog", required=True, type=Path)
    parser.add_argument("--experiment1-feature-stats", required=True, type=Path)
    parser.add_argument("--output-root", required=True, type=Path)
    parser.add_argument("--feature-bootstrap", type=int, default=10000)
    parser.add_argument("--map-bootstrap", type=int, default=5000)
    parser.add_argument("--permutations", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=20260915)
    return parser.parse_args()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def bh_fdr(values: Iterable[float]) -> np.ndarray:
    p = np.asarray(list(values), dtype=float)
    q = np.full(p.shape, np.nan, dtype=float)
    valid = np.isfinite(p)
    if not valid.any():
        return q
    raw = p[valid]
    order = np.argsort(raw)
    ranked = raw[order]
    adjusted = ranked * len(ranked) / np.arange(1, len(ranked) + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    adjusted = np.clip(adjusted, 0, 1)
    restored = np.empty_like(adjusted)
    restored[order] = adjusted
    q[valid] = restored
    return q


def rank_biserial(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values) & ~np.isclose(values, 0)]
    if not len(values):
        return 0.0
    ranks = stats.rankdata(np.abs(values))
    positive = float(ranks[values > 0].sum())
    negative = float(ranks[values < 0].sum())
    return (positive - negative) / (positive + negative)


def safe_wilcoxon(values: np.ndarray) -> tuple[float, float]:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if not len(values) or np.allclose(values, 0):
        return 0.0, 1.0
    result = stats.wilcoxon(values, alternative="two-sided", zero_method="wilcox", method="auto")
    return float(result.statistic), float(result.pvalue)


def signed_stouffer_two_sided(
    first_values: np.ndarray, second_values: np.ndarray
) -> tuple[float, float, float, float]:
    """Combine cohort-specific two-sided Wilcoxon tests with equal weights."""
    _, first_p = safe_wilcoxon(first_values)
    _, second_p = safe_wilcoxon(second_values)
    first_sign = float(np.sign(np.median(first_values)))
    second_sign = float(np.sign(np.median(second_values)))
    first_z = first_sign * float(stats.norm.isf(max(first_p, np.finfo(float).tiny) / 2))
    second_z = second_sign * float(stats.norm.isf(max(second_p, np.finfo(float).tiny) / 2))
    combined_z = (first_z + second_z) / math.sqrt(2.0)
    combined_p = float(2.0 * stats.norm.sf(abs(combined_z)))
    return first_p, second_p, combined_z, combined_p


def safe_spearman(x: np.ndarray, y: np.ndarray) -> float:
    keep = np.isfinite(x) & np.isfinite(y)
    if keep.sum() < 3:
        return math.nan
    return float(stats.spearmanr(x[keep], y[keep]).statistic)


def rowwise_spearman(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    rx = stats.rankdata(x, axis=1)
    ry = stats.rankdata(y, axis=1)
    rx -= rx.mean(axis=1, keepdims=True)
    ry -= ry.mean(axis=1, keepdims=True)
    denominator = np.sqrt(np.sum(rx * rx, axis=1) * np.sum(ry * ry, axis=1))
    return np.divide(
        np.sum(rx * ry, axis=1),
        denominator,
        out=np.full(len(rx), np.nan),
        where=denominator > 0,
    )


def bootstrap_interval_summary(
    observed: float, distribution: np.ndarray, jackknife: np.ndarray
) -> dict[str, float]:
    """Return BCa, percentile, and basic intervals plus bias diagnostics."""
    finite = np.asarray(distribution, dtype=float)
    finite = finite[np.isfinite(finite)]
    if not len(finite):
        return {
            "percentile_low": math.nan,
            "percentile_high": math.nan,
            "basic_low": math.nan,
            "basic_high": math.nan,
            "bca_low": math.nan,
            "bca_high": math.nan,
            "bias_mean": math.nan,
            "bias_median": math.nan,
        }
    percentile_low, percentile_high = np.quantile(finite, [0.025, 0.975])
    basic_low = max(-1.0, 2.0 * observed - percentile_high)
    basic_high = min(1.0, 2.0 * observed - percentile_low)
    jack = np.asarray(jackknife, dtype=float)
    jack = jack[np.isfinite(jack)]
    if len(jack) >= 3:
        less = np.sum(finite < observed)
        equal = np.sum(finite == observed)
        probability = (less + 0.5 * equal) / len(finite)
        probability = np.clip(probability, 1.0 / (2 * len(finite)), 1 - 1.0 / (2 * len(finite)))
        z0 = float(stats.norm.ppf(probability))
        jack_mean = float(np.mean(jack))
        centered = jack_mean - jack
        denominator = 6.0 * float(np.sum(centered**2) ** 1.5)
        acceleration = float(np.sum(centered**3) / denominator) if denominator > 0 else 0.0
        adjusted = []
        for alpha in (0.025, 0.975):
            z_alpha = float(stats.norm.ppf(alpha))
            divisor = 1.0 - acceleration * (z0 + z_alpha)
            transformed = z0 + (z0 + z_alpha) / divisor if not np.isclose(divisor, 0) else z0
            adjusted.append(float(np.clip(stats.norm.cdf(transformed), 0, 1)))
        bca_low, bca_high = np.quantile(finite, adjusted)
    else:
        bca_low, bca_high = math.nan, math.nan
    return {
        "percentile_low": float(percentile_low),
        "percentile_high": float(percentile_high),
        "basic_low": float(basic_low),
        "basic_high": float(basic_high),
        "bca_low": float(bca_low),
        "bca_high": float(bca_high),
        "bias_mean": float(np.mean(finite) - observed),
        "bias_median": float(np.median(finite) - observed),
    }


def metric_value_dict(
    left: np.ndarray, right: np.ndarray, catalog: pd.DataFrame
) -> dict[str, float]:
    return {str(row["scope_name"]): float(row["spearman_rho"]) for row in metric_rows(left, right, catalog)}


def jackknife_map_distribution(
    matrices: dict[str, np.ndarray],
    discovery_cohorts: tuple[str, str],
    heldout: str,
    catalog: pd.DataFrame,
    weighting: str,
    fixed_discovery: bool,
) -> dict[str, np.ndarray]:
    fixed_left = discovery_map(matrices, discovery_cohorts, weighting)
    fixed_right = np.median(matrices[heldout], axis=0)
    names = [name for _, name, _ in scope_indices(catalog)] + ["Five-family equal-weight macro"]
    values: dict[str, list[float]] = {name: [] for name in names}
    cohorts_to_jackknife = (heldout,) if fixed_discovery else (*discovery_cohorts, heldout)
    for cohort in cohorts_to_jackknife:
        matrix = matrices[cohort]
        for omitted in range(len(matrix)):
            reduced = np.delete(matrix, omitted, axis=0)
            if cohort == heldout:
                left = fixed_left
                right = np.median(reduced, axis=0)
            else:
                changed = dict(matrices)
                changed[cohort] = reduced
                left = discovery_map(changed, discovery_cohorts, weighting)
                right = fixed_right
            current = metric_value_dict(left, right, catalog)
            for name in names:
                values[name].append(current[name])
    return {name: np.asarray(items, dtype=float) for name, items in values.items()}


def fisher_macro(rhos: Iterable[float]) -> float:
    finite = np.asarray([x for x in rhos if np.isfinite(x)], dtype=float)
    if not len(finite):
        return math.nan
    return float(np.tanh(np.mean(np.arctanh(np.clip(finite, -0.999999, 0.999999)))))


def build_matrix(patient: pd.DataFrame, catalog: pd.DataFrame) -> np.ndarray:
    wide = patient.pivot(index="patient_id", columns="feature_id", values="diff_median")
    wide = wide.reindex(columns=catalog["feature_id"])
    if wide.empty or wide.isna().any().any():
        raise RuntimeError("Missing patient-feature values in matrix")
    return wide.to_numpy(dtype=float)


def scope_indices(catalog: pd.DataFrame) -> list[tuple[str, str, np.ndarray]]:
    scopes = [("overall", f"All {len(catalog)} features", np.arange(len(catalog), dtype=int))]
    for family in FAMILIES:
        idx = np.flatnonzero(catalog["cfc_family"].eq(family).to_numpy())
        if len(idx) >= 3:
            scopes.append(("family", FAMILY_LABELS[family], idx))
    return scopes


def discovery_map(matrices: dict[str, np.ndarray], cohorts: tuple[str, str], weighting: str) -> np.ndarray:
    if weighting == "center_equal":
        return np.mean([np.median(matrices[name], axis=0) for name in cohorts], axis=0)
    if weighting == "patient_pooled":
        return np.median(np.vstack([matrices[name] for name in cohorts]), axis=0)
    raise ValueError(f"Unknown weighting: {weighting}")


def metric_rows(left: np.ndarray, right: np.ndarray, catalog: pd.DataFrame) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    family_rhos: list[float] = []
    family_directions: list[float] = []
    for scope_type, scope_name, idx in scope_indices(catalog):
        rho = safe_spearman(left[idx], right[idx])
        direction = float(np.mean(np.sign(left[idx]) == np.sign(right[idx])))
        rows.append(
            {
                "scope_type": scope_type,
                "scope_name": scope_name,
                "n_features": int(len(idx)),
                "spearman_rho": rho,
                "direction_agreement": direction,
                "median_absolute_error": float(np.median(np.abs(left[idx] - right[idx]))),
            }
        )
        if scope_type == "family":
            family_rhos.append(rho)
            family_directions.append(direction)
    rows.append(
        {
            "scope_type": "macro",
            "scope_name": "Five-family equal-weight macro",
            "n_features": 5,
            "spearman_rho": fisher_macro(family_rhos),
            "direction_agreement": float(np.mean(family_directions)),
            "median_absolute_error": math.nan,
        }
    )
    return rows


def bootstrap_map_distribution(
    matrices: dict[str, np.ndarray],
    discovery_cohorts: tuple[str, str],
    heldout: str,
    catalog: pd.DataFrame,
    weighting: str,
    repeats: int,
    seed: int,
    fixed_discovery: bool,
) -> dict[str, dict[str, np.ndarray]]:
    rng = np.random.default_rng(seed)
    scopes = scope_indices(catalog)
    names = [name for _, name, _ in scopes] + ["Five-family equal-weight macro"]
    rho = {name: np.empty(repeats, dtype=float) for name in names}
    direction = {name: np.empty(repeats, dtype=float) for name in names}
    fixed = discovery_map(matrices, discovery_cohorts, weighting)
    batch_size = 50
    for start in range(0, repeats, batch_size):
        stop = min(start + batch_size, repeats)
        size = stop - start
        if fixed_discovery:
            left = np.repeat(fixed[None, :], size, axis=0)
        else:
            sampled_discovery = []
            for cohort in discovery_cohorts:
                matrix = matrices[cohort]
                idx = rng.integers(0, len(matrix), size=(size, len(matrix)))
                sampled_discovery.append(matrix[idx])
            if weighting == "center_equal":
                left = np.mean([np.median(x, axis=1) for x in sampled_discovery], axis=0)
            else:
                left = np.median(np.concatenate(sampled_discovery, axis=1), axis=1)
        held_matrix = matrices[heldout]
        held_idx = rng.integers(0, len(held_matrix), size=(size, len(held_matrix)))
        right = np.median(held_matrix[held_idx], axis=1)
        family_rho = []
        family_direction = []
        for scope_type, scope_name, idx in scopes:
            current_rho = rowwise_spearman(left[:, idx], right[:, idx])
            current_direction = np.mean(np.sign(left[:, idx]) == np.sign(right[:, idx]), axis=1)
            rho[scope_name][start:stop] = current_rho
            direction[scope_name][start:stop] = current_direction
            if scope_type == "family":
                family_rho.append(current_rho)
                family_direction.append(current_direction)
        family_array = np.clip(np.column_stack(family_rho), -0.999999, 0.999999)
        rho["Five-family equal-weight macro"][start:stop] = np.tanh(
            np.mean(np.arctanh(family_array), axis=1)
        )
        direction["Five-family equal-weight macro"][start:stop] = np.mean(
            np.column_stack(family_direction), axis=1
        )
    return {"rho": rho, "direction": direction}


def permutation_map_distribution(
    fixed_discovery: np.ndarray,
    heldout_matrix: np.ndarray,
    catalog: pd.DataFrame,
    repeats: int,
    seed: int,
) -> dict[str, np.ndarray]:
    rng = np.random.default_rng(seed)
    scopes = scope_indices(catalog)
    names = [name for _, name, _ in scopes] + ["Five-family equal-weight macro"]
    values = {name: np.empty(repeats, dtype=float) for name in names}
    batch_size = 50
    for start in range(0, repeats, batch_size):
        stop = min(start + batch_size, repeats)
        size = stop - start
        signs = rng.choice(np.array([-1.0, 1.0]), size=(size, len(heldout_matrix), 1))
        permuted = np.median(heldout_matrix[None, :, :] * signs, axis=1)
        fixed = np.repeat(fixed_discovery[None, :], size, axis=0)
        family_values = []
        for scope_type, scope_name, idx in scopes:
            current = rowwise_spearman(fixed[:, idx], permuted[:, idx])
            values[scope_name][start:stop] = current
            if scope_type == "family":
                family_values.append(current)
        family_array = np.clip(np.column_stack(family_values), -0.999999, 0.999999)
        values["Five-family equal-weight macro"][start:stop] = np.tanh(
            np.mean(np.arctanh(family_array), axis=1)
        )
    return values


def run_map_validation(
    patient: pd.DataFrame,
    catalog: pd.DataFrame,
    weighting: str,
    bootstrap_repeats: int,
    permutation_repeats: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    matrices = {
        cohort: build_matrix(patient[patient["dataset_id"].eq(cohort)], catalog)
        for cohort in COHORTS
    }
    result_rows: list[dict[str, object]] = []
    feature_rows: list[dict[str, object]] = []
    for fold_index, (fold, discovery_cohorts, heldout) in enumerate(FOLDS):
        discovery = discovery_map(matrices, discovery_cohorts, weighting)
        heldout_map = np.median(matrices[heldout], axis=0)
        conditional = bootstrap_map_distribution(
            matrices, discovery_cohorts, heldout, catalog, weighting,
            bootstrap_repeats, seed + fold_index * 100, True,
        )
        simultaneous = bootstrap_map_distribution(
            matrices, discovery_cohorts, heldout, catalog, weighting,
            bootstrap_repeats, seed + fold_index * 100 + 20, False,
        )
        conditional_jackknife = jackknife_map_distribution(
            matrices, discovery_cohorts, heldout, catalog, weighting, True
        )
        simultaneous_jackknife = jackknife_map_distribution(
            matrices, discovery_cohorts, heldout, catalog, weighting, False
        )
        permutation = permutation_map_distribution(
            discovery, matrices[heldout], catalog, permutation_repeats,
            seed + fold_index * 100 + 40,
        )
        for row in metric_rows(discovery, heldout_map, catalog):
            name = str(row["scope_name"])
            observed = float(row["spearman_rho"])
            conditional_summary = bootstrap_interval_summary(
                observed, conditional["rho"][name], conditional_jackknife[name]
            )
            simultaneous_summary = bootstrap_interval_summary(
                observed, simultaneous["rho"][name], simultaneous_jackknife[name]
            )
            row.update(
                {
                    "fold": fold,
                    "discovery_cohorts": " + ".join(discovery_cohorts),
                    "heldout_cohort": heldout,
                    "weighting": weighting,
                    "n_discovery_patients": int(sum(len(matrices[x]) for x in discovery_cohorts)),
                    "n_heldout_patients": int(len(matrices[heldout])),
                    "conditional_rho_ci95_low": conditional_summary["percentile_low"],
                    "conditional_rho_ci95_high": conditional_summary["percentile_high"],
                    "conditional_rho_bca_ci95_low": conditional_summary["bca_low"],
                    "conditional_rho_bca_ci95_high": conditional_summary["bca_high"],
                    "conditional_rho_basic_ci95_low": conditional_summary["basic_low"],
                    "conditional_rho_basic_ci95_high": conditional_summary["basic_high"],
                    "conditional_rho_percentile_ci95_low": conditional_summary["percentile_low"],
                    "conditional_rho_percentile_ci95_high": conditional_summary["percentile_high"],
                    "conditional_rho_bootstrap_bias_mean": conditional_summary["bias_mean"],
                    "conditional_rho_bootstrap_bias_median": conditional_summary["bias_median"],
                    "conditional_direction_ci95_low": float(np.quantile(conditional["direction"][name], 0.025)),
                    "conditional_direction_ci95_high": float(np.quantile(conditional["direction"][name], 0.975)),
                    "simultaneous_rho_ci95_low": simultaneous_summary["percentile_low"],
                    "simultaneous_rho_ci95_high": simultaneous_summary["percentile_high"],
                    "simultaneous_rho_bca_ci95_low": simultaneous_summary["bca_low"],
                    "simultaneous_rho_bca_ci95_high": simultaneous_summary["bca_high"],
                    "simultaneous_rho_basic_ci95_low": simultaneous_summary["basic_low"],
                    "simultaneous_rho_basic_ci95_high": simultaneous_summary["basic_high"],
                    "simultaneous_rho_percentile_ci95_low": simultaneous_summary["percentile_low"],
                    "simultaneous_rho_percentile_ci95_high": simultaneous_summary["percentile_high"],
                    "simultaneous_rho_bootstrap_bias_mean": simultaneous_summary["bias_mean"],
                    "simultaneous_rho_bootstrap_bias_median": simultaneous_summary["bias_median"],
                    "simultaneous_direction_ci95_low": float(np.quantile(simultaneous["direction"][name], 0.025)),
                    "simultaneous_direction_ci95_high": float(np.quantile(simultaneous["direction"][name], 0.975)),
                    "permutation_p": float(
                        (1 + np.sum(np.abs(permutation[name]) >= abs(observed)))
                        / (permutation_repeats + 1)
                    ),
                }
            )
            result_rows.append(row)
        specs = catalog[["cfc_family", "method", "feature_id"]].copy()
        specs["fold"] = fold
        specs["discovery_cohorts"] = " + ".join(discovery_cohorts)
        specs["heldout_cohort"] = heldout
        specs["weighting"] = weighting
        specs["discovery_effect"] = discovery
        specs["heldout_effect"] = heldout_map
        specs["same_direction"] = np.sign(discovery) == np.sign(heldout_map)
        feature_rows.extend(specs.to_dict("records"))
    result = pd.DataFrame(result_rows)
    result["permutation_q"] = np.nan
    for scope_type in ("overall", "family", "macro"):
        mask = result["scope_type"].eq(scope_type)
        result.loc[mask, "permutation_q"] = bh_fdr(result.loc[mask, "permutation_p"])
    ordered = [
        "fold", "discovery_cohorts", "heldout_cohort", "weighting",
        "scope_type", "scope_name", "n_features", "n_discovery_patients",
        "n_heldout_patients", "spearman_rho", "conditional_rho_ci95_low",
        "conditional_rho_ci95_high", "conditional_rho_bca_ci95_low",
        "conditional_rho_bca_ci95_high", "conditional_rho_percentile_ci95_low",
        "conditional_rho_percentile_ci95_high", "conditional_rho_basic_ci95_low",
        "conditional_rho_basic_ci95_high", "conditional_rho_bootstrap_bias_mean",
        "conditional_rho_bootstrap_bias_median", "simultaneous_rho_ci95_low",
        "simultaneous_rho_ci95_high", "simultaneous_rho_bca_ci95_low",
        "simultaneous_rho_bca_ci95_high", "simultaneous_rho_percentile_ci95_low",
        "simultaneous_rho_percentile_ci95_high", "simultaneous_rho_basic_ci95_low",
        "simultaneous_rho_basic_ci95_high", "simultaneous_rho_bootstrap_bias_mean",
        "simultaneous_rho_bootstrap_bias_median", "direction_agreement",
        "conditional_direction_ci95_low", "conditional_direction_ci95_high",
        "simultaneous_direction_ci95_low", "simultaneous_direction_ci95_high",
        "median_absolute_error", "permutation_p", "permutation_q",
    ]
    return result[ordered], pd.DataFrame(feature_rows)


def bootstrap_center_equal_ci(
    first: np.ndarray, second: np.ndarray, repeats: int, rng: np.random.Generator
) -> tuple[float, float]:
    first_idx = rng.integers(0, len(first), size=(repeats, len(first)))
    second_idx = rng.integers(0, len(second), size=(repeats, len(second)))
    distribution = (np.median(first[first_idx], axis=1) + np.median(second[second_idx], axis=1)) / 2
    return tuple(np.quantile(distribution, [0.025, 0.975]).astype(float))


def discovery_feature_statistics(
    patient: pd.DataFrame,
    catalog: pd.DataFrame,
    repeats: int,
    seed: int,
) -> pd.DataFrame:
    matrices = {
        cohort: build_matrix(patient[patient["dataset_id"].eq(cohort)], catalog)
        for cohort in COHORTS
    }
    rows: list[dict[str, object]] = []
    for fold_index, (fold, discovery_cohorts, heldout) in enumerate(FOLDS):
        first = matrices[discovery_cohorts[0]]
        second = matrices[discovery_cohorts[1]]
        rng = np.random.default_rng(seed + fold_index * 1000)
        fold_rows = []
        for index, spec in catalog.iterrows():
            pooled = np.concatenate([first[:, index], second[:, index]])
            statistic, p_value = safe_wilcoxon(pooled)
            first_p, second_p, combined_z, combined_p = signed_stouffer_two_sided(
                first[:, index], second[:, index]
            )
            first_median = float(np.median(first[:, index]))
            second_median = float(np.median(second[:, index]))
            ci_low, ci_high = bootstrap_center_equal_ci(
                first[:, index], second[:, index], repeats, rng
            )
            fold_rows.append(
                {
                    "fold": fold,
                    "discovery_cohorts": " + ".join(discovery_cohorts),
                    "heldout_cohort": heldout,
                    "cfc_family": spec["cfc_family"],
                    "method": spec["method"],
                    "feature_id": spec["feature_id"],
                    "n_discovery_patients": int(len(pooled)),
                    "first_cohort_median": first_median,
                    "second_cohort_median": second_median,
                    "center_equal_effect": (first_median + second_median) / 2,
                    "center_equal_ci95_low": ci_low,
                    "center_equal_ci95_high": ci_high,
                    "pooled_median_effect": float(np.median(pooled)),
                    "pooled_wilcoxon_statistic": statistic,
                    "pooled_p_value": p_value,
                    "first_cohort_p_value": first_p,
                    "second_cohort_p_value": second_p,
                    "center_equal_stouffer_z": combined_z,
                    "center_equal_stouffer_p_value": combined_p,
                    "pooled_rank_biserial": rank_biserial(pooled),
                    "center_equal_rank_biserial": (
                        rank_biserial(first[:, index]) + rank_biserial(second[:, index])
                    ) / 2,
                    "first_positive_fraction": float(np.mean(first[:, index] > 0)),
                    "second_positive_fraction": float(np.mean(second[:, index] > 0)),
                }
            )
        fold_frame = pd.DataFrame(fold_rows)
        fold_frame["center_equal_stouffer_q_value"] = bh_fdr(
            fold_frame["center_equal_stouffer_p_value"]
        )
        fold_frame["pooled_q_value"] = bh_fdr(fold_frame["pooled_p_value"])
        fold_frame["discovery_q_value"] = fold_frame["center_equal_stouffer_q_value"]
        fold_frame["candidate_soz"] = (
            fold_frame["discovery_q_value"].lt(0.05)
            & fold_frame["center_equal_ci95_low"].gt(0)
            & fold_frame["center_equal_rank_biserial"].gt(0)
            & fold_frame["first_cohort_median"].gt(0)
            & fold_frame["second_cohort_median"].gt(0)
        )
        fold_frame["candidate_nsoz"] = (
            fold_frame["discovery_q_value"].lt(0.05)
            & fold_frame["center_equal_ci95_high"].lt(0)
            & fold_frame["center_equal_rank_biserial"].lt(0)
            & fold_frame["first_cohort_median"].lt(0)
            & fold_frame["second_cohort_median"].lt(0)
        )
        fold_frame["candidate_soz_pooled_test"] = (
            fold_frame["pooled_q_value"].lt(0.05)
            & fold_frame["center_equal_ci95_low"].gt(0)
            & fold_frame["center_equal_rank_biserial"].gt(0)
            & fold_frame["first_cohort_median"].gt(0)
            & fold_frame["second_cohort_median"].gt(0)
        )
        fold_frame["candidate_nsoz_pooled_test"] = (
            fold_frame["pooled_q_value"].lt(0.05)
            & fold_frame["center_equal_ci95_high"].lt(0)
            & fold_frame["center_equal_rank_biserial"].lt(0)
            & fold_frame["first_cohort_median"].lt(0)
            & fold_frame["second_cohort_median"].lt(0)
        )
        rows.extend(fold_frame.to_dict("records"))
    return pd.DataFrame(rows)


def compare_candidate_tests(discovery_stats: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for fold, _, heldout in FOLDS:
        part = discovery_stats[discovery_stats["fold"].eq(fold)]
        for direction, primary_col, pooled_col in (
            ("SOZ", "candidate_soz", "candidate_soz_pooled_test"),
            ("NSOZ", "candidate_nsoz", "candidate_nsoz_pooled_test"),
        ):
            primary = part[primary_col].astype(bool)
            pooled = part[pooled_col].astype(bool)
            rows.append(
                {
                    "fold": fold,
                    "heldout_cohort": heldout,
                    "candidate_direction": direction,
                    "center_equal_stouffer_candidates": int(primary.sum()),
                    "patient_pooled_wilcoxon_candidates": int(pooled.sum()),
                    "overlap": int((primary & pooled).sum()),
                    "center_equal_only": int((primary & ~pooled).sum()),
                    "patient_pooled_only": int((~primary & pooled).sum()),
                }
            )
    return pd.DataFrame(rows)


def wilson_interval(successes: int, total: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if total == 0:
        return math.nan, math.nan
    proportion = successes / total
    denominator = 1 + z * z / total
    center = (proportion + z * z / (2 * total)) / denominator
    margin = z * math.sqrt(proportion * (1 - proportion) / total + z * z / (4 * total * total)) / denominator
    return max(0.0, center - margin), min(1.0, center + margin)


def validate_candidates(
    discovery_stats: pd.DataFrame,
    heldout_stats: pd.DataFrame,
    catalog: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    detail_parts = []
    heldout_lookup = heldout_stats.set_index(["analysis_group", "feature_id"])
    for fold, discovery_cohorts, heldout in FOLDS:
        fold_stats = discovery_stats[discovery_stats["fold"].eq(fold)]
        candidates = pd.concat(
            [
                fold_stats[fold_stats["candidate_soz"]].assign(candidate_direction="SOZ"),
                fold_stats[fold_stats["candidate_nsoz"]].assign(candidate_direction="NSOZ"),
            ],
            ignore_index=True,
        )
        if candidates.empty:
            continue
        held_rows = [heldout_lookup.loc[(heldout, fid)] for fid in candidates["feature_id"]]
        candidates["validation_median_effect"] = [float(x["median_difference"]) for x in held_rows]
        candidates["validation_ci95_low"] = [float(x["ci95_low"]) for x in held_rows]
        candidates["validation_ci95_high"] = [float(x["ci95_high"]) for x in held_rows]
        candidates["validation_p_value"] = [float(x["p_value"]) for x in held_rows]
        candidates["validation_rank_biserial"] = [float(x["rank_biserial"]) for x in held_rows]
        candidates["validation_positive_fraction"] = [float(x["positive_fraction"]) for x in held_rows]
        candidates["validation_q_value"] = bh_fdr(candidates["validation_p_value"])
        is_soz = candidates["candidate_direction"].eq("SOZ")
        same_direction = np.where(
            is_soz,
            candidates["validation_median_effect"].gt(0),
            candidates["validation_median_effect"].lt(0),
        )
        interval_pass = np.where(
            is_soz,
            candidates["validation_ci95_low"].gt(0),
            candidates["validation_ci95_high"].lt(0),
        )
        effect_pass = np.where(
            is_soz,
            candidates["validation_rank_biserial"].gt(0),
            candidates["validation_rank_biserial"].lt(0),
        )
        passed = same_direction & interval_pass & effect_pass & candidates["validation_q_value"].lt(0.05)
        candidates["same_direction"] = same_direction
        candidates["validation_passed"] = passed
        candidates["validation_class"] = np.where(
            passed,
            "Cross-cohort validation passed",
            np.where(same_direction, "Direction only", "Reversed"),
        )
        detail_parts.append(candidates)
    detail = pd.concat(detail_parts, ignore_index=True) if detail_parts else pd.DataFrame()

    summary_rows: list[dict[str, object]] = []
    if not detail.empty:
        for (fold, direction), direction_group in detail.groupby(["fold", "candidate_direction"], observed=True):
            heldout = direction_group["heldout_cohort"].iloc[0]
            for family in ["Overall", *FAMILIES]:
                group = direction_group if family == "Overall" else direction_group[direction_group["cfc_family"].eq(family)]
                total = len(group)
                passed = int(group["validation_passed"].sum())
                low, high = wilson_interval(passed, total)
                summary_rows.append(
                    {
                        "fold": fold,
                        "heldout_cohort": heldout,
                        "candidate_direction": direction,
                        "cfc_family": family,
                        "n_candidates": total,
                        "n_validation_passed": passed,
                        "n_direction_only": int(group["validation_class"].eq("Direction only").sum()),
                        "n_reversed": int(group["validation_class"].eq("Reversed").sum()),
                        "validation_rate": passed / total if total else math.nan,
                        "validation_rate_ci95_low": low,
                        "validation_rate_ci95_high": high,
                    }
                )
    summary = pd.DataFrame(summary_rows)

    transport = catalog.copy()
    if detail.empty:
        for name in ["candidate_folds", "validation_passes", "same_direction_folds"]:
            transport[name] = 0
    else:
        transport["candidate_folds"] = transport["feature_id"].map(detail.groupby("feature_id").size()).fillna(0).astype(int)
        transport["validation_passes"] = transport["feature_id"].map(
            detail[detail["validation_passed"]].groupby("feature_id").size()
        ).fillna(0).astype(int)
        transport["same_direction_folds"] = transport["feature_id"].map(
            detail[detail["same_direction"]].groupby("feature_id").size()
        ).fillna(0).astype(int)
    return detail, summary, transport


def consensus_stability(
    patient: pd.DataFrame, catalog: pd.DataFrame
) -> tuple[pd.DataFrame, pd.DataFrame]:
    matrices = {
        cohort: build_matrix(patient[patient["dataset_id"].eq(cohort)], catalog)
        for cohort in COHORTS
    }
    cohort_maps = {cohort: np.median(matrix, axis=0) for cohort, matrix in matrices.items()}
    consensus = np.mean(np.vstack([cohort_maps[x] for x in COHORTS]), axis=0)
    rows = []
    feature_rows = []
    for fold, discovery_cohorts, heldout in FOLDS:
        discovery = np.mean(np.vstack([cohort_maps[x] for x in discovery_cohorts]), axis=0)
        for row in metric_rows(discovery, consensus, catalog):
            row.update(
                {
                    "fold": fold,
                    "discovery_cohorts": " + ".join(discovery_cohorts),
                    "added_cohort": heldout,
                }
            )
            rows.append(row)
        specs = catalog[["cfc_family", "method", "feature_id"]].copy()
        specs["fold"] = fold
        specs["discovery_cohorts"] = " + ".join(discovery_cohorts)
        specs["added_cohort"] = heldout
        specs["discovery_effect"] = discovery
        specs["three_cohort_consensus_effect"] = consensus
        feature_rows.extend(specs.to_dict("records"))
    return pd.DataFrame(rows), pd.DataFrame(feature_rows)


def setup_output(root: Path) -> dict[int, dict[str, Path]]:
    root.mkdir(parents=True, exist_ok=False)
    paths: dict[int, dict[str, Path]] = {}
    for number, name in PART_NAMES.items():
        part = root / name
        paths[number] = {
            "root": part,
            "data": part / "01_统计数据",
            "figures": part / "02_结果图",
            "code": part / "03_分析代码",
        }
        for path in paths[number].values():
            path.mkdir(parents=True, exist_ok=True)
    return paths


def save_figure(fig: plt.Figure, path_without_suffix: Path) -> None:
    fig.savefig(path_without_suffix.with_suffix(".png"), dpi=220, bbox_inches="tight", facecolor="white")
    fig.savefig(path_without_suffix.with_suffix(".pdf"), bbox_inches="tight", facecolor="white")
    plt.close(fig)


def plot_validation_forest(data: pd.DataFrame, path: Path, title: str) -> None:
    order = [f"All {data.loc[data['scope_type'].eq('overall'), 'n_features'].max()} features"]
    order += [FAMILY_LABELS[x] for x in FAMILIES]
    order += ["Five-family equal-weight macro"]
    fig, axes = plt.subplots(1, 3, figsize=(15.8, 5.6), sharey=True)
    for ax, (fold, _, heldout) in zip(axes, FOLDS):
        group = data[data["fold"].eq(fold)].set_index("scope_name")
        y = np.arange(len(order))
        rho = np.array([group.loc[name, "spearman_rho"] for name in order])
        low = np.array([group.loc[name, "conditional_rho_ci95_low"] for name in order])
        high = np.array([group.loc[name, "conditional_rho_ci95_high"] for name in order])
        ax.hlines(y, low, high, color="#8DAFC4", linewidth=2)
        ax.plot(low, y, "|", color="#8DAFC4", markersize=7)
        ax.plot(high, y, "|", color="#8DAFC4", markersize=7)
        ax.plot(rho, y, "o", color="#315F7D")
        ax.axvline(0, color="#8B949E", ls="--", lw=1)
        ax.set_xlim(-1, 1)
        ax.set_title(f"{fold}: held-out {heldout}")
        ax.set_xlabel("Spearman rho (95% conditional stratified bootstrap range)")
        ax.grid(axis="x", alpha=0.2)
    axes[0].set_yticks(np.arange(len(order)), order)
    fig.suptitle(title, weight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    save_figure(fig, path)


def plot_map_scatter(feature_values: pd.DataFrame, path: Path, title: str) -> None:
    fig, axes = plt.subplots(1, 3, figsize=(14.8, 4.8))
    for ax, (fold, _, heldout) in zip(axes, FOLDS):
        group = feature_values[feature_values["fold"].eq(fold)]
        x = group["discovery_effect"].to_numpy(dtype=float)
        y = group["heldout_effect"].to_numpy(dtype=float)
        rho = safe_spearman(x, y)
        ax.scatter(x, y, s=16, alpha=0.55, color="#315F7D", edgecolors="none")
        limit = max(np.max(np.abs(x)), np.max(np.abs(y))) * 1.04
        ax.plot([-limit, limit], [-limit, limit], color="#999999", ls="--", lw=1)
        ax.axhline(0, color="#D0D0D0", lw=0.8)
        ax.axvline(0, color="#D0D0D0", lw=0.8)
        ax.set_xlim(-limit, limit)
        ax.set_ylim(-limit, limit)
        ax.set_aspect("equal", adjustable="box")
        ax.set_title(f"{fold}: held-out {heldout}\nrho = {rho:.3f}")
        ax.set_xlabel("Discovery effect")
        ax.set_ylabel("Held-out effect")
    fig.suptitle(title, weight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.92))
    save_figure(fig, path)


def plot_candidate_counts(summary: pd.DataFrame, path: Path) -> None:
    data = summary[
        summary["candidate_direction"].eq("SOZ") & summary["cfc_family"].eq("Overall")
    ].set_index("fold").reindex([x[0] for x in FOLDS])
    classes = ["n_validation_passed", "n_direction_only", "n_reversed"]
    labels = ["Cross-cohort validation passed", "Direction only", "Reversed"]
    colors = ["#2E8B8B", "#E5B15A", "#D97941"]
    x = np.arange(len(data))
    bottom = np.zeros(len(data))
    fig, ax = plt.subplots(figsize=(8.8, 5.2))
    for column, label, color in zip(classes, labels, colors):
        values = data[column].to_numpy(dtype=float)
        ax.bar(x, values, bottom=bottom, color=color, label=label)
        bottom += values
    ax.set_xticks(x, [f"{fold}\nheld-out {heldout}" for fold, _, heldout in FOLDS])
    ax.set_ylabel("Locked SOZ-advantage candidates")
    ax.set_title("Feature-level independent validation", weight="bold")
    ax.legend(frameon=False, ncol=3, loc="upper center")
    ax.grid(axis="y", alpha=0.2)
    fig.tight_layout()
    save_figure(fig, path)


def plot_candidate_family_rates(summary: pd.DataFrame, path: Path) -> None:
    data = summary[
        summary["candidate_direction"].eq("SOZ") & summary["cfc_family"].isin(FAMILIES)
    ].copy()
    x = np.arange(len(FAMILIES))
    width = 0.24
    colors = ["#D97941", "#2E8B8B", "#3B6FB6"]
    fig, ax = plt.subplots(figsize=(10.8, 5.3))
    for index, (fold, _, heldout) in enumerate(FOLDS):
        group = data[data["fold"].eq(fold)].set_index("cfc_family")
        values = [group.loc[f, "validation_rate"] if f in group.index else math.nan for f in FAMILIES]
        ax.bar(x + (index - 1) * width, values, width, label=f"{fold}: {heldout}", color=colors[index])
    ax.set_xticks(x, [FAMILY_LABELS[x] for x in FAMILIES])
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("Cross-cohort validation rate")
    ax.set_title("Locked candidate validation by CFC family", weight="bold")
    ax.legend(frameon=False, ncol=3, loc="upper center")
    ax.grid(axis="y", alpha=0.2)
    fig.tight_layout()
    save_figure(fig, path)


def plot_consensus(data: pd.DataFrame, path: Path) -> None:
    order = ["All 312 features", *[FAMILY_LABELS[x] for x in FAMILIES], "Five-family equal-weight macro"]
    fig, ax = plt.subplots(figsize=(10.8, 5.4))
    x = np.arange(len(order))
    colors = ["#D97941", "#2E8B8B", "#3B6FB6"]
    for index, (fold, _, heldout) in enumerate(FOLDS):
        group = data[data["fold"].eq(fold)].set_index("scope_name")
        values = [group.loc[name, "spearman_rho"] for name in order]
        ax.plot(x, values, "o-", color=colors[index], label=f"{fold}: add {heldout}")
    ax.set_xticks(x, order, rotation=12, ha="right")
    ax.set_ylim(-0.1, 1.05)
    ax.set_ylabel("Spearman rho")
    ax.set_title("Discovery-map stability after adding the third cohort", weight="bold")
    ax.legend(frameon=False)
    ax.grid(axis="y", alpha=0.2)
    fig.tight_layout()
    save_figure(fig, path)


def plot_sensitivities(
    primary: pd.DataFrame,
    pooled: pd.DataFrame,
    high: pd.DataFrame,
    path: Path,
) -> None:
    primary_overall = primary[primary["scope_type"].eq("overall")].set_index("fold")
    pooled_overall = pooled[pooled["scope_type"].eq("overall")].set_index("fold")
    high_overall = high[high["scope_type"].eq("overall")].set_index("fold")
    folds = [x[0] for x in FOLDS]
    x = np.arange(3)
    fig, axes = plt.subplots(1, 2, figsize=(13.2, 5.1))
    axes[0].plot(x, primary_overall.loc[folds, "spearman_rho"], "o-", lw=2, label="Center-equal, 312", color="#315F7D")
    axes[0].plot(x, pooled_overall.loc[folds, "spearman_rho"], "s-", lw=2, label="Patient-pooled, 312", color="#D97941")
    axes[0].plot(x, high_overall.loc[folds, "spearman_rho"], "^-", lw=2, label="Center-equal, 282", color="#2E8B8B")
    axes[0].set_xticks(x, [f"{fold}\n{heldout}" for fold, _, heldout in FOLDS])
    axes[0].set_ylim(0, 1)
    axes[0].set_ylabel("Spearman rho")
    axes[0].set_title("Weighting and upper-ripple sensitivity")
    axes[0].legend(frameon=False)
    axes[0].grid(axis="y", alpha=0.2)
    conditional_width = (
        primary_overall.loc[folds, "conditional_rho_ci95_high"].to_numpy()
        - primary_overall.loc[folds, "conditional_rho_ci95_low"].to_numpy()
    )
    simultaneous_width = (
        primary_overall.loc[folds, "simultaneous_rho_ci95_high"].to_numpy()
        - primary_overall.loc[folds, "simultaneous_rho_ci95_low"].to_numpy()
    )
    width = 0.34
    axes[1].bar(x - width / 2, conditional_width, width, label="Held-out only", color="#76A5C3")
    axes[1].bar(x + width / 2, simultaneous_width, width, label="Both discovery and held-out", color="#E5A06A")
    axes[1].set_xticks(x, [x[0] for x in FOLDS])
    axes[1].set_ylabel("95% CI width")
    axes[1].set_title("Bootstrap uncertainty scope")
    axes[1].legend(frameon=False)
    axes[1].grid(axis="y", alpha=0.2)
    fig.suptitle("Experiment II sensitivity analyses", weight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    save_figure(fig, path)


def markdown_table(frame: pd.DataFrame, columns: list[str], digits: int = 3) -> str:
    data = frame[columns].copy()
    for column in data.select_dtypes(include=[np.number]).columns:
        data[column] = data[column].map(
            lambda value: "" if pd.isna(value) else f"{value:.{digits}f}"
        )
    header = "| " + " | ".join(columns) + " |"
    rule = "|" + "|".join(["---"] * len(columns)) + "|"
    rows = ["| " + " | ".join(map(str, row)) + " |" for row in data.to_numpy()]
    return "\n".join([header, rule, *rows])


def write_reports(
    paths: dict[int, dict[str, Path]],
    primary: pd.DataFrame,
    candidate_summary: pd.DataFrame,
    transport: pd.DataFrame,
    consensus: pd.DataFrame,
    pooled: pd.DataFrame,
    high: pd.DataFrame,
    high_candidate_summary: pd.DataFrame,
    candidate_test_comparison: pd.DataFrame,
) -> None:
    primary_table = markdown_table(
        primary[primary["scope_type"].eq("overall")],
        ["fold", "discovery_cohorts", "heldout_cohort", "n_features", "spearman_rho", "conditional_rho_ci95_low", "conditional_rho_ci95_high", "direction_agreement", "permutation_q"],
    )
    family_table = markdown_table(
        primary[primary["scope_type"].isin(["family", "macro"])],
        ["fold", "heldout_cohort", "scope_name", "n_features", "spearman_rho", "conditional_rho_ci95_low", "conditional_rho_ci95_high", "direction_agreement", "permutation_q"],
    )
    main_candidates = candidate_summary[
        candidate_summary["candidate_direction"].eq("SOZ") & candidate_summary["cfc_family"].eq("Overall")
    ]
    candidate_table = markdown_table(
        main_candidates,
        ["fold", "heldout_cohort", "n_candidates", "n_validation_passed", "n_direction_only", "n_reversed", "validation_rate", "validation_rate_ci95_low", "validation_rate_ci95_high"],
    )
    family_candidate_table = markdown_table(
        candidate_summary[
            candidate_summary["candidate_direction"].eq("SOZ") & candidate_summary["cfc_family"].isin(FAMILIES)
        ],
        ["fold", "heldout_cohort", "cfc_family", "n_candidates", "n_validation_passed", "validation_rate", "n_direction_only", "n_reversed"],
    )
    consensus_table = markdown_table(
        consensus[consensus["scope_type"].eq("overall")],
        ["fold", "discovery_cohorts", "added_cohort", "n_features", "spearman_rho", "direction_agreement", "median_absolute_error"],
    )
    sensitivity_rows = []
    for label, frame in [("Center-equal 312", primary), ("Patient-pooled 312", pooled), ("Center-equal 282", high)]:
        part = frame[frame["scope_type"].eq("overall")].copy()
        part.insert(0, "analysis", label)
        sensitivity_rows.append(part)
    sensitivity = pd.concat(sensitivity_rows, ignore_index=True)
    sensitivity_table = markdown_table(
        sensitivity,
        ["analysis", "fold", "heldout_cohort", "n_features", "spearman_rho", "direction_agreement", "permutation_q"],
    )
    high_candidate_table = markdown_table(
        high_candidate_summary[
            high_candidate_summary["candidate_direction"].eq("SOZ") & high_candidate_summary["cfc_family"].eq("Overall")
        ],
        ["fold", "heldout_cohort", "n_candidates", "n_validation_passed", "validation_rate"],
    )
    candidate_test_table = markdown_table(
        candidate_test_comparison,
        [
            "fold", "heldout_cohort", "candidate_direction",
            "center_equal_stouffer_candidates", "patient_pooled_wilcoxon_candidates",
            "overlap", "center_equal_only", "patient_pooled_only",
        ],
    )

    reports = {
        1: f"""
# 完整效应图留一队列验证 详细结果

## 设计

每轮将两个发现队列分别形成患者中位SOZ减NSOZ效应图，再以队列等权方式合并；第三个数据集完全留出。主要终点为全部312个特征的Spearman相关，五类CFC和五家族等权结果用于解释方法特异的迁移性。

## 完整效应图

{primary_table}

## 五类CFC与等权结果

{family_table}

条件bootstrap固定发现图，只重采样留出队列；同时重采样版本传播发现侧与验证侧的不确定性。由于患者中位数与Spearman相关构成非平滑统计量，主文报告分层百分位bootstrap的95%重采样范围；BCa、basic区间与bootstrap偏倚仅作为诊断，不承担显著性判断。正式统计推断由置换检验完成，并分别对3个总体、15个家族和3个宏平均检验进行BH校正。
""",
        2: f"""
# 锁定候选特征跨队列验证 详细结果

## 设计

发现侧先在两个队列内分别执行患者级Wilcoxon检验，再将带方向的Z值以等权Stouffer方法合并，并对312个组合P值进行FDR校正。候选还要求队列等权bootstrap区间不跨0、队列等权秩二列效应方向正确，且两个发现队列的中位效应同方向。患者直接合并的Wilcoxon P值和q值保留在统计表中作为权重敏感性结果。验证队列只在锁定候选范围内重新校正FDR。

## SOZ优势候选总体结果

{candidate_table}

## 五类CFC结果

{family_candidate_table}

`Direction only`表示留出队列方向一致但未同时满足FDR、置信区间和秩二列效应标准；`Reversed`表示方向反转。通过率的95%区间使用Wilson方法。每个特征跨三轮的候选和通过次数保存在`feature_transportability_summary.csv`，共{len(transport)}个特征。
""",
        3: f"""
# 双队列到三队列总体稳定性 详细结果

## 设计

将双队列等权发现图与三个队列等权总体图比较，用于评价加入第三队列后效应结构是否改变。总体图包含发现队列，因此本部分不是独立验证，不提供验证性P值。

{consensus_table}
""",
        4: f"""
# 实验二敏感性分析 详细结果

## 权重与Upper-ripple频段排除

{sensitivity_table}

`Center-equal 312`是主分析；`Patient-pooled 312`检验样本量权重影响；`Center-equal 282`排除涉及Upper-ripple（150至200 Hz）的30个特征。原始特征表中的内部键`fast_ripple_low`仅为历史键名，并不代表经典定义的fast ripple。

## 排除Upper-ripple频段后的候选验证

{high_candidate_table}

## 候选检验权重口径

{candidate_test_table}

等权Stouffer组合是修订后的主检验，患者合并Wilcoxon仅用于评价样本量权重是否改变候选集合。

主统计表同时保存固定发现图与双侧同时重采样的置信区间，用于比较条件验证不确定性和完整发现—验证流程不确定性。实验一已经完成电极类型匹配分析，本部分不重复。
""",
    }
    descriptions = {
        1: "本目录保存三轮队列等权的留一队列完整效应图验证。",
        2: "本目录保存发现候选、留出队列验证、家族通过率和跨轮特征迁移结果。",
        3: "本目录保存双队列发现图与三队列等权总体图的描述性稳定性比较。",
        4: "本目录保存队列权重、Upper-ripple（150至200 Hz）频段排除、bootstrap范围与区间方法敏感性分析。",
    }
    for number in PART_NAMES:
        (paths[number]["root"] / "README_文件说明.md").write_text(
            "# 文件说明\n\n" + descriptions[number] + "统计数据、结果图和可复现代码分别保存在三个编号子目录中。",
            encoding="utf-8",
        )
        (paths[number]["root"] / "详细结果分析.md").write_text(reports[number].strip() + "\n", encoding="utf-8")
        (paths[number]["code"] / "运行说明.md").write_text(
            "# 运行说明\n\n本目录中的程序一次性生成实验二全部四部分。运行时需提供患者级Parquet、特征目录、实验一正式特征统计表和输出目录。",
            encoding="utf-8",
        )

    full_report = f"""
# 实验二：双队列发现与留一队列跨数据集验证

## 研究目的

检验任意两个队列发现的SOZ减NSOZ五类CFC效应结构，能否迁移到未参与该轮发现的第三个数据集。主要分析采用队列等权发现图和等权Stouffer候选检验；患者合并、Upper-ripple频段排除及bootstrap范围作为敏感性分析。该设计属于同一研究内的internal-external cross-validation，不表述为前瞻性独立外部验证。

## 完整效应图跨数据集验证

{primary_table}

## 锁定SOZ优势候选验证

{candidate_table}

## 总体稳定性

{consensus_table}

## 结论边界

跨队列证据来自留出数据集的完整效应图和锁定候选验证。双队列与三队列总体比较包含发现数据，只能解释加入第三队列后的稳定性。实验二不评价患者级SOZ分类性能，也不涉及机器学习模型。
"""
    (paths[1]["root"].parent / "实验二_完整结果报告.md").write_text(full_report.strip() + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    patient = pd.read_parquet(args.patient_table)
    catalog = pd.read_csv(args.feature_catalog).drop_duplicates("feature_id").reset_index(drop=True)
    experiment1_stats = pd.read_csv(args.experiment1_feature_stats)
    if len(catalog) != 312 or patient["feature_id"].nunique() != 312:
        raise RuntimeError("Expected 312 CFC features")
    if set(patient["dataset_id"].unique()) != set(COHORTS):
        raise RuntimeError("Expected exactly three cohorts")
    if patient.duplicated(["dataset_id", "patient_id", "feature_id"]).any():
        raise RuntimeError("Duplicate patient-feature rows")
    if len(experiment1_stats) != 936:
        raise RuntimeError("Experiment I feature statistics must contain 936 rows")

    paths = setup_output(args.output_root)
    print("Part 1: center-equal leave-one-cohort-out map validation", flush=True)
    primary, primary_feature_values = run_map_validation(
        patient, catalog, "center_equal", args.map_bootstrap, args.permutations, args.seed
    )
    primary.to_csv(paths[1]["data"] / "leave_one_cohort_out_map_validation.csv", index=False, encoding="utf-8-sig")
    primary_feature_values.to_csv(paths[1]["data"] / "leave_one_cohort_out_feature_values.csv", index=False, encoding="utf-8-sig")
    plot_validation_forest(primary, paths[1]["figures"] / "leave_one_cohort_out_family_correlations", "Leave-one-cohort-out CFC validation")
    plot_map_scatter(primary_feature_values, paths[1]["figures"] / "leave_one_cohort_out_effect_scatter", "Cohort-equal discovery maps vs held-out datasets")

    print("Part 2: locked feature validation", flush=True)
    discovery_stats = discovery_feature_statistics(patient, catalog, args.feature_bootstrap, args.seed + 10000)
    candidate_test_comparison = compare_candidate_tests(discovery_stats)
    candidate_detail, candidate_summary, transport = validate_candidates(discovery_stats, experiment1_stats, catalog)
    discovery_stats.to_csv(paths[2]["data"] / "discovery_feature_statistics.csv", index=False, encoding="utf-8-sig")
    candidate_test_comparison.to_csv(
        paths[4]["data"] / "candidate_test_weighting_comparison.csv",
        index=False,
        encoding="utf-8-sig",
    )
    candidate_detail.to_csv(paths[2]["data"] / "candidate_validation_detail.csv", index=False, encoding="utf-8-sig")
    candidate_summary.to_csv(paths[2]["data"] / "candidate_validation_summary.csv", index=False, encoding="utf-8-sig")
    transport.to_csv(paths[2]["data"] / "feature_transportability_summary.csv", index=False, encoding="utf-8-sig")
    top = candidate_detail[candidate_detail["validation_passed"]].sort_values(
        ["candidate_direction", "validation_median_effect"], ascending=[True, False]
    )
    top.to_csv(paths[2]["data"] / "validated_features_ranked.csv", index=False, encoding="utf-8-sig")
    plot_candidate_counts(candidate_summary, paths[2]["figures"] / "feature_validation_counts")
    plot_candidate_family_rates(candidate_summary, paths[2]["figures"] / "family_validation_rates")

    print("Part 3: discovery-to-consensus stability", flush=True)
    consensus, consensus_features = consensus_stability(patient, catalog)
    consensus.to_csv(paths[3]["data"] / "discovery_vs_three_cohort_consensus.csv", index=False, encoding="utf-8-sig")
    consensus_features.to_csv(paths[3]["data"] / "consensus_feature_values.csv", index=False, encoding="utf-8-sig")
    plot_consensus(consensus, paths[3]["figures"] / "discovery_to_consensus_stability")

    print("Part 4: weighting and upper-ripple sensitivities", flush=True)
    pooled, _ = run_map_validation(
        patient, catalog, "patient_pooled", args.map_bootstrap, args.permutations, args.seed + 20000
    )
    high_mask = catalog[["band_1", "band_2"]].eq(UPPER_RIPPLE_LEGACY_KEY).any(axis=1)
    high_catalog = catalog.loc[~high_mask].reset_index(drop=True)
    high_patient = patient[patient["feature_id"].isin(high_catalog["feature_id"])].copy()
    high, _ = run_map_validation(
        high_patient, high_catalog, "center_equal", args.map_bootstrap, args.permutations, args.seed + 30000
    )
    high_discovery_stats = discovery_feature_statistics(
        high_patient, high_catalog, args.feature_bootstrap, args.seed + 40000
    )
    high_candidate_detail, high_candidate_summary, _ = validate_candidates(
        high_discovery_stats,
        experiment1_stats[experiment1_stats["feature_id"].isin(high_catalog["feature_id"])],
        high_catalog,
    )
    pooled.to_csv(paths[4]["data"] / "patient_pooled_weighting_sensitivity.csv", index=False, encoding="utf-8-sig")
    high.to_csv(paths[4]["data"] / "exclude_upper_ripple_150_200Hz_map_validation.csv", index=False, encoding="utf-8-sig")
    high_discovery_stats.to_csv(paths[4]["data"] / "exclude_upper_ripple_150_200Hz_discovery_feature_statistics.csv", index=False, encoding="utf-8-sig")
    high_candidate_detail.to_csv(paths[4]["data"] / "exclude_upper_ripple_150_200Hz_candidate_validation_detail.csv", index=False, encoding="utf-8-sig")
    high_candidate_summary.to_csv(paths[4]["data"] / "exclude_upper_ripple_150_200Hz_candidate_validation_summary.csv", index=False, encoding="utf-8-sig")
    catalog.loc[high_mask].to_csv(paths[4]["data"] / "excluded_upper_ripple_150_200Hz_features.csv", index=False, encoding="utf-8-sig")
    bootstrap_scope = primary[
        primary["scope_type"].eq("overall")
    ][[
        "fold", "heldout_cohort", "spearman_rho", "conditional_rho_ci95_low",
        "conditional_rho_ci95_high", "conditional_rho_bca_ci95_low",
        "conditional_rho_bca_ci95_high", "conditional_rho_percentile_ci95_low",
        "conditional_rho_percentile_ci95_high", "conditional_rho_basic_ci95_low",
        "conditional_rho_basic_ci95_high", "conditional_rho_bootstrap_bias_mean",
        "conditional_rho_bootstrap_bias_median", "simultaneous_rho_ci95_low",
        "simultaneous_rho_ci95_high", "simultaneous_rho_bca_ci95_low",
        "simultaneous_rho_bca_ci95_high", "simultaneous_rho_percentile_ci95_low",
        "simultaneous_rho_percentile_ci95_high", "simultaneous_rho_basic_ci95_low",
        "simultaneous_rho_basic_ci95_high", "simultaneous_rho_bootstrap_bias_mean",
        "simultaneous_rho_bootstrap_bias_median",
    ]].copy()
    bootstrap_scope["conditional_ci_width"] = bootstrap_scope["conditional_rho_ci95_high"] - bootstrap_scope["conditional_rho_ci95_low"]
    bootstrap_scope["simultaneous_ci_width"] = bootstrap_scope["simultaneous_rho_ci95_high"] - bootstrap_scope["simultaneous_rho_ci95_low"]
    bootstrap_scope["conditional_bca_ci_width"] = (
        bootstrap_scope["conditional_rho_bca_ci95_high"]
        - bootstrap_scope["conditional_rho_bca_ci95_low"]
    )
    bootstrap_scope["simultaneous_bca_ci_width"] = (
        bootstrap_scope["simultaneous_rho_bca_ci95_high"]
        - bootstrap_scope["simultaneous_rho_bca_ci95_low"]
    )
    bootstrap_scope["conditional_percentile_ci_width"] = (
        bootstrap_scope["conditional_rho_percentile_ci95_high"]
        - bootstrap_scope["conditional_rho_percentile_ci95_low"]
    )
    bootstrap_scope["simultaneous_percentile_ci_width"] = (
        bootstrap_scope["simultaneous_rho_percentile_ci95_high"]
        - bootstrap_scope["simultaneous_rho_percentile_ci95_low"]
    )
    bootstrap_scope["conditional_range_contains_point"] = (
        bootstrap_scope["spearman_rho"].ge(bootstrap_scope["conditional_rho_ci95_low"])
        & bootstrap_scope["spearman_rho"].le(bootstrap_scope["conditional_rho_ci95_high"])
    )
    bootstrap_scope["simultaneous_range_contains_point"] = (
        bootstrap_scope["spearman_rho"].ge(bootstrap_scope["simultaneous_rho_ci95_low"])
        & bootstrap_scope["spearman_rho"].le(bootstrap_scope["simultaneous_rho_ci95_high"])
    )
    bootstrap_scope.to_csv(paths[4]["data"] / "bootstrap_scope_sensitivity.csv", index=False, encoding="utf-8-sig")
    plot_sensitivities(primary, pooled, high, paths[4]["figures"] / "experiment2_sensitivity_summary")

    write_reports(
        paths, primary, candidate_summary, transport, consensus, pooled, high,
        high_candidate_summary, candidate_test_comparison,
    )
    for number in PART_NAMES:
        shutil.copy2(Path(__file__), paths[number]["code"] / "run_experiment2_revised.py")

    metadata = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "input_patient_table": str(args.patient_table),
        "input_patient_table_sha256": sha256_file(args.patient_table),
        "feature_catalog": str(args.feature_catalog),
        "feature_catalog_sha256": sha256_file(args.feature_catalog),
        "experiment1_feature_stats": str(args.experiment1_feature_stats),
        "experiment1_feature_stats_sha256": sha256_file(args.experiment1_feature_stats),
        "patients": int(patient.groupby(["dataset_id", "patient_id"]).ngroups),
        "patient_feature_rows": int(len(patient)),
        "features_primary": int(len(catalog)),
        "features_without_upper_ripple_150_200Hz": int(len(high_catalog)),
        "frequency_band_definition": {
            "legacy_internal_key": UPPER_RIPPLE_LEGACY_KEY,
            "display_name": UPPER_RIPPLE_LABEL,
            "low_hz": UPPER_RIPPLE_RANGE_HZ[0],
            "high_hz": UPPER_RIPPLE_RANGE_HZ[1],
        },
        "feature_bootstrap_repeats": args.feature_bootstrap,
        "map_bootstrap_repeats": args.map_bootstrap,
        "permutation_repeats": args.permutations,
        "seed": args.seed,
        "analysis_unit": "patient",
        "discovery_weighting_primary": "center_equal",
        "heldout_policy": "not used for discovery feature selection, direction, or thresholds",
        "window": "post-onset 0-30 s",
        "reference": "CAR",
        "sampling_rate_hz": 500,
        "surrogates": 1000,
        "lanzhou_label_note": (
            "Clinically provided surgical/resection contacts treated as an SOZ proxy "
            "according to clinician confirmation"
        ),
        "map_correlation_uncertainty_primary": "stratified percentile bootstrap 95% resampling range",
        "map_correlation_inference": "stratified permutation test with BH-FDR correction",
        "map_correlation_interval_sensitivity": "BCa and basic bootstrap diagnostics",
        "discovery_feature_test_primary": "equal-weight signed Stouffer combination of cohort-specific Wilcoxon tests",
        "discovery_feature_test_sensitivity": "patient-pooled Wilcoxon",
        "python": platform.python_version(),
        "pandas": pd.__version__,
        "numpy": np.__version__,
        "scipy": scipy.__version__,
    }
    (args.output_root / "run_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (args.output_root / "README_实验二总说明.md").write_text(
        "# 实验二总说明\n\n本目录包含修订后的双队列发现与留一队列跨数据集验证，属于同一研究内的internal-external cross-validation。四个编号目录依次对应完整效应图验证、锁定候选特征验证、总体稳定性和敏感性分析。实验一结果不在此重复。",
        encoding="utf-8",
    )
    print(json.dumps({"status": "complete", "output": str(args.output_root)}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
