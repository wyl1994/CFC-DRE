"""Matched patients/windows/features with joint bootstrap and identical split partitions.

Scientific definitions follow the frozen author analysis; see REPRODUCE.md.
"""
from __future__ import annotations

import argparse
import json
from itertools import combinations
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import rankdata


ESTIMANDS = {
    "pre_spatial": "spatial_z_value_pre",
    "post_spatial": "spatial_z_value_post",
    "early_interaction": "interaction_z_value",
}
ESTIMAND_LABELS = {
    "pre_spatial": "Pre-onset spatial contrast",
    "post_spatial": "Post-onset spatial contrast",
    "early_interaction": "Early region-by-time interaction",
}
DATASET_ORDER = ["ds003029", "ds004100", "Lanzhou"]
FAMILY_ORDER = ["PAC", "PPC", "AAC", "Bicoherence", "CFC_coherence"]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Matched-patient, matched-window reliability analysis for Experiment 3."
    )
    parser.add_argument("--early", type=Path, required=True)
    parser.add_argument("--catalog", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--bootstrap", type=int, default=2000)
    parser.add_argument("--split-half", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=20260926)
    return parser.parse_args()


def spearman_rho(first: np.ndarray, second: np.ndarray) -> float:
    first = np.asarray(first, dtype=float)
    second = np.asarray(second, dtype=float)
    valid = np.isfinite(first) & np.isfinite(second)
    if valid.sum() < 3:
        return np.nan
    first = first[valid]
    second = second[valid]
    if np.ptp(first) == 0 or np.ptp(second) == 0:
        return np.nan
    first_rank = rankdata(first, method="average")
    second_rank = rankdata(second, method="average")
    return float(np.corrcoef(first_rank, second_rank)[0, 1])


def direction_agreement(first: np.ndarray, second: np.ndarray) -> float:
    first = np.asarray(first, dtype=float)
    second = np.asarray(second, dtype=float)
    valid = np.isfinite(first) & np.isfinite(second)
    if valid.sum() == 0:
        return np.nan
    return float(np.mean(np.sign(first[valid]) == np.sign(second[valid])))


def percentile_interval(values: np.ndarray) -> tuple[float, float, float]:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if values.size == 0:
        return np.nan, np.nan, np.nan
    low, median, high = np.percentile(values, [2.5, 50.0, 97.5])
    return float(median), float(low), float(high)


def validate_inputs(early: pd.DataFrame, catalog: pd.DataFrame) -> pd.DataFrame:
    required = {
        "dataset_id",
        "patient_id",
        "feature_id",
        "spatial_z_value_pre",
        "spatial_z_value_post",
        "interaction_z_value",
    }
    missing = sorted(required.difference(early.columns))
    if missing:
        raise ValueError(f"Missing columns in early table: {missing}")
    if early.duplicated(["dataset_id", "patient_id", "feature_id"]).any():
        raise ValueError("Duplicate dataset-patient-feature rows detected.")
    if early[list(ESTIMANDS.values())].isna().any().any():
        raise ValueError("Non-finite estimand values detected.")
    if set(early["feature_id"]) != set(catalog["feature_id"]):
        raise ValueError("Feature catalog and early table do not contain the same feature IDs.")

    audit_rows = []
    expected_features = catalog["feature_id"].nunique()
    for dataset_id, group in early.groupby("dataset_id", observed=True):
        counts = group.groupby("patient_id", observed=True)["feature_id"].nunique()
        audit_rows.append(
            {
                "dataset_id": dataset_id,
                "n_patients": int(group["patient_id"].nunique()),
                "n_features": int(group["feature_id"].nunique()),
                "minimum_features_per_patient": int(counts.min()),
                "maximum_features_per_patient": int(counts.max()),
                "complete_feature_grid": bool((counts == expected_features).all()),
                "missing_estimand_values": int(group[list(ESTIMANDS.values())].isna().sum().sum()),
            }
        )
    audit = pd.DataFrame(audit_rows)
    if not audit["complete_feature_grid"].all():
        raise ValueError("At least one patient does not have a complete feature grid.")
    return audit


def build_matrices(
    early: pd.DataFrame, feature_order: list[str]
) -> dict[str, dict[str, pd.DataFrame]]:
    matrices: dict[str, dict[str, pd.DataFrame]] = {}
    for dataset_id in DATASET_ORDER:
        cohort = early.loc[early["dataset_id"] == dataset_id].copy()
        if cohort.empty:
            continue
        matrices[dataset_id] = {}
        for estimand, value_column in ESTIMANDS.items():
            matrix = cohort.pivot(
                index="patient_id", columns="feature_id", values=value_column
            ).reindex(columns=feature_order)
            matrices[dataset_id][estimand] = matrix.sort_index()
    return matrices


def observed_pairwise(
    matrices: dict[str, dict[str, pd.DataFrame]],
    scopes: dict[str, np.ndarray],
) -> pd.DataFrame:
    rows = []
    for first, second in combinations(DATASET_ORDER, 2):
        for scope, indices in scopes.items():
            for estimand in ESTIMANDS:
                first_map = np.nanmedian(matrices[first][estimand].to_numpy()[:, indices], axis=0)
                second_map = np.nanmedian(matrices[second][estimand].to_numpy()[:, indices], axis=0)
                rows.append(
                    {
                        "cohort_1": first,
                        "cohort_2": second,
                        "scope": scope,
                        "estimand": estimand,
                        "n_features": int(indices.size),
                        "spearman_rho": spearman_rho(first_map, second_map),
                        "direction_agreement": direction_agreement(first_map, second_map),
                        "median_absolute_difference": float(
                            np.nanmedian(np.abs(first_map - second_map))
                        ),
                    }
                )
    return pd.DataFrame(rows)


def bootstrap_pairwise(
    matrices: dict[str, dict[str, pd.DataFrame]],
    scopes: dict[str, np.ndarray],
    repeats: int,
    rng: np.random.Generator,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    draw_rows = []
    for first, second in combinations(DATASET_ORDER, 2):
        n_first = matrices[first]["pre_spatial"].shape[0]
        n_second = matrices[second]["pre_spatial"].shape[0]
        first_arrays = {key: value.to_numpy() for key, value in matrices[first].items()}
        second_arrays = {key: value.to_numpy() for key, value in matrices[second].items()}
        for repeat in range(repeats):
            first_index = rng.integers(0, n_first, size=n_first)
            second_index = rng.integers(0, n_second, size=n_second)
            first_maps = {
                key: np.nanmedian(array[first_index], axis=0)
                for key, array in first_arrays.items()
            }
            second_maps = {
                key: np.nanmedian(array[second_index], axis=0)
                for key, array in second_arrays.items()
            }
            for scope, indices in scopes.items():
                values = {
                    estimand: spearman_rho(
                        first_maps[estimand][indices], second_maps[estimand][indices]
                    )
                    for estimand in ESTIMANDS
                }
                for estimand, rho in values.items():
                    draw_rows.append(
                        {
                            "cohort_1": first,
                            "cohort_2": second,
                            "scope": scope,
                            "repeat": repeat,
                            "estimand": estimand,
                            "spearman_rho": rho,
                        }
                    )
    draws = pd.DataFrame(draw_rows)

    summary_rows = []
    for keys, group in draws.groupby(
        ["cohort_1", "cohort_2", "scope", "estimand"], observed=True
    ):
        median, low, high = percentile_interval(group["spearman_rho"].to_numpy())
        summary_rows.append(
            {
                "cohort_1": keys[0],
                "cohort_2": keys[1],
                "scope": keys[2],
                "estimand": keys[3],
                "bootstrap_median_rho": median,
                "bootstrap_ci_low": low,
                "bootstrap_ci_high": high,
                "n_bootstrap": int(group.shape[0]),
            }
        )
    summary = pd.DataFrame(summary_rows)

    wide = draws.pivot_table(
        index=["cohort_1", "cohort_2", "scope", "repeat"],
        columns="estimand",
        values="spearman_rho",
    ).reset_index()
    comparisons = {
        "post_minus_interaction": wide["post_spatial"] - wide["early_interaction"],
        "pre_minus_interaction": wide["pre_spatial"] - wide["early_interaction"],
        "post_minus_pre": wide["post_spatial"] - wide["pre_spatial"],
    }
    difference_rows = []
    for name, values in comparisons.items():
        wide[name] = values
        for keys, group in wide.groupby(["cohort_1", "cohort_2", "scope"], observed=True):
            delta = group[name].to_numpy(dtype=float)
            median, low, high = percentile_interval(delta)
            finite = delta[np.isfinite(delta)]
            difference_rows.append(
                {
                    "cohort_1": keys[0],
                    "cohort_2": keys[1],
                    "scope": keys[2],
                    "comparison": name,
                    "median_delta_rho": median,
                    "ci_low": low,
                    "ci_high": high,
                    "probability_delta_above_zero": float(np.mean(finite > 0)),
                    "n_bootstrap": int(finite.size),
                }
            )
    differences = pd.DataFrame(difference_rows)
    return draws, summary, differences


def split_half_reliability(
    matrices: dict[str, dict[str, pd.DataFrame]],
    scopes: dict[str, np.ndarray],
    repeats: int,
    rng: np.random.Generator,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    rows = []
    for dataset_id in DATASET_ORDER:
        arrays = {key: value.to_numpy() for key, value in matrices[dataset_id].items()}
        n_patients = arrays["pre_spatial"].shape[0]
        first_size = n_patients // 2
        for repeat in range(repeats):
            order = rng.permutation(n_patients)
            first_index = order[:first_size]
            second_index = order[first_size:]
            first_maps = {
                key: np.nanmedian(array[first_index], axis=0) for key, array in arrays.items()
            }
            second_maps = {
                key: np.nanmedian(array[second_index], axis=0) for key, array in arrays.items()
            }
            for scope, indices in scopes.items():
                for estimand in ESTIMANDS:
                    rows.append(
                        {
                            "dataset_id": dataset_id,
                            "scope": scope,
                            "repeat": repeat,
                            "estimand": estimand,
                            "spearman_rho": spearman_rho(
                                first_maps[estimand][indices], second_maps[estimand][indices]
                            ),
                            "n_first_half": int(first_index.size),
                            "n_second_half": int(second_index.size),
                        }
                    )
    draws = pd.DataFrame(rows)

    summary_rows = []
    for keys, group in draws.groupby(["dataset_id", "scope", "estimand"], observed=True):
        median, low, high = percentile_interval(group["spearman_rho"].to_numpy())
        summary_rows.append(
            {
                "dataset_id": keys[0],
                "scope": keys[1],
                "estimand": keys[2],
                "split_half_median_rho": median,
                "split_half_ci_low": low,
                "split_half_ci_high": high,
                "n_repeats": int(group.shape[0]),
            }
        )
    summary = pd.DataFrame(summary_rows)

    wide = draws.pivot_table(
        index=["dataset_id", "scope", "repeat"],
        columns="estimand",
        values="spearman_rho",
    ).reset_index()
    comparisons = {
        "post_minus_interaction": wide["post_spatial"] - wide["early_interaction"],
        "pre_minus_interaction": wide["pre_spatial"] - wide["early_interaction"],
        "post_minus_pre": wide["post_spatial"] - wide["pre_spatial"],
    }
    difference_rows = []
    for name, values in comparisons.items():
        wide[name] = values
        for keys, group in wide.groupby(["dataset_id", "scope"], observed=True):
            delta = group[name].to_numpy(dtype=float)
            median, low, high = percentile_interval(delta)
            finite = delta[np.isfinite(delta)]
            difference_rows.append(
                {
                    "dataset_id": keys[0],
                    "scope": keys[1],
                    "comparison": name,
                    "median_delta_rho": median,
                    "ci_low": low,
                    "ci_high": high,
                    "probability_delta_above_zero": float(np.mean(finite > 0)),
                    "n_repeats": int(finite.size),
                }
            )
    differences = pd.DataFrame(difference_rows)
    return draws, summary, differences


def make_figure(
    observed: pd.DataFrame,
    bootstrap_summary: pd.DataFrame,
    split_summary: pd.DataFrame,
    output_dir: Path,
) -> None:
    plt.rcParams.update(
        {
            "font.family": "Arial",
            "font.size": 8,
            "axes.linewidth": 0.8,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )
    colors = {
        "pre_spatial": "#4C78A8",
        "post_spatial": "#E45756",
        "early_interaction": "#16877B",
    }
    markers = {"pre_spatial": "o", "post_spatial": "s", "early_interaction": "^"}

    fig, axes = plt.subplots(1, 2, figsize=(7.16, 2.75), constrained_layout=True)
    pair_order = list(combinations(DATASET_ORDER, 2))
    pair_labels = [f"{first}\nvs {second}" for first, second in pair_order]
    x = np.arange(len(pair_order), dtype=float)
    offsets = {"pre_spatial": -0.18, "post_spatial": 0.0, "early_interaction": 0.18}

    for estimand in ESTIMANDS:
        y = []
        low = []
        high = []
        for first, second in pair_order:
            row = bootstrap_summary.loc[
                (bootstrap_summary["cohort_1"] == first)
                & (bootstrap_summary["cohort_2"] == second)
                & (bootstrap_summary["scope"] == "All features")
                & (bootstrap_summary["estimand"] == estimand)
            ].iloc[0]
            observed_row = observed.loc[
                (observed["cohort_1"] == first)
                & (observed["cohort_2"] == second)
                & (observed["scope"] == "All features")
                & (observed["estimand"] == estimand)
            ].iloc[0]
            y.append(float(observed_row["spearman_rho"]))
            low.append(float(observed_row["spearman_rho"] - row["bootstrap_ci_low"]))
            high.append(float(row["bootstrap_ci_high"] - observed_row["spearman_rho"]))
        axes[0].errorbar(
            x + offsets[estimand],
            y,
            yerr=np.vstack([np.maximum(low, 0), np.maximum(high, 0)]),
            color=colors[estimand],
            marker=markers[estimand],
            markersize=4,
            linewidth=1.1,
            capsize=2,
            label=ESTIMAND_LABELS[estimand],
        )
    axes[0].axhline(0, color="#666666", linewidth=0.7, linestyle="--")
    axes[0].set_xticks(x, pair_labels)
    axes[0].set_ylabel("Cross-cohort Spearman rho")
    axes[0].set_title("(a) Matched cross-cohort map agreement", loc="left", fontweight="bold")
    axes[0].set_ylim(-0.35, 1.0)

    x2 = np.arange(len(DATASET_ORDER), dtype=float)
    for estimand in ESTIMANDS:
        y = []
        low = []
        high = []
        for dataset_id in DATASET_ORDER:
            row = split_summary.loc[
                (split_summary["dataset_id"] == dataset_id)
                & (split_summary["scope"] == "All features")
                & (split_summary["estimand"] == estimand)
            ].iloc[0]
            y.append(float(row["split_half_median_rho"]))
            low.append(float(row["split_half_median_rho"] - row["split_half_ci_low"]))
            high.append(float(row["split_half_ci_high"] - row["split_half_median_rho"]))
        axes[1].errorbar(
            x2 + offsets[estimand],
            y,
            yerr=np.vstack([np.maximum(low, 0), np.maximum(high, 0)]),
            color=colors[estimand],
            marker=markers[estimand],
            markersize=4,
            linewidth=1.1,
            capsize=2,
            label=ESTIMAND_LABELS[estimand],
        )
    axes[1].axhline(0, color="#666666", linewidth=0.7, linestyle="--")
    axes[1].set_xticks(x2, DATASET_ORDER)
    axes[1].set_ylabel("Within-cohort split-half rho")
    axes[1].set_title("(b) Matched within-cohort reliability", loc="left", fontweight="bold")
    axes[1].set_ylim(-0.35, 1.0)
    axes[1].legend(frameon=False, fontsize=7, loc="lower right")

    for axis in axes:
        axis.spines[["top", "right"]].set_visible(False)
        axis.grid(axis="y", color="#D9D9D9", linewidth=0.5, alpha=0.7)

    output_dir.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_dir / "matched_window_map_reliability.png", dpi=600, bbox_inches="tight")
    fig.savefig(output_dir / "matched_window_map_reliability.pdf", bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    data_dir = args.output / "01_统计数据"
    figure_dir = args.output / "02_结果图"
    data_dir.mkdir(exist_ok=True)
    figure_dir.mkdir(exist_ok=True)

    early = pd.read_parquet(args.early)
    catalog = pd.read_csv(args.catalog)
    audit = validate_inputs(early, catalog)
    audit.to_csv(data_dir / "eligibility_audit.csv", index=False, encoding="utf-8-sig")

    catalog = catalog.drop_duplicates("feature_id").copy()
    catalog["family_order"] = catalog["cfc_family"].map(
        {family: index for index, family in enumerate(FAMILY_ORDER)}
    )
    catalog = catalog.sort_values(["family_order", "method", "feature_id"])
    feature_order = catalog["feature_id"].tolist()
    feature_family = catalog.set_index("feature_id")["cfc_family"].reindex(feature_order)
    scopes = {"All features": np.arange(len(feature_order), dtype=int)}
    for family in FAMILY_ORDER:
        scopes[family] = np.flatnonzero(feature_family.to_numpy() == family)

    matrices = build_matrices(early, feature_order)
    observed = observed_pairwise(matrices, scopes)
    observed.to_csv(
        data_dir / "matched_window_pairwise_observed.csv", index=False, encoding="utf-8-sig"
    )

    bootstrap_rng = np.random.default_rng(args.seed)
    bootstrap_draws, bootstrap_summary, bootstrap_differences = bootstrap_pairwise(
        matrices, scopes, args.bootstrap, bootstrap_rng
    )
    bootstrap_draws.to_parquet(data_dir / "matched_window_pairwise_bootstrap_draws.parquet")
    bootstrap_summary.to_csv(
        data_dir / "matched_window_pairwise_bootstrap_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )
    bootstrap_differences.to_csv(
        data_dir / "matched_window_pairwise_delta_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )

    split_rng = np.random.default_rng(args.seed + 1)
    split_draws, split_summary, split_differences = split_half_reliability(
        matrices, scopes, args.split_half, split_rng
    )
    split_draws.to_parquet(data_dir / "matched_window_split_half_draws.parquet")
    split_summary.to_csv(
        data_dir / "matched_window_split_half_summary.csv", index=False, encoding="utf-8-sig"
    )
    split_differences.to_csv(
        data_dir / "matched_window_split_half_delta_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )

    make_figure(observed, bootstrap_summary, split_summary, figure_dir)
    run_metadata = {
        "early_input": str(args.early.resolve()),
        "catalog_input": str(args.catalog.resolve()),
        "bootstrap_repeats": args.bootstrap,
        "split_half_repeats": args.split_half,
        "random_seed": args.seed,
        "estimands": ESTIMANDS,
        "datasets": DATASET_ORDER,
        "families": FAMILY_ORDER,
        "patient_counts": {
            row.dataset_id: int(row.n_patients) for row in audit.itertuples(index=False)
        },
    }
    (data_dir / "run_metadata.json").write_text(
        json.dumps(run_metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print("Matched-window reliability analysis completed.")
    print(observed.loc[observed["scope"] == "All features"].to_string(index=False))


if __name__ == "__main__":
    main()
