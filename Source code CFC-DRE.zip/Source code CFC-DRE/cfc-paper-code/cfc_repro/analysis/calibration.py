"""Nine synthetic signal scenarios; calibration is separate from patient inference.

Scientific definitions follow the frozen author analysis; see REPRODUCE.md.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import math
import sys
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import signal


SFREQ = 500.0
FAMILIES = ["PAC", "PPC", "AAC", "Bicoherence", "CFC_coherence"]
SCENARIOS = [
    "independent",
    "transient_pac",
    "stationary_pac",
    "stationary_ppc",
    "common_am",
    "quadratic_triad",
    "harmonic_waveform",
    "sharp_transients",
    "power_ramp",
]
EXPECTED_TARGET = {
    "independent": "None",
    "transient_pac": "PAC; CFC coherence",
    "stationary_pac": "PAC; CFC coherence",
    "stationary_ppc": "PPC",
    "common_am": "AAC",
    "quadratic_triad": "Bicoherence",
    "harmonic_waveform": "Diagnostic confound; multiple families may respond",
    "sharp_transients": "Diagnostic confound; multiple families may respond",
    "power_ramp": "Diagnostic nonstationarity",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Targeted synthetic calibration of CFC surrogates.")
    parser.add_argument("--bicoherence-module", type=Path, required=True)
    parser.add_argument("--coherence-module", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--replicates", type=int, default=100)
    parser.add_argument("--surrogates", type=int, default=200)
    parser.add_argument("--seed", type=int, default=20260926)
    return parser.parse_args()


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def fft_bandpass(values: np.ndarray, low: float, high: float) -> np.ndarray:
    centered = np.asarray(values, dtype=np.float64) - np.mean(values)
    frequencies = np.fft.rfftfreq(centered.size, 1.0 / SFREQ)
    spectrum = np.fft.rfft(centered)
    spectrum *= (frequencies >= low) & (frequencies <= high)
    return np.fft.irfft(spectrum, n=centered.size)


def analytic_phase(values: np.ndarray, low: float, high: float) -> np.ndarray:
    return np.angle(signal.hilbert(fft_bandpass(values, low, high)))


def log_envelope(values: np.ndarray, low: float, high: float) -> np.ndarray:
    envelope = np.abs(signal.hilbert(fft_bandpass(values, low, high)))
    logged = np.log(envelope + np.finfo(float).eps)
    width = int(round(0.2 * SFREQ))
    return np.convolve(logged, np.ones(width) / width, mode="same")


def zscore(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    standard_deviation = float(np.std(values))
    if standard_deviation <= 0 or not np.isfinite(standard_deviation):
        return np.zeros_like(values)
    return (values - float(np.mean(values))) / standard_deviation


def circular_product_curve(left: np.ndarray, right: np.ndarray) -> np.ndarray:
    """Return mean(left[t] * roll(right, shift)[t]) for every circular shift."""
    left_fft = np.fft.fft(np.asarray(left))
    conjugated_right_fft = np.fft.fft(np.conj(np.asarray(right)))
    return np.fft.ifft(left_fft * np.conj(conjugated_right_fft)) / left.size


def generic_stats(observed: float, surrogate_values: np.ndarray) -> tuple[float, float, float, float]:
    surrogate_values = np.asarray(surrogate_values, dtype=float)
    surrogate_values = surrogate_values[np.isfinite(surrogate_values)]
    mean = float(np.mean(surrogate_values))
    standard_deviation = float(np.std(surrogate_values, ddof=1))
    z_value = (
        float((observed - mean) / standard_deviation)
        if standard_deviation > 1e-12
        else 0.0
    )
    p_value = float((np.sum(surrogate_values >= observed) + 1) / (surrogate_values.size + 1))
    return mean, standard_deviation, z_value, p_value


def circular_shift_indices(
    n_samples: int, n_surrogates: int, rng: np.random.Generator
) -> np.ndarray:
    minimum = int(round(SFREQ))
    maximum = n_samples - minimum
    if maximum <= minimum:
        raise ValueError("Signal is too short for one-second constrained shifts.")
    return rng.integers(minimum, maximum + 1, size=n_surrogates)


def estimate_pac(values: np.ndarray, shifts: np.ndarray) -> tuple[float, float, float, float, float]:
    phase = analytic_phase(values, 4.0, 8.0)
    amplitude = np.abs(signal.hilbert(fft_bandpass(values, 30.0, 55.0)))
    amplitude = amplitude / max(float(np.mean(amplitude)), np.finfo(float).eps)
    phase_vector = np.exp(1j * phase)
    observed = float(np.abs(np.mean(phase_vector * amplitude)))
    curve = np.abs(circular_product_curve(phase_vector, amplitude))
    surrogate_values = curve[shifts]
    mean, standard_deviation, z_value, p_value = generic_stats(observed, surrogate_values)
    return observed, mean, standard_deviation, z_value, p_value


def estimate_ppc(values: np.ndarray, shifts: np.ndarray) -> tuple[float, float, float, float, float]:
    low_phase = analytic_phase(values, 4.0, 6.0)
    high_phase = analytic_phase(values, 9.0, 11.0)
    left = np.exp(1j * 2.0 * low_phase)
    right = np.exp(-1j * high_phase)
    observed = float(np.abs(np.mean(left * right)))
    curve = np.abs(circular_product_curve(left, right))
    surrogate_values = curve[shifts]
    mean, standard_deviation, z_value, p_value = generic_stats(observed, surrogate_values)
    return observed, mean, standard_deviation, z_value, p_value


def estimate_aac(values: np.ndarray, shifts: np.ndarray) -> tuple[float, float, float, float, float]:
    left = zscore(log_envelope(values, 8.0, 13.0))[::10]
    right = zscore(log_envelope(values, 30.0, 55.0))[::10]
    scaled_shifts = np.maximum(1, np.rint(shifts / 10.0).astype(int)) % left.size
    observed = float(np.mean(left * right))
    curve = np.real(circular_product_curve(left, right))
    surrogate_values = curve[scaled_shifts]
    mean, standard_deviation, z_value, p_value = generic_stats(observed, surrogate_values)
    return observed, mean, standard_deviation, z_value, p_value


def estimate_bicoherence(
    values: np.ndarray,
    n_surrogates: int,
    rng: np.random.Generator,
    module: Any,
) -> tuple[float, float, float, float, float]:
    spectrum, frequencies, info = module.compute_fft_windows(values, SFREQ)
    index_1 = module.nearest_frequency_index(frequencies, 8.0)
    index_2 = module.nearest_frequency_index(frequencies, 32.0)
    index_3 = module.nearest_frequency_index(frequencies, 40.0)
    observed, product, denominator = module.bicoherence_from_components(
        spectrum[:, index_1], spectrum[:, index_2], spectrum[:, index_3]
    )
    permutations = np.vstack(
        [rng.permutation(int(info["window_count"])) for _ in range(n_surrogates)]
    )
    mean, standard_deviation, z_value, p_value = module.surrogate_stats(
        product, spectrum[:, index_3], denominator, observed, permutations
    )
    return observed, mean, standard_deviation, z_value, p_value


def estimate_coherence(
    values: np.ndarray,
    n_surrogates: int,
    rng: np.random.Generator,
    module: Any,
) -> tuple[float, float, float, float, float]:
    low_signal = module.fft_bandpass(values, SFREQ, 4.0, 8.0)
    high_envelope = module.amplitude_envelope_from_band(values, SFREQ, 30.0, 55.0)
    low_fft, frequencies, info = module.welch_fft(low_signal, SFREQ)
    high_fft, high_frequencies, _ = module.welch_fft(high_envelope, SFREQ)
    if not np.allclose(frequencies, high_frequencies):
        raise ValueError("Welch frequency grids do not match.")
    mask = (frequencies >= 4.0) & (frequencies <= 8.0)
    low_band = low_fft[:, mask]
    high_band = high_fft[:, mask]
    observed, _mean_coherence, _peak_frequency = module.coherence_peak_mean(
        low_band, high_band, frequencies[mask]
    )
    permutations = np.vstack(
        [rng.permutation(int(info["welch_window_count"])) for _ in range(n_surrogates)]
    )
    mean, standard_deviation, z_value, p_value = module.surrogate_stats(
        low_band, high_band, observed, permutations
    )
    return observed, mean, standard_deviation, z_value, p_value


def smooth_gate(t: np.ndarray, duration: float) -> np.ndarray:
    rise = 1.0 / (1.0 + np.exp(-(t - 0.25 * duration) / 0.15))
    fall = 1.0 / (1.0 + np.exp((t - 0.75 * duration) / 0.15))
    return rise * fall


def generate_signal(
    scenario: str, duration: float, rng: np.random.Generator
) -> np.ndarray:
    n_samples = int(round(duration * SFREQ))
    t = np.arange(n_samples) / SFREQ
    phi_low = rng.uniform(0, 2 * np.pi)
    phi_high = rng.uniform(0, 2 * np.pi)
    noise = 0.55 * rng.standard_normal(n_samples)

    if scenario == "independent":
        return np.sin(2 * np.pi * 6 * t + phi_low) + np.sin(
            2 * np.pi * 40 * t + phi_high
        ) + noise

    if scenario in {"transient_pac", "stationary_pac"}:
        low_phase = 2 * np.pi * 6 * t + phi_low
        gate = smooth_gate(t, duration) if scenario == "transient_pac" else np.ones_like(t)
        amplitude = 1.0 + 0.85 * gate * np.cos(low_phase)
        return np.sin(low_phase) + amplitude * np.sin(2 * np.pi * 40 * t + phi_high) + noise

    if scenario == "stationary_ppc":
        low_phase = 2 * np.pi * 5 * t + phi_low
        high_phase = 2.0 * low_phase + 0.4
        return np.sin(low_phase) + np.sin(high_phase) + noise

    if scenario == "common_am":
        raw_modulator = rng.standard_normal(n_samples)
        sos = signal.butter(3, 0.8, btype="lowpass", fs=SFREQ, output="sos")
        modulator = zscore(signal.sosfiltfilt(sos, raw_modulator))
        envelope = np.exp(0.55 * modulator)
        return envelope * np.sin(2 * np.pi * 10 * t + phi_low) + envelope * np.sin(
            2 * np.pi * 40 * t + phi_high
        ) + noise

    if scenario == "quadratic_triad":
        output = np.zeros(n_samples, dtype=float)
        segment_samples = int(round(2.0 * SFREQ))
        for start in range(0, n_samples, segment_samples):
            end = min(start + segment_samples, n_samples)
            local_t = t[start:end]
            phi_1 = rng.uniform(0, 2 * np.pi)
            phi_2 = rng.uniform(0, 2 * np.pi)
            output[start:end] = (
                np.sin(2 * np.pi * 8 * local_t + phi_1)
                + np.sin(2 * np.pi * 32 * local_t + phi_2)
                + np.sin(2 * np.pi * 40 * local_t + phi_1 + phi_2)
            )
        return output + noise

    if scenario == "harmonic_waveform":
        return 1.5 * signal.sawtooth(2 * np.pi * 8 * t + phi_low, width=0.22) + noise

    if scenario == "sharp_transients":
        impulses = np.zeros(n_samples, dtype=float)
        n_events = max(2, int(round(1.5 * duration)))
        locations = rng.choice(
            np.arange(int(0.5 * SFREQ), n_samples - int(0.5 * SFREQ)),
            size=n_events,
            replace=False,
        )
        impulses[locations] = rng.uniform(5.0, 8.0, size=n_events)
        width = int(round(0.012 * SFREQ))
        kernel_t = np.arange(-5 * width, 5 * width + 1)
        kernel = np.exp(-0.5 * (kernel_t / max(width, 1)) ** 2)
        transients = np.convolve(impulses, kernel, mode="same")
        return transients + 0.4 * np.sin(2 * np.pi * 6 * t + phi_low) + noise

    if scenario == "power_ramp":
        ramp = 0.25 + 2.0 * t / duration
        return np.sin(2 * np.pi * 6 * t + phi_low) + ramp * np.sin(
            2 * np.pi * 40 * t + phi_high
        ) + noise

    raise ValueError(scenario)


def summarize(results: pd.DataFrame) -> pd.DataFrame:
    summary = (
        results.groupby(["scenario", "duration_sec", "family"], observed=True)
        .agg(
            median_observed=("observed", "median"),
            median_surrogate_mean=("surrogate_mean", "median"),
            median_z=("z_value", "median"),
            q25_z=("z_value", lambda values: float(np.quantile(values, 0.25))),
            q75_z=("z_value", lambda values: float(np.quantile(values, 0.75))),
            detection_rate=("p_value", lambda values: float(np.mean(np.asarray(values) < 0.05))),
            n_replicates=("replicate", "nunique"),
        )
        .reset_index()
    )
    summary["expected_target"] = summary["scenario"].map(EXPECTED_TARGET)
    return summary


def make_figure(summary: pd.DataFrame, output: Path) -> None:
    plt.rcParams.update(
        {
            "font.family": "Arial",
            "font.size": 8,
            "axes.linewidth": 0.8,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )
    fig, axes = plt.subplots(1, 2, figsize=(7.16, 3.65), constrained_layout=True)
    thirty = summary.loc[summary["duration_sec"] == 30].copy()
    detection = thirty.pivot(index="scenario", columns="family", values="detection_rate").reindex(
        index=SCENARIOS, columns=FAMILIES
    )
    image = axes[0].imshow(detection.to_numpy(), vmin=0, vmax=1, cmap="viridis", aspect="auto")
    axes[0].set_xticks(np.arange(len(FAMILIES)), ["PAC", "PPC", "AAC", "Bicoh.", "CFC coh."], rotation=35, ha="right")
    axes[0].set_yticks(np.arange(len(SCENARIOS)), [name.replace("_", " ") for name in SCENARIOS])
    axes[0].set_title("(a) Detection rate at 30 s", loc="left", fontweight="bold")
    for row in range(detection.shape[0]):
        for column in range(detection.shape[1]):
            value = detection.iloc[row, column]
            axes[0].text(column, row, f"{value:.2f}", ha="center", va="center", color="white" if value < 0.65 else "black", fontsize=6)
    colorbar = fig.colorbar(image, ax=axes[0], fraction=0.045, pad=0.02)
    colorbar.set_label("Empirical p < 0.05")

    focus = summary.loc[
        summary["scenario"].isin(["independent", "transient_pac", "stationary_pac", "stationary_ppc"])
        & summary["family"].isin(["PAC", "PPC"])
    ].copy()
    styles = {
        ("independent", "PAC"): ("#777777", "o", "Independent: PAC"),
        ("transient_pac", "PAC"): ("#E45756", "s", "Transient PAC: PAC"),
        ("stationary_pac", "PAC"): ("#4C78A8", "^", "Stationary PAC: PAC"),
        ("stationary_ppc", "PPC"): ("#16877B", "D", "Stationary PPC: PPC"),
    }
    for key, (color, marker, label) in styles.items():
        data = focus.loc[(focus["scenario"] == key[0]) & (focus["family"] == key[1])].sort_values("duration_sec")
        axes[1].plot(data["duration_sec"], data["detection_rate"], color=color, marker=marker, linewidth=1.3, label=label)
    axes[1].axhline(0.05, color="#666666", linestyle="--", linewidth=0.8)
    axes[1].set_xticks([10, 20, 30])
    axes[1].set_ylim(-0.02, 1.02)
    axes[1].set_xlabel("Window duration (s)")
    axes[1].set_ylabel("Detection rate")
    axes[1].set_title("(b) Circular-shift calibration", loc="left", fontweight="bold")
    axes[1].legend(frameon=False, fontsize=6.5, loc="best")
    axes[1].spines[["top", "right"]].set_visible(False)
    axes[1].grid(axis="y", color="#D9D9D9", linewidth=0.5, alpha=0.7)

    output.mkdir(parents=True, exist_ok=True)
    fig.savefig(output / "synthetic_surrogate_calibration.png", dpi=600, bbox_inches="tight")
    fig.savefig(output / "synthetic_surrogate_calibration.pdf", bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    data_dir = args.output / "01_统计数据"
    figure_dir = args.output / "02_结果图"
    data_dir.mkdir(parents=True, exist_ok=True)
    figure_dir.mkdir(parents=True, exist_ok=True)
    bicoherence = load_module("synthetic_bicoherence", args.bicoherence_module)
    coherence = load_module("synthetic_coherence", args.coherence_module)

    rows = []
    root_seed = np.random.SeedSequence(args.seed)
    tasks = [(scenario, duration, replicate) for scenario in SCENARIOS for duration in (10, 20, 30) for replicate in range(args.replicates)]
    child_seeds = root_seed.spawn(len(tasks))
    for task_index, ((scenario, duration, replicate), seed) in enumerate(zip(tasks, child_seeds), start=1):
        rng = np.random.default_rng(seed)
        values = generate_signal(scenario, float(duration), rng)
        shifts = circular_shift_indices(values.size, args.surrogates, rng)
        estimators = {
            "PAC": lambda: estimate_pac(values, shifts),
            "PPC": lambda: estimate_ppc(values, shifts),
            "AAC": lambda: estimate_aac(values, shifts),
            "Bicoherence": lambda: estimate_bicoherence(values, args.surrogates, rng, bicoherence),
            "CFC_coherence": lambda: estimate_coherence(values, args.surrogates, rng, coherence),
        }
        for family, estimator in estimators.items():
            observed, surrogate_mean, surrogate_std, z_value, p_value = estimator()
            rows.append(
                {
                    "scenario": scenario,
                    "duration_sec": duration,
                    "replicate": replicate,
                    "family": family,
                    "observed": observed,
                    "surrogate_mean": surrogate_mean,
                    "surrogate_std": surrogate_std,
                    "z_value": z_value,
                    "p_value": p_value,
                }
            )
        if task_index % max(1, len(tasks) // 20) == 0:
            print(f"[{task_index}/{len(tasks)}] {100 * task_index / len(tasks):.1f}%", flush=True)

    results = pd.DataFrame(rows)
    summary = summarize(results)
    results.to_parquet(data_dir / "synthetic_surrogate_replicates.parquet", index=False)
    summary.to_csv(
        data_dir / "synthetic_surrogate_summary.csv", index=False, encoding="utf-8-sig"
    )
    metadata = {
        "sampling_frequency_hz": SFREQ,
        "replicates_per_scenario_duration": args.replicates,
        "surrogates_per_estimate": args.surrogates,
        "durations_sec": [10, 20, 30],
        "scenarios": SCENARIOS,
        "families": FAMILIES,
        "random_seed": args.seed,
        "interpretation": "Targeted method calibration, not a full generative model of ictal iEEG.",
    }
    (data_dir / "synthetic_surrogate_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    make_figure(summary, figure_dir)
    print(summary.loc[summary["duration_sec"] == 30].to_string(index=False))


if __name__ == "__main__":
    main()
