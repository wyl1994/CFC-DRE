"""Patient summaries and statistical diagnostics for raw-signal sensitivities.

Scientific definitions follow the frozen author analysis; see REPRODUCE.md.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import shutil
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy.stats as stats
import statsmodels.api as sm


COHORTS = ("Lanzhou", "ds003029", "ds004100")
FAMILIES = ("PAC", "CFC_coherence")
SCENARIO_WINDOWS = {
    "guard_window": ("guard_pre_-12_-2", "guard_post_2_12"),
    "alternative_reference": ("pre_cumulative_10", "post_cumulative_10"),
    "spike_masked": ("pre_cumulative_10", "post_cumulative_10"),
}
SCENARIO_LABELS = {
    "baseline_CAR": "Primary CAR",
    "guard_window": "Guard window",
    "alternative_reference": "Median reference",
    "spike_masked": "Spike-masked",
}


def bh_fdr(values: pd.Series) -> np.ndarray:
    p = values.to_numpy(float)
    out = np.full(len(p), np.nan)
    valid = np.isfinite(p)
    ranked = p[valid]
    if len(ranked) == 0:
        return out
    order = np.argsort(ranked)
    q = ranked[order] * len(ranked) / np.arange(1, len(ranked) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    restored = np.empty_like(q)
    restored[order] = np.clip(q, 0, 1)
    out[valid] = restored
    return out


def rank_biserial(values: np.ndarray) -> float:
    x = np.asarray(values, float)
    x = x[np.isfinite(x) & ~np.isclose(x, 0)]
    if len(x) == 0:
        return 0.0
    ranks = stats.rankdata(np.abs(x))
    return float((ranks[x > 0].sum() - ranks[x < 0].sum()) / ranks.sum())


def summarize(values: np.ndarray, rng: np.random.Generator, repeats: int = 5000) -> dict[str, float | int]:
    x = np.asarray(values, float)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return {"n_patients": 0, "median_effect": math.nan, "ci95_low": math.nan, "ci95_high": math.nan,
                "p_value": math.nan, "rank_biserial": math.nan, "positive_fraction": math.nan}
    boot = np.median(x[rng.integers(0, len(x), size=(repeats, len(x)))], axis=1)
    if np.allclose(x, 0):
        p_value = 1.0
    else:
        p_value = float(stats.wilcoxon(x, zero_method="wilcox", alternative="two-sided", method="auto").pvalue)
    return {
        "n_patients": len(x), "median_effect": float(np.median(x)),
        "ci95_low": float(np.quantile(boot, 0.025)), "ci95_high": float(np.quantile(boot, 0.975)),
        "p_value": p_value, "rank_biserial": rank_biserial(x),
        "positive_fraction": float(np.mean(x > 0)),
    }


def locate_baseline(root: Path) -> tuple[Path, None]:
    family_candidates = list((root / "01_早期五家族区域时间交互" / "01_统计数据").glob("*.csv"))
    family_path = next(path for path in family_candidates if set(pd.read_csv(path, nrows=2).columns) >= {
        "dataset_id", "patient_id", "cfc_family", "family_interaction"
    })
    # This analysis uses the patient-family baseline only. The old unused
    # feature-table lookup imposed the author's archived folder hierarchy.
    return family_path, None


def aggregate_targeted_cfc(raw_root: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    patient_rows: list[pd.DataFrame] = []
    patient_dirs = sorted({path.parent for path in raw_root.rglob("*_targeted_cfc.parquet")})
    for index, patient_dir in enumerate(patient_dirs, 1):
        files = sorted(patient_dir.glob("*_targeted_cfc.parquet"))
        frame = pd.concat([pd.read_parquet(path, columns=[
            "analysis_id", "dataset_id", "patient_id", "recording_id", "channel_name",
            "channel_index_1based", "soz_label", "window_id", "cfc_family", "method", "feature_id", "z_value"
        ]) for path in files], ignore_index=True)
        frame = frame[frame["soz_label"].isin(["SOZ", "NSOZ"]) & frame["cfc_family"].isin(FAMILIES)]
        frame["channel_key"] = frame["channel_index_1based"].astype(str) + "|" + frame["channel_name"].astype(str)
        contact_keys = ["analysis_id", "dataset_id", "patient_id", "channel_key", "soz_label", "window_id",
                        "cfc_family", "method", "feature_id"]
        contact = frame.groupby(contact_keys, observed=True)["z_value"].median().reset_index()
        zone_keys = ["analysis_id", "dataset_id", "patient_id", "soz_label", "window_id",
                     "cfc_family", "method", "feature_id"]
        zone = contact.groupby(zone_keys, observed=True)["z_value"].median().reset_index()
        spatial = zone.pivot(index=["analysis_id", "dataset_id", "patient_id", "window_id", "cfc_family", "method", "feature_id"],
                             columns="soz_label", values="z_value").reset_index()
        spatial = spatial.dropna(subset=["SOZ", "NSOZ"])
        spatial["spatial_effect"] = spatial["SOZ"] - spatial["NSOZ"]
        for scenario, (pre_window, post_window) in SCENARIO_WINDOWS.items():
            part = spatial[spatial["analysis_id"].eq(scenario)]
            pre = part[part["window_id"].eq(pre_window)].drop(columns=["window_id", "SOZ", "NSOZ"])
            post = part[part["window_id"].eq(post_window)].drop(columns=["window_id", "SOZ", "NSOZ"])
            keys = ["analysis_id", "dataset_id", "patient_id", "cfc_family", "method", "feature_id"]
            paired = pre.merge(post, on=keys, suffixes=("_pre", "_post"), validate="one_to_one")
            paired["interaction"] = paired["spatial_effect_post"] - paired["spatial_effect_pre"]
            patient_rows.append(paired[keys + ["spatial_effect_pre", "spatial_effect_post", "interaction"]])
        print(f"CFC aggregation {index}/{len(patient_dirs)} {patient_dir.name}", flush=True)
    features = pd.concat(patient_rows, ignore_index=True)
    family = (features.groupby(["analysis_id", "dataset_id", "patient_id", "cfc_family"], observed=True)["interaction"]
              .median().rename("family_interaction").reset_index())
    return features, family


def family_statistics(family: pd.DataFrame, seed: int) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows = []
    for scenario in family["analysis_id"].unique():
        for group in ("Overall",) + COHORTS:
            part = family[family["analysis_id"].eq(scenario)]
            if group != "Overall":
                part = part[part["dataset_id"].eq(group)]
            for fam in FAMILIES:
                result = summarize(part.loc[part["cfc_family"].eq(fam), "family_interaction"].to_numpy(), rng)
                rows.append({"analysis_id": scenario, "analysis_group": group, "cfc_family": fam, **result})
    output = pd.DataFrame(rows)
    output["q_value"] = output.groupby(["analysis_id", "analysis_group"], observed=True)["p_value"].transform(
        lambda values: bh_fdr(values)
    )
    output["robust_positive"] = output["q_value"].lt(0.05) & output["ci95_low"].gt(0) & output["rank_biserial"].gt(0)
    return output


def cohort_equal_statistics(family: pd.DataFrame, seed: int, repeats: int = 10000) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows = []
    for scenario in family["analysis_id"].unique():
        for fam in FAMILIES:
            part = family[(family["analysis_id"] == scenario) & (family["cfc_family"] == fam)]
            arrays = [part.loc[part["dataset_id"].eq(cohort), "family_interaction"].to_numpy(float) for cohort in COHORTS]
            point = float(np.mean([np.median(values) for values in arrays]))
            boots = np.empty(repeats)
            permutations = np.empty(repeats)
            for i in range(repeats):
                boots[i] = np.mean([np.median(values[rng.integers(0, len(values), len(values))]) for values in arrays])
                permutations[i] = np.mean([np.median(values * rng.choice((-1.0, 1.0), len(values))) for values in arrays])
            rows.append({"analysis_id": scenario, "cfc_family": fam, "cohort_equal_effect": point,
                         "ci95_low": float(np.quantile(boots, .025)), "ci95_high": float(np.quantile(boots, .975)),
                         "signflip_p": float((np.sum(np.abs(permutations) >= abs(point)) + 1) / (repeats + 1))})
    output = pd.DataFrame(rows)
    output["q_value"] = output.groupby("analysis_id", observed=True)["signflip_p"].transform(lambda x: bh_fdr(x))
    return output


def compare_baseline(baseline: pd.DataFrame, sensitivity: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    baseline = baseline[baseline["cfc_family"].isin(FAMILIES)].copy()
    baseline["analysis_id"] = "baseline_CAR"
    baseline = baseline.rename(columns={"family_interaction": "baseline_effect"})
    rows = []
    paired_parts = []
    for scenario in sensitivity["analysis_id"].unique():
        merged = baseline.merge(
            sensitivity[sensitivity["analysis_id"].eq(scenario)],
            on=["dataset_id", "patient_id", "cfc_family"], how="inner", validate="one_to_one",
        )
        merged["difference_from_baseline"] = merged["family_interaction"] - merged["baseline_effect"]
        paired_parts.append(merged)
        for group in ("Overall",) + COHORTS:
            part = merged if group == "Overall" else merged[merged["dataset_id"].eq(group)]
            for fam in FAMILIES:
                x = part[part["cfc_family"].eq(fam)]
                rho = stats.spearmanr(x["baseline_effect"], x["family_interaction"]).statistic if len(x) >= 3 else math.nan
                diff = x["difference_from_baseline"].to_numpy(float)
                p = 1.0 if np.allclose(diff, 0) else float(stats.wilcoxon(diff).pvalue)
                rows.append({"analysis_id": scenario, "analysis_group": group, "cfc_family": fam,
                             "n_patients": len(x), "baseline_median": float(x["baseline_effect"].median()),
                             "sensitivity_median": float(x["family_interaction"].median()),
                             "median_change": float(np.median(diff)), "spearman_rho": float(rho),
                             "sign_agreement": float(np.mean(np.sign(x["baseline_effect"]) == np.sign(x["family_interaction"]))),
                             "positive_direction_fraction": float(np.mean(x["family_interaction"] > 0)),
                             "paired_difference_p": p})
    return pd.concat(paired_parts, ignore_index=True), pd.DataFrame(rows)


def aggregate_power(raw_root: Path) -> pd.DataFrame:
    frame = pd.concat([pd.read_parquet(path) for path in raw_root.rglob("*_power.parquet")], ignore_index=True)
    frame = frame[frame["soz_label"].isin(["SOZ", "NSOZ"])]
    frame["channel_key"] = frame["channel_index_1based"].astype(str) + "|" + frame["channel_name"].astype(str)
    contact_keys = ["dataset_id", "patient_id", "channel_key", "soz_label", "window_id", "band"]
    contact = frame.groupby(contact_keys, observed=True)["log10_power_uv2"].median().reset_index()
    zone_keys = ["dataset_id", "patient_id", "soz_label", "window_id", "band"]
    zone = contact.groupby(zone_keys, observed=True)["log10_power_uv2"].median().reset_index()
    spatial = zone.pivot(index=["dataset_id", "patient_id", "window_id", "band"], columns="soz_label",
                         values="log10_power_uv2").dropna().reset_index()
    spatial["power_spatial"] = spatial["SOZ"] - spatial["NSOZ"]
    keys = ["dataset_id", "patient_id", "band"]
    pre = spatial[spatial["window_id"].eq("pre_cumulative_10")][keys + ["power_spatial"]].rename(columns={"power_spatial": "pre"})
    post = spatial[spatial["window_id"].eq("post_cumulative_10")][keys + ["power_spatial"]].rename(columns={"power_spatial": "post"})
    paired = pre.merge(post, on=keys, validate="one_to_one")
    paired["power_interaction"] = paired["post"] - paired["pre"]
    return paired


def power_control(baseline: pd.DataFrame, power: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    phase = {"delta", "theta", "alpha", "beta"}
    power["power_role"] = np.where(power["band"].isin(phase), "low_frequency", "high_frequency")
    covariates = (power.groupby(["dataset_id", "patient_id", "power_role"], observed=True)["power_interaction"]
                  .median().unstack("power_role").reset_index())
    data = baseline[baseline["cfc_family"].isin(FAMILIES)].merge(covariates, on=["dataset_id", "patient_id"], validate="many_to_one")
    rows = []
    adjusted_parts = []
    rng = np.random.default_rng(seed)
    for fam in FAMILIES:
        part = data[data["cfc_family"].eq(fam)].copy()
        for column in ("low_frequency", "high_frequency"):
            part[column + "_z"] = (part[column] - part[column].mean()) / part[column].std(ddof=1)
        cohort_dummies = pd.get_dummies(part["dataset_id"], prefix="cohort", drop_first=True, dtype=float)
        design = sm.add_constant(pd.concat([part[["low_frequency_z", "high_frequency_z"]], cohort_dummies], axis=1))
        model = sm.OLS(part["family_interaction"].to_numpy(float), design.to_numpy(float)).fit(cov_type="HC3")
        names = list(design.columns)
        beta_low = float(model.params[names.index("low_frequency_z")])
        beta_high = float(model.params[names.index("high_frequency_z")])
        part["power_adjusted_effect"] = part["family_interaction"] - beta_low * part["low_frequency_z"] - beta_high * part["high_frequency_z"]
        adjusted_parts.append(part)
        adjusted_summary = summarize(part["power_adjusted_effect"].to_numpy(), rng)
        rows.append({"cfc_family": fam, "model_n": len(part), "model_r_squared": float(model.rsquared),
                     "beta_low_power": beta_low, "p_low_power": float(model.pvalues[names.index("low_frequency_z")]),
                     "beta_high_power": beta_high, "p_high_power": float(model.pvalues[names.index("high_frequency_z")]),
                     **{"adjusted_" + key: value for key, value in adjusted_summary.items()}})
    return pd.concat(adjusted_parts, ignore_index=True), pd.DataFrame(rows)


def aggregate_harmonics(raw_root: Path) -> pd.DataFrame:
    frame = pd.concat([pd.read_parquet(path) for path in raw_root.rglob("*_spike_harmonic.parquet")], ignore_index=True)
    frame = frame[frame["soz_label"].isin(["SOZ", "NSOZ"])]
    frame["channel_key"] = frame["channel_index_1based"].astype(str) + "|" + frame["channel_name"].astype(str)
    metrics = ["harmonics_above_6db", "median_harmonic_excess_db", "max_harmonic_excess_db"]
    contact_keys = ["dataset_id", "patient_id", "channel_key", "soz_label", "window_id", "phase_band"]
    contact = frame.groupby(contact_keys, observed=True)[metrics].median().reset_index()
    zone_keys = ["dataset_id", "patient_id", "soz_label", "window_id", "phase_band"]
    zone = contact.groupby(zone_keys, observed=True)[metrics].median().reset_index()
    outputs = []
    for metric in metrics:
        spatial = zone.pivot(index=["dataset_id", "patient_id", "window_id", "phase_band"], columns="soz_label", values=metric).dropna().reset_index()
        spatial["spatial"] = spatial["SOZ"] - spatial["NSOZ"]
        keys = ["dataset_id", "patient_id", "phase_band"]
        pre = spatial[spatial["window_id"].eq("pre_cumulative_10")][keys + ["spatial"]].rename(columns={"spatial": "pre"})
        post = spatial[spatial["window_id"].eq("post_cumulative_10")][keys + ["spatial"]].rename(columns={"spatial": "post"})
        paired = pre.merge(post, on=keys, validate="one_to_one")
        paired["interaction"] = paired["post"] - paired["pre"]
        paired["diagnostic_metric"] = metric
        outputs.append(paired)
    return pd.concat(outputs, ignore_index=True)


def harmonic_associations(baseline: pd.DataFrame, harmonic: pd.DataFrame) -> pd.DataFrame:
    patient_diag = (harmonic.groupby(["dataset_id", "patient_id", "diagnostic_metric"], observed=True)["interaction"]
                    .median().unstack("diagnostic_metric").reset_index())
    pac = baseline[baseline["cfc_family"].eq("PAC")].merge(patient_diag, on=["dataset_id", "patient_id"], validate="one_to_one")
    rows = []
    for metric in [column for column in patient_diag.columns if column not in ("dataset_id", "patient_id")]:
        rho, p = stats.spearmanr(pac["family_interaction"], pac[metric])
        rows.append({"diagnostic_metric": metric, "n_patients": len(pac), "spearman_rho_with_PAC": float(rho), "p_value": float(p)})
    output = pd.DataFrame(rows)
    output["q_value"] = bh_fdr(output["p_value"])
    return output


def make_figures(stats_frame: pd.DataFrame, paired: pd.DataFrame, power_data: pd.DataFrame,
                 output: Path) -> None:
    plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
    colors = {"baseline_CAR": "#243B5A", "guard_window": "#2A9D8F", "alternative_reference": "#E9A23B", "spike_masked": "#C44E52"}
    overall = stats_frame[stats_frame["analysis_group"].eq("Overall")].copy()
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.2), sharey=True)
    for ax, fam in zip(axes, FAMILIES):
        part = overall[overall["cfc_family"].eq(fam)]
        for i, scenario in enumerate(("baseline_CAR", "guard_window", "alternative_reference", "spike_masked")):
            row = part[part["analysis_id"].eq(scenario)].iloc[0]
            ax.errorbar(row["median_effect"], i, xerr=[[row["median_effect"] - row["ci95_low"]], [row["ci95_high"] - row["median_effect"]]],
                        fmt="o", color=colors[scenario], capsize=3, markersize=6)
        ax.axvline(0, color="#777777", linestyle="--", linewidth=1)
        ax.set_yticks(range(4), [SCENARIO_LABELS[x] for x in ("baseline_CAR", "guard_window", "alternative_reference", "spike_masked")])
        ax.set_title(fam.replace("_", " "))
        ax.set_xlabel("Patient-level interaction (median z)")
    fig.suptitle("Robustness of onset-related SOZ-relative CFC effects", fontweight="bold")
    fig.tight_layout()
    fig.savefig(output / "Fig9_四项原始信号敏感性森林图.png", dpi=300, bbox_inches="tight")
    fig.savefig(output / "Fig9_四项原始信号敏感性森林图.pdf", bbox_inches="tight")
    plt.close(fig)

    fig, axes = plt.subplots(2, 3, figsize=(12, 7.2))
    scenarios = ("guard_window", "alternative_reference", "spike_masked")
    for row_index, fam in enumerate(FAMILIES):
        for col_index, scenario in enumerate(scenarios):
            ax = axes[row_index, col_index]
            part = paired[(paired["cfc_family"] == fam) & (paired["analysis_id_y"] == scenario)]
            for cohort, color in zip(COHORTS, ("#E76F51", "#457B9D", "#2A9D8F")):
                sub = part[part["dataset_id"].eq(cohort)]
                ax.scatter(sub["baseline_effect"], sub["family_interaction"], s=22, alpha=.75, label=cohort, color=color)
            limits = np.nanpercentile(np.r_[part["baseline_effect"], part["family_interaction"]], [1, 99])
            ax.plot(limits, limits, "--", color="#777777", linewidth=1)
            rho = stats.spearmanr(part["baseline_effect"], part["family_interaction"]).statistic
            ax.set_title(f"{fam.replace('_', ' ')} | {SCENARIO_LABELS[scenario]}\nrho={rho:.2f}")
            ax.set_xlabel("Primary CAR effect")
            ax.set_ylabel("Sensitivity effect")
    axes[0, 2].legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(output / "Fig10_患者级敏感性与主结果一致性.png", dpi=300, bbox_inches="tight")
    fig.savefig(output / "Fig10_患者级敏感性与主结果一致性.pdf", bbox_inches="tight")
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(9.5, 4))
    for ax, fam in zip(axes, FAMILIES):
        part = power_data[power_data["cfc_family"].eq(fam)]
        ax.scatter(part["low_frequency"], part["family_interaction"], s=25, alpha=.75, color="#457B9D", label="Low-frequency power")
        ax.scatter(part["high_frequency"], part["family_interaction"], s=25, alpha=.65, color="#E76F51", label="High-frequency power")
        ax.axhline(0, color="#888888", linewidth=1)
        ax.set_title(fam.replace("_", " "))
        ax.set_xlabel("Power spatial-time interaction (log10)")
        ax.set_ylabel("Primary CFC interaction")
    axes[0].legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(output / "Fig11_CFC与功率交互关系.png", dpi=300, bbox_inches="tight")
    fig.savefig(output / "Fig11_CFC与功率交互关系.pdf", bbox_inches="tight")
    plt.close(fig)


def write_report(output: Path, stats_frame: pd.DataFrame, cohort_equal: pd.DataFrame,
                 comparisons: pd.DataFrame, power_stats: pd.DataFrame, harmonic_stats: pd.DataFrame) -> None:
    overall = stats_frame[stats_frame["analysis_group"].eq("Overall")]
    lines = [
        "# 实验三四项原始信号补充检查：方案、结果与分析", "", "## 1. 分析目的", "",
        "本轮分析检验新版实验三中 PAC 与 CFC coherence 的区域×时间交互是否依赖发作起始瞬间、宽带功率变化、尖波/谐波结构或 CAR 参考方式。所有统计均以患者为独立单位。",
        "", "## 2. 数据与层级汇总", "", "- 81名患者，269条发作记录。", "- 每条记录均完成保护窗、中位数参考、去尖波重算，以及频带功率和谐波诊断。",
        "- 发作先在患者-通道内取中位数，再在SOZ和NSOZ通道内取中位数；最终计算 `(SOZpost-NSOZpost)-(SOZpre-NSOZpre)`。",
        "- PAC保留45个特征，CFC coherence保留16个特征；家族效应为患者内特征中位数。", "",
        "## 3. 四项检查方案", "", "### 3.1 起始保护窗", "",
        "以 -12至-2 s 和 2至12 s 替代 -10至0 s 和 0至10 s，去除起始点两侧各2 s，判断结果是否由标注误差、滤波瞬态或起始尖锐波形驱动。",
        "", "### 3.2 功率控制", "", "计算四个低频段和四个高频段的患者级功率区域×时间交互，以低频功率、高频功率和队列固定效应解释主CFC效应，并检验扣除功率贡献后的方向。",
        "", "### 3.3 尖波与谐波诊断", "", "采用6×MAD幅值/一阶差分阈值识别尖锐瞬变，向两侧扩展100 ms并线性插值后，重新计算PAC和CFC coherence；同时量化低频主峰整数倍处超过局部背景6 dB的谐波负担。",
        "", "### 3.4 替代参考方式", "", "将CAR改为全通道中位数参考后完整重算，检验结论是否依赖平均参考。", "",
        "## 4. 主要结果", "",
    ]
    for scenario in ("baseline_CAR", "guard_window", "alternative_reference", "spike_masked"):
        lines += [f"### 4.{1 + list(('baseline_CAR','guard_window','alternative_reference','spike_masked')).index(scenario)} {SCENARIO_LABELS[scenario]}", ""]
        for fam in FAMILIES:
            row = overall[(overall["analysis_id"] == scenario) & (overall["cfc_family"] == fam)].iloc[0]
            lines.append(f"- **{fam}**：中位效应 {row.median_effect:.4f}，95% CI [{row.ci95_low:.4f}, {row.ci95_high:.4f}]，q={row.q_value:.4g}，正向患者比例 {row.positive_fraction:.1%}。")
        lines.append("")
    lines += ["## 5. 与主分析的一致性", ""]
    for _, row in comparisons[comparisons["analysis_group"].eq("Overall")].iterrows():
        lines.append(f"- {SCENARIO_LABELS[row.analysis_id]} / {row.cfc_family}：患者级 rho={row.spearman_rho:.3f}，方向一致率 {row.sign_agreement:.1%}，相对主分析中位变化 {row.median_change:.4f}。")
    lines += ["", "## 6. 功率控制", ""]
    for _, row in power_stats.iterrows():
        lines.append(f"- **{row.cfc_family}**：模型 R²={row.model_r_squared:.3f}；低频功率 beta={row.beta_low_power:.3f} (p={row.p_low_power:.3g})，高频功率 beta={row.beta_high_power:.3f} (p={row.p_high_power:.3g})；功率调整后中位效应 {row.adjusted_median_effect:.4f}，95% CI [{row.adjusted_ci95_low:.4f}, {row.adjusted_ci95_high:.4f}]，p={row.adjusted_p_value:.3g}。")
    lines += ["", "## 7. 谐波关联", ""]
    for _, row in harmonic_stats.iterrows():
        lines.append(f"- {row.diagnostic_metric} 与PAC患者级效应：rho={row.spearman_rho_with_PAC:.3f}，q={row.q_value:.3g}。")
    lines += ["", "## 8. 中心等权结果", ""]
    for _, row in cohort_equal.iterrows():
        lines.append(f"- {SCENARIO_LABELS[row.analysis_id]} / {row.cfc_family}：中心等权效应 {row.cohort_equal_effect:.4f}，95% CI [{row.ci95_low:.4f}, {row.ci95_high:.4f}]，q={row.q_value:.3g}。")
    lines += ["", "## 9. 解释原则", "", "只有当效应在保护窗、替代参考和去尖波分析中保持同向，同时功率调整后仍存在，才能将其描述为不完全由起始瞬态、参考方式或频带功率单独解释的稳健CFC表型。谐波诊断不能证明真实神经通信，只能限制非正弦波形解释。", ""]
    (output / "实验三_四项原始信号补充检查_详细报告.md").write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-root", type=Path, required=True)
    parser.add_argument("--experiment-root", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=20260918)
    args = parser.parse_args()
    section = args.experiment_root / "07_关键敏感性分析"
    data_out, figure_out, code_out = section / "01_统计数据", section / "02_结果图", section / "03_分析代码"
    for path in (data_out, figure_out, code_out):
        path.mkdir(parents=True, exist_ok=True)

    baseline_path, baseline_feature_path = locate_baseline(args.experiment_root)
    baseline = pd.read_csv(baseline_path)
    baseline = baseline[baseline["cfc_family"].isin(FAMILIES)].copy()
    print("Aggregating targeted CFC...", flush=True)
    targeted_features, targeted_family = aggregate_targeted_cfc(args.raw_root)
    baseline_for_stats = baseline.rename(columns={"family_interaction": "family_interaction"}).copy()
    baseline_for_stats["analysis_id"] = "baseline_CAR"
    all_family = pd.concat([baseline_for_stats[["analysis_id", "dataset_id", "patient_id", "cfc_family", "family_interaction"]], targeted_family], ignore_index=True)
    stats_frame = family_statistics(all_family, args.seed)
    cohort_equal = cohort_equal_statistics(all_family, args.seed + 1)
    paired, comparisons = compare_baseline(baseline, targeted_family)

    print("Aggregating power and fitting patient-level models...", flush=True)
    power = aggregate_power(args.raw_root)
    power_adjusted, power_stats = power_control(baseline, power, args.seed + 2)
    print("Aggregating harmonic diagnostics...", flush=True)
    harmonics = aggregate_harmonics(args.raw_root)
    harmonic_stats = harmonic_associations(baseline, harmonics)

    targeted_features.to_parquet(data_out / "原始信号敏感性_患者级61特征交互.parquet", index=False)
    all_family.to_csv(data_out / "原始信号敏感性_患者级家族效应.csv", index=False, encoding="utf-8-sig")
    stats_frame.to_csv(data_out / "原始信号敏感性_合并与分队列统计.csv", index=False, encoding="utf-8-sig")
    cohort_equal.to_csv(data_out / "原始信号敏感性_中心等权推断.csv", index=False, encoding="utf-8-sig")
    comparisons.to_csv(data_out / "原始信号敏感性_与主分析一致性.csv", index=False, encoding="utf-8-sig")
    paired.to_parquet(data_out / "原始信号敏感性_患者级配对明细.parquet", index=False)
    power.to_csv(data_out / "功率控制_患者级频带交互.csv", index=False, encoding="utf-8-sig")
    power_adjusted.to_csv(data_out / "功率控制_患者级调整结果.csv", index=False, encoding="utf-8-sig")
    power_stats.to_csv(data_out / "功率控制_回归与调整效应.csv", index=False, encoding="utf-8-sig")
    harmonics.to_csv(data_out / "尖波谐波诊断_患者级交互.csv", index=False, encoding="utf-8-sig")
    harmonic_stats.to_csv(data_out / "尖波谐波诊断_与PAC关联.csv", index=False, encoding="utf-8-sig")

    make_figures(stats_frame, paired, power_adjusted, figure_out)
    write_report(section, stats_frame, cohort_equal, comparisons, power_stats, harmonic_stats)
    shutil.copy2(Path(__file__), code_out / Path(__file__).name)
    status = {"status": "complete", "records": len(list(args.raw_root.rglob("*_targeted_cfc.parquet"))), "patients": int(all_family["patient_id"].nunique()),
              "families": list(FAMILIES), "raw_cfc_files": len(list(args.raw_root.rglob("*_targeted_cfc.parquet"))),
              "outputs_sha256": {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in data_out.glob("*") if path.is_file()}}
    (section / "run_status_raw_sensitivity.json").write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(status, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
