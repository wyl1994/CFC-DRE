"""Frozen 282-feature dynamic sensitivity, adapted from compute_experiment3_282_primary.py.

Only input/output discovery is changed. Preserve family order and the shared RNG
stream: changing either changes the finite-resample estimates.
"""
from pathlib import Path

import numpy as np
import pandas as pd

from . import dynamics as mod


def run(patient_root: Path, output: Path):
    inputs = mod.locate_inputs(patient_root)
    early = pd.read_parquet(inputs.early)
    catalog = pd.read_csv(inputs.catalog)
    high_mask = catalog[["band_1", "band_2"]].eq("fast_ripple_low").any(axis=1)
    allowed = set(catalog.loc[~high_mask, "feature_id"])
    if len(allowed) != 282:
        raise ValueError("Expected 282 features after excluding upper-ripple band entries")
    restricted = early[early.feature_id.isin(allowed)].copy()
    patient = mod.family_patient_effects(restricted)
    rng = np.random.default_rng(20261918)
    center = pd.DataFrame([mod.center_equal_test(patient, family, 3000, 10000, rng) for family in mod.FAMILIES])
    center["q_value"] = mod.bh_fdr(center.permutation_p_value)
    center["robust_center_equal"] = (center.q_value.lt(.05)
        & (center.ci95_low.gt(0) | center.ci95_high.lt(0)) & center.all_cohorts_same_direction)
    global_test = pd.DataFrame([mod.global_family_permutation(restricted, family, 5000, rng) for family in mod.FAMILIES])
    global_test["q_value"] = mod.bh_fdr(global_test.global_sign_flip_p_value)
    output.mkdir(parents=True, exist_ok=True)
    center.to_csv(output / "upper_ripple_center_equal.csv", index=False)
    global_test.to_csv(output / "upper_ripple_global_permutation.csv", index=False)
    from ..io import write_metadata
    write_metadata(output, {"features": 282, "seed": 20261918, "bootstrap": 3000,
                           "permutations": 10000, "global_permutations": 5000}, (inputs.early, inputs.catalog))
