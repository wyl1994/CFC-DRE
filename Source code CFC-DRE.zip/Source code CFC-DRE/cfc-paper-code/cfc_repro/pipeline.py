"""Portable orchestration around the frozen study estimators and aggregation functions."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from .core import formal, metrics, surrogates
from .io import read_manifests, sha256, write_metadata, assert_run_identity


SIX_WINDOWS = ("pre_temporal_early", "pre_temporal_middle", "pre_cumulative_10",
               "post_cumulative_10", "post_temporal_middle", "post_temporal_late")


def configure(mode: str, count: int, device: str, rank_policy="ordinal_frozen"):
    """Configure one computation process; window length changes its Welch segmentation."""
    if count < 2:
        raise ValueError("At least two surrogates are required for sample standard deviation")
    if device == "cuda":
        if metrics.torch is None or not metrics.torch.cuda.is_available():
            raise RuntimeError("CUDA was requested but a CUDA-enabled PyTorch environment is unavailable")
        metrics.DEVICE = metrics.torch.device("cuda")
    elif device == "cpu":
        metrics.DEVICE = None
    else:
        raise ValueError("device must be cpu or cuda")
    if mode not in ("spatial", "dynamic", "raw_sensitivity", "conservative_spikes"):
        raise ValueError(f"Unknown computation mode: {mode}")
    metrics.RANK_POLICY = rank_policy
    surrogates.COUNTS = (count,)
    formal.N_SURROGATES = count
    formal.FORMAL_SEED = 20260916 if mode == "dynamic" else 20260908
    metrics.COHERENCE.WELCH_WINDOW_SEC = 2.0 if mode == "dynamic" else 4.0
    formal.WINDOW_IDS = SIX_WINDOWS if mode == "dynamic" else ("pre_cumulative_30", "post_cumulative_30")
    return [w for w in metrics.WINDOWS if w.window_id in formal.WINDOW_IDS]


def compute_records(seizures: Path, channels: Path, output: Path, mode="spatial",
                    count=1000, device="cpu", data_root=None, max_records=0, recording_id="",
                    rank_policy="ordinal_frozen"):
    """Write one contact/window/feature Parquet shard per retained recording.

    Manifests supply clinical labels and onset; all retained contacts participate
    in referencing. Resume is allowed only for the identical run identity.
    """
    windows = configure(mode, count, device, rank_policy)
    records, groups = read_manifests(seizures, channels, data_root)
    if recording_id:
        records = [r for r in records if r["recording_id"] == recording_id]
    if max_records:
        records = records[:max_records]
    if not records:
        raise ValueError("No recordings match the requested selection")
    output.mkdir(parents=True, exist_ok=True)
    # Refuse to silently resume shards generated with different inputs, code, or settings.
    identity = {"mode": mode, "surrogates": count, "device": device, "rank_policy": rank_policy,
                "seed": formal.FORMAL_SEED, "welch_window_sec": metrics.COHERENCE.WELCH_WINDOW_SEC,
                "windows": [w.window_id for w in windows], "recordings": [r["recording_id"] for r in records],
                "seizures_sha256": sha256(seizures), "channels_sha256": sha256(channels),
                "code_sha256": {Path(m.__file__).name: sha256(Path(m.__file__))
                                for m in (metrics, metrics.preprocessing, surrogates, formal, metrics.PAC, metrics.BICOHERENCE, metrics.COHERENCE)}}
    assert_run_identity(output, identity)
    log = []
    for index, record in enumerate(records, 1):
        contacts = groups[(record["dataset_id"], record["recording_id"])]
        target = output / "shards" / formal.safe_name(record["dataset_id"]) / formal.safe_name(record["patient_id"]) / (formal.safe_name(record["recording_id"]) + ".parquet")
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists() and formal.parquet_rows(target) == formal.expected_rows(len(contacts)):
            print(f"[{index}/{len(records)}] Reusing complete shard: {record['recording_id']}", flush=True)
            continue
        print(f"[{index}/{len(records)}] Computing {record['recording_id']} ({len(contacts)} contacts)", flush=True)
        log.append(formal.process_record(record, contacts, windows, target))
        pd.DataFrame(log).to_csv(output / "runtime.csv", index=False)
    write_metadata(output, identity, (seizures, channels))


def demo(example: Path, output: Path, count=20, device="cpu", all_windows=False):
    """Compute 312 features per contact/window from an already processed NPZ.

    Output differences are descriptive for one subject, not group inference.
    Do not filter or re-reference this four-contact input a second time.
    """
    windows = configure("dynamic", count, device)
    if not all_windows:
        windows = [w for w in windows if w.window_id in ("pre_cumulative_10", "post_cumulative_10")]
    with np.load(example, allow_pickle=False) as content:
        values = content["signal_uv"].astype(np.float64)
        names = content["channel_names"].astype(str)
        labels = content["soz_labels"].astype(str)
        sfreq = float(content["sfreq_hz"])
    if values.shape != (len(names), 34000) or sfreq != 500:
        raise ValueError("Example must contain 68 buffered seconds at 500 Hz")
    if len(labels) != len(names) or len(set(names)) != len(names) or set(labels) != {"SOZ", "NSOZ"} or not np.isfinite(values).all():
        raise ValueError("Example requires finite signals, unique contacts, and both SOZ/NSOZ labels")
    rows = []
    for channel, values_i, label in zip(names, values, labels):
        print(f"Computing example contact {channel} ({label})", flush=True)
        components = metrics.build_components(values_i)
        metadata = {"dataset_id": "ds003029", "patient_id": "example-public-01",
                    "recording_id": "example-recording-01", "channel_name": channel, "soz_label": label}
        for window in windows:
            part = surrogates.compute_window(metadata, window, values_i, components, formal.FORMAL_SEED)
            for row in part:
                row.update(window_start_sec=window.start_sec, window_end_sec=window.end_sec)
            rows.extend(part)
    frame = pd.DataFrame(rows)
    # Archived rows use empty strings for inapplicable frequency fields. Give
    # Parquet a stable numeric schema rather than a mixed string/float column.
    for field in formal.FLOAT_FIELDS:
        if field in frame:
            frame[field] = pd.to_numeric(frame[field], errors="coerce").astype("float64")
    if not frame.finite_pass.eq(1).all() or frame.zero_surrogate_variance.any():
        raise ValueError("Example contains invalid surrogate results")
    output.mkdir(parents=True, exist_ok=True)
    frame.to_parquet(output / "contact_window_features.parquet", index=False)
    region = frame.groupby(["window_id", "cfc_family", "method", "feature_id", "soz_label"], sort=False).z_value.median().unstack("soz_label")
    region["contrast"] = region.SOZ - region.NSOZ
    paired = region.contrast.unstack("window_id")
    paired["interaction"] = paired.post_cumulative_10 - paired.pre_cumulative_10
    paired.reset_index().to_csv(output / "example_feature_interactions.csv", index=False)
    summary = paired.groupby(level="cfc_family").interaction.median()
    summary.to_csv(output / "example_family_interactions.csv")
    write_metadata(output, {"example_only": True, "patients": 1, "contacts": len(names),
                           "surrogates": count, "seed": formal.FORMAL_SEED, "device": device,
                           "windows": [w.window_id for w in windows], "preprocessed_input": True}, (example,))
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(6.2, 3.3))
    summary.reindex(["PAC", "PPC", "AAC", "Bicoherence", "CFC_coherence"]).plot.bar(ax=ax, color="#387E96", width=.6)
    ax.axhline(0, color="#777777", linewidth=.6)
    ax.set_ylabel("Change in regional contrast")
    ax.set_xlabel("")
    ax.set_xticklabels(["PAC", "PPC", "AAC", "Bicoherence", "CFC coherence"], rotation=20, ha="right")
    ax.set_title("Public example: 1 subject, 4 selected contacts")
    fig.tight_layout()
    fig.savefig(output / "example_interactions.png", dpi=180)
    plt.close(fig)
    print(f"Example complete: {len(frame)} contact-window-feature rows. Output: {output}", flush=True)


def aggregate(spatial_shards: Path, dynamic_shards: Path, eligibility_path: Path, output: Path):
    """Build patient tables from shards and clinically annotated eligibility.

    Seizures are summarized within contact before contacts within region.
    Paired regional differences and then pre/post interactions are formed
    within patient; pooled regional medians cannot replace these operations.
    """
    from .analysis import spatial_aggregation as sa, window_aggregation as wa
    eligibility = pd.read_csv(eligibility_path)
    required = {"dataset_id", "recording_id", "start_sec", "window_state_status", "offset_status"}
    if required - set(eligibility.columns):
        raise ValueError(f"Eligibility table lacks {sorted(required - set(eligibility.columns))}")
    output.mkdir(parents=True, exist_ok=True)
    (_, patient, _, _), catalog = sa.collect_patient_summaries(spatial_shards)
    patient.to_parquet(output / "patient_spatial_0_30.parquet", index=False)
    # Feature traversal consumes a shared bootstrap stream. Preserve the TWO
    # frozen orders rather than letting a cosmetic sort change inference.
    catalog.to_csv(output / "spatial_feature_catalog.csv", index=False)
    catalog.sort_values(["cfc_family", "method", "feature_id"]).to_csv(output / "feature_catalog.csv", index=False)
    early_set, full_set, confirmed_set = wa.build_record_sets(eligibility)
    groups = {}
    for path in sorted(dynamic_shards.rglob("*.parquet")):
        rel = path.relative_to(dynamic_shards)
        if len(rel.parts) != 3:
            raise ValueError("Dynamic shards must use cohort/patient/recording.parquet directories")
        groups.setdefault((rel.parts[0], rel.parts[1]), []).append(path)
    if not groups:
        raise ValueError("No dynamic shards found")
    accumulated = {name: [] for name in ("early", "full", "mean", "confirmed")}
    qc = []
    for (cohort, patient_id), files in sorted(groups.items()):
        frame = pd.concat([pd.read_parquet(p, columns=list(wa.READ_COLUMNS)) for p in files], ignore_index=True)
        frame = frame[frame.soz_label.isin(["SOZ", "NSOZ"]) & frame.window_id.isin(SIX_WINDOWS) & frame.finite_pass.eq(1) & frame.zero_surrogate_variance.eq(0)]
        frame = frame[np.isfinite(frame[list(wa.VALUE_COLUMNS)]).all(axis=1)]
        keys = set(zip(frame.dataset_id, frame.recording_id))
        for name, permitted, method in (("early", early_set, "median"), ("full", full_set, "median"),
                                        ("mean", full_set, "mean"), ("confirmed", confirmed_set, "median")):
            selected = frame[frame.window_id.isin([wa.PRE_NEAR, wa.POST_EARLY])] if name == "early" else frame
            result = wa.aggregate_zone_window(selected, keys & permitted, method)
            if not result.empty:
                accumulated[name].append(result)
        qc.append({"dataset_id": cohort, "patient_id": patient_id, "records_total": len(files),
                   "records_early_primary": len(keys & early_set), "records_full_trajectory": len(keys & full_set),
                   "records_confirmed_ge30": len(keys & confirmed_set)})
    regions = {}
    for name, parts in accumulated.items():
        if not parts:
            if name == "confirmed":
                regions[name] = regions["full"].iloc[:0].copy()
                continue
            raise ValueError(f"No eligible {name} regional data; check window eligibility annotations")
        regions[name] = pd.concat(parts, ignore_index=True)
    early = wa.early_interaction(wa.spatial_contrast(regions["early"]))
    early.to_parquet(output / "patient_early_interaction_312_features.parquet", index=False)
    regions["early"].to_parquet(output / "patient_zone_early_windows.parquet", index=False)
    regions["full"].to_parquet(output / "patient_zone_six_windows.parquet", index=False)
    for name, target in (("full", "patient_spatial_contrast_six_windows.parquet"),
                         ("mean", "sensitivity_mean_patient_spatial_contrast.parquet"),
                         ("confirmed", "sensitivity_confirmed_ge30_spatial_contrast.parquet")):
        wa.spatial_contrast(regions[name]).to_parquet(output / target, index=False)
    pd.DataFrame(qc).to_csv(output / "patient_processing_qc.csv", index=False)
    eligibility.to_csv(output / "window_state_eligibility_used.csv", index=False)
    write_metadata(output, {"aggregation_order": "seizures within contact; contacts within region", "subjects": len(groups)}, (eligibility_path,))
