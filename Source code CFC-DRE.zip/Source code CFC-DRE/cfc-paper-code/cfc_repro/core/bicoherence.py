"""Segmented spectral helpers for normalized quadratic phase coupling.

The feature grid and surrogate stream are supplied by metrics.py/surrogates.py.
Use cfc_repro compute rather than the retained legacy standalone batch parser.
"""
from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
INPUT_INDEX = PROJECT_ROOT / "outputs" / "cfc_ds004100_fs_ge500_full" / "preprocessed_segments" / "04_cfc_segments_index.csv"
OUTPUT_DIR = PROJECT_ROOT / "outputs" / "cfc_ds004100_fs_ge500_full" / "bicoherence_standard"

RANDOM_SEED = 20260714
DEFAULT_N_SURROGATES = 200
WINDOW_SEC = 2.0
WINDOW_OVERLAP = 0.5
MAX_SUM_FREQ_HZ = 120.0
PROGRESS_INTERVAL_SEC = 10.0

F1_FREQS_HZ = [4.0, 8.0, 12.0, 16.0, 20.0, 24.0, 28.0, 32.0, 36.0, 40.0]
F2_FREQS_HZ = [4.0, 8.0, 12.0, 16.0, 20.0, 24.0, 28.0, 32.0, 36.0, 40.0, 48.0, 56.0, 64.0, 72.0, 80.0]


def read_csv(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    df.columns = [str(col).strip() for col in df.columns]
    return df


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8-sig")


def next_power_of_two(value: int) -> int:
    return int(2 ** math.ceil(math.log2(max(2, value))))


def make_windows(x: np.ndarray, sfreq: float) -> tuple[np.ndarray, int, int]:
    window_samples = int(round(WINDOW_SEC * sfreq))
    step_samples = max(1, int(round(window_samples * (1.0 - WINDOW_OVERLAP))))
    if window_samples <= 1:
        raise ValueError("window length is too short")
    if x.size < window_samples:
        raise ValueError("signal is shorter than one bicoherence window")

    starts = np.arange(0, x.size - window_samples + 1, step_samples, dtype=int)
    windows = np.stack([x[start : start + window_samples] for start in starts], axis=0).astype(np.float64)
    windows -= np.mean(windows, axis=1, keepdims=True)
    taper = np.hanning(window_samples + 1)[:-1]
    windows *= taper[np.newaxis, :]
    return windows, window_samples, step_samples


def compute_fft_windows(x: np.ndarray, sfreq: float) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    windows, window_samples, step_samples = make_windows(x=x, sfreq=sfreq)
    nfft = next_power_of_two(window_samples)
    spectrum = np.fft.rfft(windows, n=nfft, axis=1)
    freqs = np.fft.rfftfreq(nfft, d=1.0 / sfreq)
    info = {
        "window_count": int(windows.shape[0]),
        "window_samples": int(window_samples),
        "window_step_samples": int(step_samples),
        "nfft": int(nfft),
        "frequency_resolution_hz": float(freqs[1] - freqs[0]),
    }
    return spectrum, freqs, info


def nearest_frequency_index(freqs: np.ndarray, target_hz: float) -> int:
    idx = int(np.argmin(np.abs(freqs - target_hz)))
    tolerance = max(0.25, float(freqs[1] - freqs[0]) * 0.75)
    if abs(float(freqs[idx]) - target_hz) > tolerance:
        raise ValueError(f"Cannot map {target_hz} Hz to FFT grid, nearest is {freqs[idx]} Hz")
    return idx


def build_frequency_triplets() -> list[dict[str, float]]:
    triplets: list[dict[str, float]] = []
    for f1 in F1_FREQS_HZ:
        for f2 in F2_FREQS_HZ:
            f3 = f1 + f2
            if f2 < f1:
                continue
            if f3 > MAX_SUM_FREQ_HZ:
                continue
            triplets.append({"f1_hz": f1, "f2_hz": f2, "f3_hz": f3})
    return triplets


def bicoherence_from_components(x1: np.ndarray, x2: np.ndarray, x3: np.ndarray) -> tuple[float, np.ndarray, float]:
    product = x1 * x2
    denominator = float(np.mean(np.abs(product) ** 2) * np.mean(np.abs(x3) ** 2))
    if denominator <= 0 or not np.isfinite(denominator):
        return math.nan, product, math.nan
    numerator = np.abs(np.mean(product * np.conj(x3))) ** 2
    value = float(np.clip(numerator / denominator, 0.0, 1.0))
    return value, product, denominator


def surrogate_stats(
    product: np.ndarray,
    x3: np.ndarray,
    denominator: float,
    observed: float,
    permutations: np.ndarray,
) -> tuple[float, float, float, float]:
    if not np.isfinite(denominator) or denominator <= 0 or not np.isfinite(observed):
        return math.nan, math.nan, math.nan, math.nan

    permuted_x3 = x3[permutations]
    numerators = np.abs(np.mean(product[np.newaxis, :] * np.conj(permuted_x3), axis=1)) ** 2
    values = np.clip(numerators / denominator, 0.0, 1.0)
    values = values[np.isfinite(values)]
    if values.size == 0:
        return math.nan, math.nan, math.nan, math.nan

    mean = float(np.mean(values))
    std = float(np.std(values, ddof=1)) if values.size > 1 else 0.0
    z_value = float((observed - mean) / std) if std > 0 else 0.0
    p_value = float((np.sum(values >= observed) + 1) / (values.size + 1))
    return mean, std, z_value, p_value


def benjamini_hochberg(p_values: pd.Series) -> pd.Series:
    p = pd.to_numeric(p_values, errors="coerce").to_numpy(dtype=float)
    q = np.full(p.shape, np.nan, dtype=float)
    valid = np.isfinite(p)
    if not np.any(valid):
        return pd.Series(q, index=p_values.index)
    p_valid = np.clip(p[valid], 0.0, 1.0)
    order = np.argsort(p_valid)
    ranked = p_valid[order]
    n_tests = ranked.size
    raw_q = ranked * n_tests / np.arange(1, n_tests + 1)
    monotone = np.minimum.accumulate(raw_q[::-1])[::-1]
    restored = np.empty_like(monotone)
    restored[order] = np.clip(monotone, 0.0, 1.0)
    q[valid] = restored
    return pd.Series(q, index=p_values.index)


def add_fdr_columns(results: pd.DataFrame) -> pd.DataFrame:
    out = results.copy()
    out["p_value"] = pd.to_numeric(out["p_value"], errors="coerce")
    out["fdr_q_value"] = benjamini_hochberg(out["p_value"])
    out["p_lt_0_05"] = out["p_value"] < 0.05
    out["fdr_q_lt_0_05"] = out["fdr_q_value"] < 0.05
    out["fdr_scope"] = "all_bicoherence_rows"
    return out


def compute_segment_bicoherence(
    row: pd.Series,
    triplets: list[dict[str, float]],
    n_surrogates: int,
    rng: np.random.Generator,
) -> list[dict[str, Any]]:
    loaded = np.load(row["segment_file"])
    x = np.asarray(loaded["signal"], dtype=np.float64)
    sfreq = float(loaded["sampling_frequency_hz"])
    spectrum, fft_freqs, info = compute_fft_windows(x=x, sfreq=sfreq)
    nyquist = sfreq / 2.0
    n_windows = int(info["window_count"])
    permutations = np.vstack([rng.permutation(n_windows) for _ in range(n_surrogates)])

    index_cache: dict[float, int] = {}

    def freq_index(freq_hz: float) -> int:
        if freq_hz not in index_cache:
            index_cache[freq_hz] = nearest_frequency_index(fft_freqs, freq_hz)
        return index_cache[freq_hz]

    rows: list[dict[str, Any]] = []
    for triplet in triplets:
        f1 = float(triplet["f1_hz"])
        f2 = float(triplet["f2_hz"])
        f3 = float(triplet["f3_hz"])
        if f3 >= nyquist - 1.0:
            continue

        idx1 = freq_index(f1)
        idx2 = freq_index(f2)
        idx3 = freq_index(f3)
        x1 = spectrum[:, idx1]
        x2 = spectrum[:, idx2]
        x3 = spectrum[:, idx3]
        observed, product, denominator = bicoherence_from_components(x1=x1, x2=x2, x3=x3)
        surrogate_mean, surrogate_std, z_value, p_value = surrogate_stats(
            product=product,
            x3=x3,
            denominator=denominator,
            observed=observed,
            permutations=permutations,
        )
        rows.append(
            {
                "segment_id": row["segment_id"],
                "cfc_sample_id": row["cfc_sample_id"],
                "participant_id": row["participant_id"],
                "run_key": row["run_key"],
                "acquisition": row["acquisition"],
                "channel_name": row["channel_name"],
                "channel_name_key": row["channel_name_key"],
                "channel_type": row["channel_type"],
                "soz_label": row["soz_label"],
                "is_soz": row["is_soz"],
                "f1_hz": f1,
                "f2_hz": f2,
                "f3_hz": f3,
                "fft_mapped_f1_hz": float(fft_freqs[idx1]),
                "fft_mapped_f2_hz": float(fft_freqs[idx2]),
                "fft_mapped_f3_hz": float(fft_freqs[idx3]),
                "bicoherence_value": observed,
                "surrogate_mean": surrogate_mean,
                "surrogate_std": surrogate_std,
                "bicoherence_z": z_value,
                "p_value": p_value,
                "n_surrogates": n_surrogates,
                "window_sec": WINDOW_SEC,
                "window_overlap": WINDOW_OVERLAP,
                "final_sampling_frequency_hz": sfreq,
                "nyquist_hz": nyquist,
                "segment_file": row["segment_file"],
                **info,
            }
        )
    return rows


def cohen_d(a: pd.Series, b: pd.Series) -> float:
    x = pd.to_numeric(a, errors="coerce").dropna().to_numpy(dtype=float)
    y = pd.to_numeric(b, errors="coerce").dropna().to_numpy(dtype=float)
    if x.size < 2 or y.size < 2:
        return math.nan
    pooled = math.sqrt(((x.size - 1) * np.var(x, ddof=1) + (y.size - 1) * np.var(y, ddof=1)) / (x.size + y.size - 2))
    if pooled <= 0:
        return 0.0
    return float((np.mean(x) - np.mean(y)) / pooled)


def scope_frames(results: pd.DataFrame) -> list[tuple[str, pd.DataFrame]]:
    frames = [("combined", results)]
    for acquisition in ["ecog", "seeg"]:
        frames.append((f"{acquisition}_only", results[results["acquisition"] == acquisition]))
    return frames


def build_peak_rows(results: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for segment_id, group in results.groupby("segment_id", dropna=False):
        finite = group[np.isfinite(pd.to_numeric(group["bicoherence_z"], errors="coerce"))]
        if finite.empty:
            continue
        peak = finite.sort_values("bicoherence_z", ascending=False).iloc[0]
        rows.append(
            {
                "segment_id": segment_id,
                "cfc_sample_id": peak["cfc_sample_id"],
                "participant_id": peak["participant_id"],
                "run_key": peak["run_key"],
                "acquisition": peak["acquisition"],
                "channel_name": peak["channel_name"],
                "channel_type": peak["channel_type"],
                "soz_label": peak["soz_label"],
                "peak_f1_hz": peak["f1_hz"],
                "peak_f2_hz": peak["f2_hz"],
                "peak_f3_hz": peak["f3_hz"],
                "peak_bicoherence_value": peak["bicoherence_value"],
                "peak_z": peak["bicoherence_z"],
                "peak_p_value": peak["p_value"],
                "peak_fdr_q_value": peak["fdr_q_value"],
                "peak_fdr_q_lt_0_05": peak["fdr_q_lt_0_05"],
                "n_surrogates": peak["n_surrogates"],
            }
        )
    return pd.DataFrame(rows)


def summarize_results(results: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    label_rows: list[dict[str, Any]] = []
    triplet_rows: list[dict[str, Any]] = []
    comparison_rows: list[dict[str, Any]] = []

    for scope, scope_df in scope_frames(results):
        if scope_df.empty:
            continue

        for label, group in scope_df.groupby("soz_label", dropna=False):
            label_rows.append(
                {
                    "analysis_scope": scope,
                    "soz_label": label,
                    "rows": len(group),
                    "segment_count": group["segment_id"].nunique(),
                    "mean_bicoherence_value": float(pd.to_numeric(group["bicoherence_value"]).mean()),
                    "mean_bicoherence_z": float(pd.to_numeric(group["bicoherence_z"]).mean()),
                    "median_bicoherence_z": float(pd.to_numeric(group["bicoherence_z"]).median()),
                    "p_lt_0_05_percent": round(100 * pd.to_numeric(group["p_lt_0_05"]).mean(), 3),
                    "fdr_q_lt_0_05_percent": round(100 * pd.to_numeric(group["fdr_q_lt_0_05"]).mean(), 3),
                }
            )

        for keys, group in scope_df.groupby(["f1_hz", "f2_hz", "f3_hz", "soz_label"], dropna=False):
            f1, f2, f3, label = keys
            triplet_rows.append(
                {
                    "analysis_scope": scope,
                    "f1_hz": f1,
                    "f2_hz": f2,
                    "f3_hz": f3,
                    "soz_label": label,
                    "rows": len(group),
                    "segment_count": group["segment_id"].nunique(),
                    "mean_bicoherence_value": float(pd.to_numeric(group["bicoherence_value"]).mean()),
                    "mean_bicoherence_z": float(pd.to_numeric(group["bicoherence_z"]).mean()),
                    "median_bicoherence_z": float(pd.to_numeric(group["bicoherence_z"]).median()),
                    "fdr_q_lt_0_05_percent": round(100 * pd.to_numeric(group["fdr_q_lt_0_05"]).mean(), 3),
                }
            )

        for keys, group in scope_df.groupby(["f1_hz", "f2_hz", "f3_hz"], dropna=False):
            f1, f2, f3 = keys
            soz = group[group["soz_label"] == "SOZ"]
            non = group[group["soz_label"] == "non-SOZ"]
            comparison_rows.append(
                {
                    "analysis_scope": scope,
                    "f1_hz": f1,
                    "f2_hz": f2,
                    "f3_hz": f3,
                    "soz_rows": len(soz),
                    "non_soz_rows": len(non),
                    "soz_mean_z": float(pd.to_numeric(soz["bicoherence_z"]).mean()) if len(soz) else math.nan,
                    "non_soz_mean_z": float(pd.to_numeric(non["bicoherence_z"]).mean()) if len(non) else math.nan,
                    "soz_minus_non_soz_mean_z": (
                        float(pd.to_numeric(soz["bicoherence_z"]).mean() - pd.to_numeric(non["bicoherence_z"]).mean())
                        if len(soz) and len(non)
                        else math.nan
                    ),
                    "cohen_d_soz_vs_non_soz_z": cohen_d(soz["bicoherence_z"], non["bicoherence_z"]) if len(soz) and len(non) else math.nan,
                    "soz_mean_value": float(pd.to_numeric(soz["bicoherence_value"]).mean()) if len(soz) else math.nan,
                    "non_soz_mean_value": float(pd.to_numeric(non["bicoherence_value"]).mean()) if len(non) else math.nan,
                    "soz_fdr_q_lt_0_05_percent": round(100 * pd.to_numeric(soz["fdr_q_lt_0_05"]).mean(), 3) if len(soz) else math.nan,
                    "non_soz_fdr_q_lt_0_05_percent": round(100 * pd.to_numeric(non["fdr_q_lt_0_05"]).mean(), 3) if len(non) else math.nan,
                }
            )

    comparison = pd.DataFrame(comparison_rows)
    if not comparison.empty:
        comparison = comparison.sort_values(["analysis_scope", "soz_minus_non_soz_mean_z"], ascending=[True, False])
    return pd.DataFrame(label_rows), pd.DataFrame(triplet_rows), comparison


def build_column_dictionary() -> pd.DataFrame:
    rows = [
        ("bicoherence_value", "真实bicoherence值，范围通常在0到1之间"),
        ("bicoherence_z", "真实bicoherence相对于surrogate分布的Z值"),
        ("f1_hz", "第一个频率成分"),
        ("f2_hz", "第二个频率成分"),
        ("f3_hz", "相加频率，等于f1+f2"),
        ("surrogate_mean", "随机打乱短窗顺序后的surrogate平均bicoherence"),
        ("surrogate_std", "surrogate bicoherence标准差"),
        ("p_value", "经验p值，表示surrogate结果大于等于真实结果的比例"),
        ("fdr_q_value", "BH-FDR多重比较校正后的q值"),
        ("analysis_scope", "分析范围：combined为全部，ecog_only只看ECOG，seeg_only只看SEEG"),
        ("soz_minus_non_soz_mean_z", "SOZ平均Z值减去non-SOZ平均Z值"),
        ("cohen_d_soz_vs_non_soz_z", "SOZ与non-SOZ的Z值差异效应量"),
        ("window_sec", "双谱计算使用的短窗长度，单位秒"),
        ("window_overlap", "短窗重叠比例"),
    ]
    return pd.DataFrame(rows, columns=["column", "中文含义"])


def write_summary_md(
    output_dir: Path,
    index_df: pd.DataFrame,
    triplets: list[dict[str, float]],
    results: pd.DataFrame,
    peaks: pd.DataFrame,
    failures: pd.DataFrame,
    label_summary: pd.DataFrame,
    comparison: pd.DataFrame,
    n_surrogates: int,
) -> None:
    top_combined = comparison[comparison["analysis_scope"] == "combined"].head(10) if not comparison.empty else pd.DataFrame()
    lines = [
        "# Step 8 ds004100 双谱耦合 bicoherence 标准版计算报告",
        "",
        "## 1. 这一步做什么",
        "",
        "双谱耦合看的是二阶频率组合关系：如果 f1 和 f2 的相位/能量关系稳定地耦合到 f3，且 f3=f1+f2，那么 bicoherence 会偏高。",
        "",
        "和 PAC/AAC 不同，bicoherence 更强调非线性相位耦合或二次相互作用，所以输出不是两个频段，而是 f1、f2、f3 三元组。",
        "",
        "## 2. 统计口径",
        "",
        f"- 输入文件：`{INPUT_INDEX}`",
        f"- surrogate次数：`{n_surrogates}`",
        f"- 短窗长度：`{WINDOW_SEC}` 秒",
        f"- 短窗重叠：`{WINDOW_OVERLAP}`",
        f"- 候选频率三元组数量：`{len(triplets)}`",
        f"- 最大f1+f2频率：`{MAX_SUM_FREQ_HZ}` Hz",
        "- 多重比较校正：Benjamini-Hochberg FDR。",
        "- 输出三种分析范围：`combined`、`ecog_only`、`seeg_only`。",
        "",
        "## 3. 主要结果规模",
        "",
        f"- 输入片段数：{len(index_df)}",
        f"- 成功片段数：{results['segment_id'].nunique() if not results.empty else 0}",
        f"- 失败片段数：{len(failures)}",
        f"- bicoherence长表行数：{len(results)}",
        f"- 峰值表行数：{len(peaks)}",
        "",
        "## 4. 标签汇总",
        "",
        "| 范围 | 标签 | 片段数 | 平均bicoherence | 平均z值 | 中位z值 | p<0.05比例% | FDR q<0.05比例% |",
        "|---|---|---:|---:|---:|---:|---:|---:|",
    ]
    for _idx, row in label_summary.iterrows():
        lines.append(
            f"| {row.get('analysis_scope', '')} | {row.get('soz_label', '')} | {row.get('segment_count', '')} | "
            f"{float(row.get('mean_bicoherence_value', 0)):.4f} | {float(row.get('mean_bicoherence_z', 0)):.4f} | "
            f"{float(row.get('median_bicoherence_z', 0)):.4f} | {row.get('p_lt_0_05_percent', '')} | "
            f"{row.get('fdr_q_lt_0_05_percent', '')} |"
        )

    lines.extend(
        [
            "",
            "## 5. combined范围内SOZ高于non-SOZ最多的频率三元组",
            "",
            "| f1 Hz | f2 Hz | f3 Hz | SOZ平均z | non-SOZ平均z | 差值 | Cohen d | SOZ FDR显著% | non-SOZ FDR显著% |",
            "|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for _idx, row in top_combined.iterrows():
        lines.append(
            f"| {float(row.get('f1_hz', 0)):.1f} | {float(row.get('f2_hz', 0)):.1f} | {float(row.get('f3_hz', 0)):.1f} | "
            f"{float(row.get('soz_mean_z', 0)):.4f} | {float(row.get('non_soz_mean_z', 0)):.4f} | "
            f"{float(row.get('soz_minus_non_soz_mean_z', 0)):.4f} | {float(row.get('cohen_d_soz_vs_non_soz_z', 0)):.4f} | "
            f"{row.get('soz_fdr_q_lt_0_05_percent', '')} | {row.get('non_soz_fdr_q_lt_0_05_percent', '')} |"
        )

    lines.extend(
        [
            "",
            "## 6. 输出文件说明",
            "",
            "- `08_bicoherence_results_long.csv`：完整双谱耦合长表。",
            "- `08_bicoherence_peak_by_segment.csv`：每个片段中bicoherence_z最高的频率三元组。",
            "- `08_bicoherence_summary_by_scope_label.csv`：按combined/ECOG/SEEG和SOZ标签汇总。",
            "- `08_bicoherence_frequency_triplet_summary.csv`：按频率三元组汇总。",
            "- `08_bicoherence_soz_nonsoz_comparison.csv`：SOZ与non-SOZ在每个三元组上的差异对比表。",
            "- `08_bicoherence_failures.csv`：失败片段记录；如果为空说明没有失败。",
            "- `08_column_dictionary_中文说明.csv`：主要列名中文解释。",
            "- `08_bicoherence_config.json`：本次参数记录。",
            "",
        ]
    )
    (output_dir / "08_bicoherence_standard_summary.md").write_text("\n".join(lines), encoding="utf-8-sig")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Compute ds004100 bicoherence features with surrogate statistics.")
    parser.add_argument("--n-surrogates", type=int, default=DEFAULT_N_SURROGATES)
    parser.add_argument("--max-segments", type=int, default=0)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    if not INPUT_INDEX.exists():
        raise FileNotFoundError(f"Missing Step 4 index: {INPUT_INDEX}")

    index_df = read_csv(INPUT_INDEX)
    if args.max_segments and args.max_segments > 0:
        index_df = index_df.head(args.max_segments).copy()
    triplets = build_frequency_triplets()
    print(f"Bicoherence frequency triplets: {len(triplets)}", flush=True)

    rng = np.random.default_rng(RANDOM_SEED)
    rows: list[dict[str, Any]] = []
    failure_rows: list[dict[str, Any]] = []
    started_at = time.monotonic()
    last_progress_at = 0.0
    for i, (_idx, row) in enumerate(index_df.iterrows(), start=1):
        now = time.monotonic()
        if i == 1 or i == len(index_df) or now - last_progress_at >= PROGRESS_INTERVAL_SEC:
            print(
                f"epoch {i}/{len(index_df)} | elapsed={now-started_at:.1f}s | "
                f"{row['segment_id']} {row['acquisition']} {row['channel_name']} {row['soz_label']}",
                flush=True,
            )
            last_progress_at = now
        try:
            rows.extend(compute_segment_bicoherence(row, triplets, args.n_surrogates, rng))
        except Exception as exc:
            failure_rows.append(
                {
                    "segment_id": row.get("segment_id", ""),
                    "participant_id": row.get("participant_id", ""),
                    "run_key": row.get("run_key", ""),
                    "channel_name": row.get("channel_name", ""),
                    "soz_label": row.get("soz_label", ""),
                    "error": repr(exc),
                }
            )

    results = add_fdr_columns(pd.DataFrame(rows))
    failures = pd.DataFrame(failure_rows)
    peaks = build_peak_rows(results) if not results.empty else pd.DataFrame()
    label_summary, triplet_summary, comparison = summarize_results(results) if not results.empty else (pd.DataFrame(), pd.DataFrame(), pd.DataFrame())
    column_dictionary = build_column_dictionary()

    write_csv(results, output_dir / "08_bicoherence_results_long.csv")
    write_csv(peaks, output_dir / "08_bicoherence_peak_by_segment.csv")
    write_csv(failures, output_dir / "08_bicoherence_failures.csv")
    write_csv(label_summary, output_dir / "08_bicoherence_summary_by_scope_label.csv")
    write_csv(triplet_summary, output_dir / "08_bicoherence_frequency_triplet_summary.csv")
    write_csv(comparison, output_dir / "08_bicoherence_soz_nonsoz_comparison.csv")
    write_csv(column_dictionary, output_dir / "08_column_dictionary_中文说明.csv")

    config = {
        "input_index": str(INPUT_INDEX),
        "output_dir": str(output_dir),
        "f1_freqs_hz": F1_FREQS_HZ,
        "f2_freqs_hz": F2_FREQS_HZ,
        "max_sum_freq_hz": MAX_SUM_FREQ_HZ,
        "frequency_triplet_count": len(triplets),
        "window_sec": WINDOW_SEC,
        "window_overlap": WINDOW_OVERLAP,
        "n_surrogates": args.n_surrogates,
        "random_seed": RANDOM_SEED,
        "fdr_method": "Benjamini-Hochberg",
        "fdr_scope": "all bicoherence result rows",
        "analysis_scopes": ["combined", "ecog_only", "seeg_only"],
        "max_segments": args.max_segments,
    }
    (output_dir / "08_bicoherence_config.json").write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    write_summary_md(output_dir, index_df, triplets, results, peaks, failures, label_summary, comparison, args.n_surrogates)

    elapsed = time.monotonic() - started_at
    print(f"Done. bicoherence rows={len(results)}, peaks={len(peaks)}, failures={len(failures)}, elapsed={elapsed:.1f}s", flush=True)
    print(f"Output dir: {output_dir}", flush=True)


if __name__ == "__main__":
    main()


