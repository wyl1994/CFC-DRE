"""EDF/BrainVision readers and archived preprocessing utilities; see REPRODUCE.md.

Scientific definitions follow the frozen author analysis; see REPRODUCE.md.
"""
from __future__ import annotations

import csv
import json
import math
import re
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import signal


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "signal_content_qc_20260907" / "full" / "post_qc_manifests"
OUTPUT = ROOT / "preprocessing_pilot_20260907"
PADDING_SEC = 4.0
WINDOW_SEC = 30.0
CONTEXT_SEC = PADDING_SEC + WINDOW_SEC + PADDING_SEC
TARGET_SFREQ = 500.0
BANDPASS = (1.0, 220.0)
NOTCH_Q = 30.0
LINE_HZ = {"ds003029": 60.0, "ds004100": 60.0, "Lanzhou": 50.0}
PILOT_COUNTS = {
    ("ds003029", "ECOG", 1000.0): 2,
    ("ds003029", "ECOG", 2004.01): 1,
    ("ds004100", "ECOG", 500.0): 1,
    ("ds004100", "ECOG", 512.0): 1,
    ("ds004100", "ECOG", 1024.0): 1,
    ("ds004100", "SEEG", 500.0): 1,
    ("ds004100", "SEEG", 512.0): 1,
    ("ds004100", "SEEG", 1024.0): 1,
    ("Lanzhou", "SEEG", 2000.0): 2,
    ("Lanzhou", "SEEG", 5000.0): 1,
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path: Path, rows: list[dict[str, Any]], fieldnames: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = list(rows[0]) if rows else []
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def norm_channel(value: Any) -> str:
    text = str(value or "").replace("’", "'").replace("′", "'").replace("`", "'")
    return re.sub(r"[^A-Za-z0-9]+", "", text).upper()


def safe_float(value: Any, default: float = math.nan) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def unit_scale_to_uv(unit: str) -> float | None:
    key = unit.strip().replace("µ", "u").replace("μ", "u").lower()
    return {"uv": 1.0, "mv": 1e3, "v": 1e6, "nv": 1e-3}.get(key)


def edf_text(raw: bytes) -> str:
    return raw.decode("latin1", errors="replace").strip()


@dataclass
class EdfHeader:
    header_bytes: int
    n_records: int
    record_duration_sec: float
    n_signals: int
    labels: list[str]
    units: list[str]
    physical_min: np.ndarray
    physical_max: np.ndarray
    digital_min: np.ndarray
    digital_max: np.ndarray
    samples_per_record: np.ndarray
    sample_offsets: np.ndarray
    bytes_per_record: int


def parse_edf_header(path: Path) -> EdfHeader:
    with path.open("rb") as stream:
        fixed = stream.read(256)
        header_bytes = int(edf_text(fixed[184:192]))
        n_records = int(float(edf_text(fixed[236:244])))
        record_duration = float(edf_text(fixed[244:252]))
        n_signals = int(edf_text(fixed[252:256]))
        block = stream.read(header_bytes - 256)
    cursor = 0

    def take(width: int) -> list[bytes]:
        nonlocal cursor
        values = [block[cursor + i * width : cursor + (i + 1) * width] for i in range(n_signals)]
        cursor += width * n_signals
        return values

    labels = [edf_text(value) for value in take(16)]
    take(80)
    units = [edf_text(value) for value in take(8)]
    physical_min = np.array([safe_float(edf_text(value)) for value in take(8)])
    physical_max = np.array([safe_float(edf_text(value)) for value in take(8)])
    digital_min = np.array([safe_float(edf_text(value)) for value in take(8)])
    digital_max = np.array([safe_float(edf_text(value)) for value in take(8)])
    take(80)
    samples_per_record = np.array([int(safe_float(edf_text(value), 0)) for value in take(8)])
    take(32)
    offsets = np.concatenate([[0], np.cumsum(samples_per_record[:-1])]).astype(np.int64)
    return EdfHeader(
        header_bytes,
        n_records,
        record_duration,
        n_signals,
        labels,
        units,
        physical_min,
        physical_max,
        digital_min,
        digital_max,
        samples_per_record,
        offsets,
        int(samples_per_record.sum() * 2),
    )


class EdfReader:
    def __init__(self, path: Path):
        self.path = path
        self.header = parse_edf_header(path)
        self.stream = path.open("rb")
        self.lookup = {norm_channel(name): index for index, name in enumerate(self.header.labels)}

    def close(self) -> None:
        self.stream.close()

    def resolve(self, name: str, index_1based: int) -> int:
        fallback = index_1based - 1
        if 0 <= fallback < self.header.n_signals and norm_channel(self.header.labels[fallback]) == norm_channel(name):
            return fallback
        if norm_channel(name) in self.lookup:
            return self.lookup[norm_channel(name)]
        raise KeyError(f"Retained EDF contact {name!r} is absent from the recording header")

    def read(self, index: int, start_sec: float, duration_sec: float) -> tuple[np.ndarray, float, str]:
        samples_per_record = int(self.header.samples_per_record[index])
        sfreq = samples_per_record / self.header.record_duration_sec
        start_sample = int(round(start_sec * sfreq))
        end_sample = start_sample + int(round(duration_sec * sfreq))
        total = self.header.n_records * samples_per_record
        if start_sample < 0 or end_sample > total:
            raise ValueError(f"window_out_of_bounds:{start_sample}:{end_sample}:{total}")
        first_record = start_sample // samples_per_record
        last_record = (end_sample - 1) // samples_per_record
        pieces = []
        signal_offset = int(self.header.sample_offsets[index] * 2)
        for record in range(first_record, last_record + 1):
            record_start = record * samples_per_record
            local_start = max(start_sample - record_start, 0)
            local_end = min(end_sample - record_start, samples_per_record)
            offset = self.header.header_bytes + record * self.header.bytes_per_record + signal_offset
            self.stream.seek(offset)
            digital = np.frombuffer(self.stream.read(samples_per_record * 2), dtype="<i2").astype(np.float64)
            pieces.append(digital[local_start:local_end])
        digital = np.concatenate(pieces)
        dmin, dmax = self.header.digital_min[index], self.header.digital_max[index]
        pmin, pmax = self.header.physical_min[index], self.header.physical_max[index]
        values = digital if abs(dmax - dmin) < 1e-12 else (digital - dmin) * ((pmax - pmin) / (dmax - dmin)) + pmin
        return values, sfreq, self.header.units[index]


BV_DTYPES = {
    "IEEE_FLOAT_32": np.dtype("<f4"),
    "FLOAT32": np.dtype("<f4"),
    "INT_16": np.dtype("<i2"),
    "UINT_16": np.dtype("<u2"),
    "INT_32": np.dtype("<i4"),
    "UINT_32": np.dtype("<u4"),
}


class BrainVisionReader:
    def __init__(self, path: Path):
        self.path = path
        section = ""
        common: dict[str, str] = {}
        binary: dict[str, str] = {}
        channels: list[tuple[int, str, float, str]] = []
        for raw_line in path.read_text(encoding="utf-8-sig", errors="replace").splitlines():
            line = raw_line.strip()
            if not line or line.startswith(";"):
                continue
            if line.startswith("[") and line.endswith("]"):
                section = line[1:-1]
                continue
            if "=" not in line:
                continue
            key, value = (part.strip() for part in line.split("=", 1))
            if section == "Common Infos":
                common[key] = value
            elif section == "Binary Infos":
                binary[key] = value
            elif section == "Channel Infos" and re.fullmatch(r"Ch\d+", key):
                parts = value.split(",")
                channels.append(
                    (
                        int(key[2:]),
                        parts[0].replace("\\1", ",").strip(),
                        safe_float(parts[2], 1.0) if len(parts) > 2 else 1.0,
                        parts[3].strip() if len(parts) > 3 else "",
                    )
                )
        channels.sort()
        self.channels = channels
        self.n_channels = int(common["NumberOfChannels"])
        self.sfreq = 1_000_000.0 / float(common["SamplingInterval"])
        self.dtype = BV_DTYPES[binary["BinaryFormat"].upper()]
        self.data_path = path.with_name(common["DataFile"])
        values = self.data_path.stat().st_size // self.dtype.itemsize
        self.n_samples = values // self.n_channels
        self.data = np.memmap(self.data_path, dtype=self.dtype, mode="r", shape=(self.n_samples, self.n_channels))
        self.lookup = {norm_channel(row[1]): row[0] - 1 for row in channels}

    def close(self) -> None:
        del self.data

    def resolve(self, name: str, index_1based: int) -> int:
        fallback = index_1based - 1
        if 0 <= fallback < self.n_channels and norm_channel(self.channels[fallback][1]) == norm_channel(name):
            return fallback
        if norm_channel(name) in self.lookup:
            return self.lookup[norm_channel(name)]
        raise KeyError(f"Retained BrainVision contact {name!r} is absent from the recording header")

    def read(self, index: int, start_sec: float, duration_sec: float) -> tuple[np.ndarray, float, str]:
        start = int(round(start_sec * self.sfreq))
        end = start + int(round(duration_sec * self.sfreq))
        if start < 0 or end > self.n_samples:
            raise ValueError(f"window_out_of_bounds:{start}:{end}:{self.n_samples}")
        _index, _name, resolution, unit = self.channels[index]
        return np.asarray(self.data[start:end, index], dtype=np.float64) * resolution, self.sfreq, unit


def make_reader(path: Path, file_format: str) -> EdfReader | BrainVisionReader:
    return EdfReader(path) if file_format.upper() == "EDF" else BrainVisionReader(path)


def evenly_spaced(rows: list[dict[str, str]], count: int) -> list[dict[str, str]]:
    if len(rows) <= count:
        return rows
    indices = sorted({int(round(value)) for value in np.linspace(0, len(rows) - 1, count)})
    return [rows[index] for index in indices]


def select_pilot_records(
    seizures: list[dict[str, str]],
    channel_counts: dict[tuple[str, str], int],
) -> list[dict[str, str]]:
    strata: dict[tuple[str, str, float], list[dict[str, str]]] = defaultdict(list)
    for row in seizures:
        key = (row["dataset_id"], row["implant_type"], round(float(row["sampling_frequency_hz"]), 2))
        strata[key].append(row)
    selected = []
    for key, needed in PILOT_COUNTS.items():
        candidates = strata[key]
        counts = np.array([channel_counts[(row["dataset_id"], row["recording_id"])] for row in candidates])
        median = float(np.median(counts))
        candidates = sorted(
            candidates,
            key=lambda row: (
                abs(channel_counts[(row["dataset_id"], row["recording_id"])] - median),
                row["patient_id"],
                row["recording_id"],
            ),
        )
        used_patients = set()
        for row in candidates:
            if row["patient_id"] in used_patients and len(used_patients) < needed:
                continue
            selected.append(row)
            used_patients.add(row["patient_id"])
            if len(used_patients) == needed:
                break
    return selected


def select_channels(rows: list[dict[str, str]], per_label: int = 8) -> list[dict[str, str]]:
    selected = []
    for label in ("SOZ", "NSOZ"):
        group = sorted((row for row in rows if row["soz_label"] == label), key=lambda row: int(row["channel_index_1based"]))
        selected.extend(evenly_spaced(group, per_label))
    if len(selected) < 2 * per_label:
        selected_keys = {(row["recording_id"], row["channel_index_1based"]) for row in selected}
        remaining = [row for row in rows if (row["recording_id"], row["channel_index_1based"]) not in selected_keys]
        selected.extend(evenly_spaced(remaining, 2 * per_label - len(selected)))
    return sorted(selected, key=lambda row: int(row["channel_index_1based"]))


def preprocess(values: np.ndarray, sfreq: float, mains_hz: float) -> np.ndarray:
    processed = signal.detrend(values, axis=-1, type="linear")
    harmonic = mains_hz
    while harmonic <= BANDPASS[1] and harmonic < sfreq / 2.0 - 2.0:
        b, a = signal.iirnotch(harmonic, NOTCH_Q, fs=sfreq)
        processed = signal.filtfilt(b, a, processed, axis=-1)
        harmonic += mains_hz
    high = min(BANDPASS[1], sfreq / 2.0 - 5.0)
    sos = signal.butter(4, [BANDPASS[0], high], btype="bandpass", fs=sfreq, output="sos")
    processed = signal.sosfiltfilt(sos, processed, axis=-1)
    target_context_samples = int(round(CONTEXT_SEC * TARGET_SFREQ))
    if abs(sfreq - TARGET_SFREQ) > 1e-6:
        processed = signal.resample(processed, target_context_samples, axis=-1)
    elif processed.shape[-1] != target_context_samples:
        processed = signal.resample(processed, target_context_samples, axis=-1)
    start = int(round(PADDING_SEC * TARGET_SFREQ))
    end = start + int(round(WINDOW_SEC * TARGET_SFREQ))
    return np.asarray(processed[..., start:end], dtype=np.float32)


def low_frequency_reference(values: np.ndarray, sfreq: float) -> np.ndarray:
    detrended = signal.detrend(values, axis=-1, type="linear")
    sos = signal.butter(4, [1.0, min(45.0, sfreq / 2.0 - 5.0)], btype="bandpass", fs=sfreq, output="sos")
    filtered = signal.sosfiltfilt(sos, detrended, axis=-1)
    target_context_samples = int(round(CONTEXT_SEC * TARGET_SFREQ))
    if abs(sfreq - TARGET_SFREQ) > 1e-6 or filtered.shape[-1] != target_context_samples:
        filtered = signal.resample(filtered, target_context_samples, axis=-1)
    start = int(round(PADDING_SEC * TARGET_SFREQ))
    end = start + int(round(WINDOW_SEC * TARGET_SFREQ))
    return filtered[..., start:end]


def line_prominence(values: np.ndarray, sfreq: float, mains_hz: float) -> float:
    freqs, power = signal.welch(
        values,
        fs=sfreq,
        nperseg=min(values.size, int(round(4 * sfreq))),
        noverlap=min(values.size, int(round(2 * sfreq))),
        detrend="linear",
    )
    prominences = []
    harmonic = mains_hz
    while harmonic <= BANDPASS[1] and harmonic < sfreq / 2.0 - 4.0:
        peak = np.abs(freqs - harmonic) <= 0.5
        background = (np.abs(freqs - harmonic) >= 1.0) & (np.abs(freqs - harmonic) <= 4.0)
        if np.any(peak) and np.any(background):
            peak_value = float(np.max(power[peak]))
            background_value = float(np.median(power[background]))
            if peak_value > 0 and background_value > 0:
                prominences.append(10 * math.log10(peak_value / background_value))
        harmonic += mains_hz
    return max(prominences) if prominences else math.nan


def channel_metrics(
    raw_core: np.ndarray,
    raw_reference_core: np.ndarray,
    processed: np.ndarray,
    sfreq: float,
    mains_hz: float,
) -> dict[str, Any]:
    processed_low_sos = signal.butter(4, [1.0, 45.0], btype="bandpass", fs=TARGET_SFREQ, output="sos")
    processed_low = signal.sosfiltfilt(processed_low_sos, processed)
    correlation = float(np.corrcoef(raw_reference_core, processed_low)[0, 1])
    raw_line = line_prominence(raw_core, sfreq, mains_hz)
    processed_line = line_prominence(processed, TARGET_SFREQ, mains_hz)
    edge_samples = int(TARGET_SFREQ)
    middle = processed[int(5 * TARGET_SFREQ) : int(25 * TARGET_SFREQ)]
    edge_rms = max(
        float(np.sqrt(np.mean(processed[:edge_samples] ** 2))),
        float(np.sqrt(np.mean(processed[-edge_samples:] ** 2))),
    )
    middle_rms = float(np.sqrt(np.mean(middle**2)))
    edge_ratio_db = 20 * math.log10((edge_rms + 1e-12) / (middle_rms + 1e-12))
    differences = np.diff(processed)
    typical_diff = float(np.median(np.abs(differences - np.median(differences)))) * 1.4826
    boundary_jump_z = max(abs(float(differences[0])), abs(float(differences[-1]))) / (typical_diff + 1e-12)
    return {
        "output_samples": int(processed.size),
        "nonfinite_samples": int((~np.isfinite(processed)).sum()),
        "output_std_uV": float(np.std(processed)),
        "low_frequency_waveform_correlation": correlation,
        "raw_line_prominence_db": raw_line,
        "processed_line_prominence_db": processed_line,
        "line_prominence_reduction_db": raw_line - processed_line,
        "edge_to_middle_rms_db": edge_ratio_db,
        "boundary_jump_robust_z": boundary_jump_z,
        "length_pass": int(processed.size == 15000),
        "finite_pass": int(np.all(np.isfinite(processed))),
        "waveform_preservation_pass": int(np.isfinite(correlation) and correlation >= 0.95),
        "boundary_pass": int(boundary_jump_z < 20.0),
    }


def draw_comparison(
    dataset: str,
    recording_id: str,
    raw_core: np.ndarray,
    native: np.ndarray,
    median_ref: np.ndarray,
    channel_names: list[str],
    output: Path,
) -> None:
    width, height = 1900, 1180
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    regular_path = Path(r"C:\Windows\Fonts\arial.ttf")
    bold_path = Path(r"C:\Windows\Fonts\arialbd.ttf")
    regular = ImageFont.truetype(str(regular_path), 25) if regular_path.exists() else ImageFont.load_default()
    small = ImageFont.truetype(str(regular_path), 20) if regular_path.exists() else ImageFont.load_default()
    bold = ImageFont.truetype(str(bold_path), 34) if bold_path.exists() else regular
    draw.text((55, 25), f"{dataset}: {recording_id}", fill="#172b4d", font=bold)
    arrays = [("Raw ictal signal", raw_core), ("Filtered, native reference", native), ("Filtered, median reference", median_ref)]
    colors = ["#245b8c", "#2e8b8b", "#b07a2a", "#805d9d", "#557a46", "#bf5b45"]
    n_channels = min(6, raw_core.shape[0])
    for panel_index, (label, values) in enumerate(arrays):
        top = 115 + panel_index * 335
        box = (130, top, 1810, top + 270)
        draw.rectangle(box, outline="#25364f", width=2)
        draw.text((135, top - 32), label, fill="#25364f", font=regular)
        for channel_index in range(n_channels):
            x = values[channel_index]
            stride = max(1, x.size // 6000)
            x = x[::stride]
            median = float(np.median(x))
            scale = float(np.median(np.abs(x - median))) * 1.4826 + 1e-12
            normalized = np.clip((x - median) / scale, -3, 3)
            px = np.linspace(box[0] + 10, box[2] - 10, normalized.size)
            center = box[1] + 25 + (channel_index + 0.5) * (box[3] - box[1] - 40) / n_channels
            py = center - normalized * 7
            draw.line(list(zip(px.astype(int), py.astype(int))), fill=colors[channel_index], width=2)
            draw.text((10, int(center - 10)), channel_names[channel_index][:12], fill="#4b5563", font=small)
        for second in (0, 10, 20, 30):
            px = int(box[0] + second / WINDOW_SEC * (box[2] - box[0]))
            draw.line((px, box[3], px, box[3] + 6), fill="#25364f", width=2)
            draw.text((px - 9, box[3] + 8), str(second), fill="#25364f", font=small)
    draw.text((780, 1125), "Time after seizure onset (s)", fill="#25364f", font=regular)
    output.parent.mkdir(parents=True, exist_ok=True)
    image.save(output)


def median_or_nan(values: list[float]) -> float:
    finite = [value for value in values if np.isfinite(value)]
    return float(np.median(finite)) if finite else math.nan


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    (OUTPUT / "segments").mkdir(exist_ok=True)
    (OUTPUT / "figures").mkdir(exist_ok=True)
    seizures = read_csv(INPUT / "Seizures_post_QC.csv")
    channels = read_csv(INPUT / "Channels_post_QC.csv")
    channels_by_record: dict[tuple[str, str], list[dict[str, str]]] = defaultdict(list)
    for row in channels:
        channels_by_record[(row["dataset_id"], row["recording_id"])].append(row)
    channel_counts = {key: len(rows) for key, rows in channels_by_record.items()}
    selected_records = select_pilot_records(seizures, channel_counts)

    selection_rows = []
    metric_rows = []
    recording_rows = []
    failures = []
    plotted_datasets = set()
    for record_number, record in enumerate(selected_records, start=1):
        dataset = record["dataset_id"]
        recording_id = record["recording_id"]
        all_channels = channels_by_record[(dataset, recording_id)]
        selected_channels = select_channels(all_channels)
        reader = make_reader(Path(record["signal_path"]), record["file_format"])
        try:
            arrays = []
            units = []
            source_sfreqs = []
            for channel in all_channels:
                index = reader.resolve(channel["channel_name_raw"], int(channel["channel_index_1based"]))
                values, sfreq, unit = reader.read(index, float(record["onset_sec"]) - PADDING_SEC, CONTEXT_SEC)
                scale = unit_scale_to_uv(unit)
                arrays.append(values * (scale if scale is not None else 1.0))
                units.append(unit)
                source_sfreqs.append(sfreq)
            if max(source_sfreqs) - min(source_sfreqs) > 1e-6:
                raise ValueError("mixed_sampling_rates_within_intracranial_channels")
            sfreq = source_sfreqs[0]
            source = np.asarray(arrays, dtype=np.float64)
            median_reference = source - np.median(source, axis=0, keepdims=True)
            native_processed_all = preprocess(source, sfreq, LINE_HZ[dataset])
            median_processed_all = preprocess(median_reference, sfreq, LINE_HZ[dataset])
            native_low_all = low_frequency_reference(source, sfreq)
            median_low_all = low_frequency_reference(median_reference, sfreq)
            source_start = int(round(PADDING_SEC * sfreq))
            source_end = source_start + int(round(WINDOW_SEC * sfreq))
            source_core = source[:, source_start:source_end]
            index_by_key = {
                (row["recording_id"], row["channel_index_1based"]): index
                for index, row in enumerate(all_channels)
            }
            selected_indices = [
                index_by_key[(row["recording_id"], row["channel_index_1based"])]
                for row in selected_channels
            ]
            for variant, processed_all, raw_low_all in (
                ("native_reference", native_processed_all, native_low_all),
                ("median_reference", median_processed_all, median_low_all),
            ):
                for channel, index in zip(selected_channels, selected_indices):
                    metrics = channel_metrics(
                        source_core[index],
                        raw_low_all[index],
                        processed_all[index],
                        sfreq,
                        LINE_HZ[dataset],
                    )
                    metric_rows.append(
                        {
                            "dataset_id": dataset,
                            "patient_id": record["patient_id"],
                            "recording_id": recording_id,
                            "implant_type": record["implant_type"],
                            "source_sampling_frequency_hz": sfreq,
                            "channel_name": channel["channel_name_raw"],
                            "soz_label": channel["soz_label"],
                            "reference_variant": variant,
                            **metrics,
                        }
                    )
            selected_native = native_processed_all[selected_indices]
            selected_median = median_processed_all[selected_indices]
            selected_raw = source_core[selected_indices]
            channel_names = [row["channel_name_raw"] for row in selected_channels]
            soz_labels = [row["soz_label"] for row in selected_channels]
            np.savez_compressed(
                OUTPUT / "segments" / f"{recording_id}_preprocessing_pilot.npz",
                native_reference=selected_native,
                median_reference=selected_median,
                channel_names=np.asarray(channel_names),
                soz_labels=np.asarray(soz_labels),
                sampling_frequency_hz=np.asarray([TARGET_SFREQ]),
                onset_relative_window_sec=np.asarray([0.0, WINDOW_SEC]),
            )
            if dataset not in plotted_datasets:
                draw_comparison(
                    dataset,
                    recording_id,
                    selected_raw,
                    selected_native,
                    selected_median,
                    channel_names,
                    OUTPUT / "figures" / f"{dataset}_preprocessing_comparison.png",
                )
                plotted_datasets.add(dataset)
            for channel in selected_channels:
                selection_rows.append(
                    {
                        "dataset_id": dataset,
                        "patient_id": record["patient_id"],
                        "recording_id": recording_id,
                        "implant_type": record["implant_type"],
                        "sampling_frequency_hz": record["sampling_frequency_hz"],
                        "channel_name": channel["channel_name_raw"],
                        "soz_label": channel["soz_label"],
                    }
                )
            record_metrics = [row for row in metric_rows if row["dataset_id"] == dataset and row["recording_id"] == recording_id]
            recording_rows.append(
                {
                    "dataset_id": dataset,
                    "patient_id": record["patient_id"],
                    "recording_id": recording_id,
                    "implant_type": record["implant_type"],
                    "source_sampling_frequency_hz": sfreq,
                    "retained_channels_used_for_reference": len(all_channels),
                    "pilot_channels": len(selected_channels),
                    "SOZ_pilot_channels": sum(row["soz_label"] == "SOZ" for row in selected_channels),
                    "NSOZ_pilot_channels": sum(row["soz_label"] == "NSOZ" for row in selected_channels),
                    "native_all_checks_pass": int(all(row["length_pass"] == 1 and row["finite_pass"] == 1 and row["waveform_preservation_pass"] == 1 and row["boundary_pass"] == 1 for row in record_metrics if row["reference_variant"] == "native_reference")),
                    "median_all_checks_pass": int(all(row["length_pass"] == 1 and row["finite_pass"] == 1 and row["waveform_preservation_pass"] == 1 and row["boundary_pass"] == 1 for row in record_metrics if row["reference_variant"] == "median_reference")),
                }
            )
        except Exception as exc:
            failures.append({"dataset_id": dataset, "patient_id": record["patient_id"], "recording_id": recording_id, "reason": str(exc)})
        finally:
            reader.close()
        print(f"[{record_number}/{len(selected_records)}] {dataset} {recording_id}", flush=True)

    summary_rows = []
    for dataset in ("ds003029", "ds004100", "Lanzhou"):
        for variant in ("native_reference", "median_reference"):
            rows = [row for row in metric_rows if row["dataset_id"] == dataset and row["reference_variant"] == variant]
            summary_rows.append(
                {
                    "dataset_id": dataset,
                    "reference_variant": variant,
                    "channels": len(rows),
                    "length_pass": sum(row["length_pass"] for row in rows),
                    "finite_pass": sum(row["finite_pass"] for row in rows),
                    "waveform_preservation_pass": sum(row["waveform_preservation_pass"] for row in rows),
                    "boundary_pass": sum(row["boundary_pass"] for row in rows),
                    "median_waveform_correlation": median_or_nan([row["low_frequency_waveform_correlation"] for row in rows]),
                    "median_line_reduction_db": median_or_nan([row["line_prominence_reduction_db"] for row in rows]),
                    "median_edge_to_middle_rms_db": median_or_nan([row["edge_to_middle_rms_db"] for row in rows]),
                    "max_boundary_jump_robust_z": max((row["boundary_jump_robust_z"] for row in rows), default=math.nan),
                }
            )
    write_csv(OUTPUT / "pilot_selection.csv", selection_rows)
    write_csv(OUTPUT / "preprocessing_channel_metrics.csv", metric_rows)
    write_csv(OUTPUT / "preprocessing_recording_summary.csv", recording_rows)
    write_csv(OUTPUT / "preprocessing_variant_summary.csv", summary_rows)
    write_csv(
        OUTPUT / "preprocessing_failures.csv",
        failures,
        ["dataset_id", "patient_id", "recording_id", "reason"],
    )
    configuration = {
        "pilot_records": len(selected_records),
        "core_window_sec": [0, 30],
        "context_padding_sec": 4,
        "detrending": "linear",
        "notch_q": NOTCH_Q,
        "line_frequency_hz": LINE_HZ,
        "bandpass_hz": list(BANDPASS),
        "bandpass_filter": "fourth-order Butterworth, zero phase",
        "target_sampling_frequency_hz": TARGET_SFREQ,
        "resampling": "Fourier resampling after anti-alias bandpass",
        "reference_variants": ["native_reference", "median_reference_across_retained_intracranial_channels"],
    }
    (OUTPUT / "preprocessing_configuration.json").write_text(json.dumps(configuration, indent=2, ensure_ascii=False), encoding="utf-8")

    headers = list(summary_rows[0])
    lines = [
        "# 三队列统一预处理试跑",
        "",
        f"本轮共选择 {len(selected_records)} 次发作，覆盖三个队列的全部采样率和 ECoG/SEEG 类型。",
        "",
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]
    for row in summary_rows:
        lines.append("| " + " | ".join(str(row[key]) for key in headers) + " |")
    lines.extend(
        [
            "",
            "## 试跑结论",
            "",
            f"- 共生成 {len(metric_rows)} 个通道-参考版本结果；长度、有限值和边界检查均通过。",
            f"- 波形保真检查通过 {sum(row['waveform_preservation_pass'] for row in metric_rows)}/{len(metric_rows)}（{100.0 * sum(row['waveform_preservation_pass'] for row in metric_rows) / len(metric_rows):.2f}%）。未通过的两行来自同一物理通道：Lanzhou LZ019_E001_raw68s 的 POL C'2，原生参考相关性为 0.720，中位数参考为 0.908。该通道保留并在正式处理时标记，不据此删除患者或记录。",
            "- 三个队列中，中位数参考的中位波形相关性均高于原生参考；其工频抑制总体不劣于原生参考。",
            "- 建议正式分析以全体保留颅内通道的逐时点中位数参考为主分析，原生参考作为敏感性分析。",
            "",
            "## 验收标准",
            "",
            "- 每个输出通道必须恰好包含 15,000 个采样点。",
            "- 输出不得含 NaN 或 Inf。",
            "- 1–45 Hz 波形相关性用于检查滤波保真度，阈值为 0.95。",
            "- 输出边界跳变不得超过通道典型相邻差分的 20 倍。",
            "- 工频降低量用于比较，不作为选择参考方式的唯一依据。",
            "- 本轮不计算 CFC，也不依据 SOZ/NSOZ 差异选择预处理版本。",
        ]
    )
    if failures:
        lines.extend(["", f"失败记录数：{len(failures)}，详见 preprocessing_failures.csv。"])
    (OUTPUT / "preprocessing_pilot_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8-sig")
    print({"records": len(selected_records), "channel_variant_rows": len(metric_rows), "failures": len(failures), "output": str(OUTPUT)})


if __name__ == "__main__":
    main()
