"""PAC estimator helpers: Tort MI, mean vector length, and GLM explained variance.

Used by metrics.py with buffered band-limited signals. The legacy standalone
batch parser is retained internally; use the public cfc_repro commands instead.
"""
from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any, Callable

import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
INPUT_INDEX = PROJECT_ROOT / "outputs" / "cfc_ds004100_fs_ge500_full" / "preprocessed_segments" / "04_cfc_segments_index.csv"
OUTPUT_DIR = PROJECT_ROOT / "outputs" / "cfc_ds004100_fs_ge500_full" / "pac_standard"

RANDOM_SEED = 20260714
DEFAULT_N_SURROGATES = 200
N_PHASE_BINS = 18
MIN_SURROGATE_SHIFT_SEC = 1.0
PROGRESS_INTERVAL_SEC = 10.0

PHASE_BANDS = [
    ("delta", 2.0, 4.0),
    ("theta", 4.0, 8.0),
    ("alpha", 8.0, 13.0),
    ("beta", 13.0, 30.0),
]

AMPLITUDE_BANDS = [
    ("low_gamma", 30.0, 55.0),
    ("high_gamma", 65.0, 100.0),
    ("ripple", 100.0, 150.0),
    ("fast_ripple_low", 150.0, 200.0),
]

METHOD_LABELS = {
    "tort_mi": "Tort MI",
    "mvl": "MVL",
    "glm_pac": "GLM-PAC R2",
}


def read_csv(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    df.columns = [str(col).strip() for col in df.columns]
    return df


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8-sig")


def safe_float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return math.nan


def fft_bandpass(x: np.ndarray, sfreq: float, low_hz: float, high_hz: float) -> np.ndarray:
    y = np.asarray(x, dtype=np.float64)
    y = y - np.mean(y)
    freqs = np.fft.rfftfreq(y.size, d=1.0 / sfreq)
    spectrum = np.fft.rfft(y)
    spectrum *= (freqs >= low_hz) & (freqs <= high_hz)
    return np.fft.irfft(spectrum, n=y.size)


def analytic_signal(x: np.ndarray) -> np.ndarray:
    y = np.asarray(x, dtype=np.float64)
    n = y.size
    spectrum = np.fft.fft(y)
    h = np.zeros(n, dtype=np.float64)
    if n % 2 == 0:
        h[0] = 1.0
        h[n // 2] = 1.0
        h[1 : n // 2] = 2.0
    else:
        h[0] = 1.0
        h[1 : (n + 1) // 2] = 2.0
    return np.fft.ifft(spectrum * h)


def valid_band(sfreq: float, low_hz: float, high_hz: float) -> bool:
    nyquist = sfreq / 2.0
    return low_hz > 0 and high_hz > low_hz and high_hz < nyquist - 1.0


def phase_from_band(x: np.ndarray, sfreq: float, low_hz: float, high_hz: float) -> np.ndarray:
    return np.angle(analytic_signal(fft_bandpass(x, sfreq, low_hz, high_hz)))


def amplitude_from_band(x: np.ndarray, sfreq: float, low_hz: float, high_hz: float) -> np.ndarray:
    return np.abs(analytic_signal(fft_bandpass(x, sfreq, low_hz, high_hz)))


class PhaseMetricHelper:
    def __init__(self, phase: np.ndarray, n_bins: int = N_PHASE_BINS) -> None:
        self.phase = phase
        self.n_bins = n_bins
        edges = np.linspace(-np.pi, np.pi, n_bins + 1)
        bin_index = np.digitize(phase, edges, right=False) - 1
        bin_index[bin_index == n_bins] = n_bins - 1
        self.bin_index = bin_index
        self.bin_counts = np.bincount(bin_index, minlength=n_bins).astype(np.float64)
        self.exp_phase = np.exp(1j * phase)
        design = np.column_stack([np.ones_like(phase), np.sin(phase), np.cos(phase)])
        self.q, _r = np.linalg.qr(design, mode="reduced")

    def tort_mi(self, amplitude: np.ndarray) -> float:
        amp = amplitude.astype(np.float64, copy=False)
        sums = np.bincount(self.bin_index, weights=amp, minlength=self.n_bins).astype(np.float64)
        global_amp = float(np.mean(amp))
        means = np.divide(
            sums,
            self.bin_counts,
            out=np.full(self.n_bins, global_amp, dtype=np.float64),
            where=self.bin_counts > 0,
        )
        amp_sum = float(np.sum(means))
        if amp_sum <= 0:
            return 0.0
        probability = np.clip(means / amp_sum, 1e-12, 1.0)
        entropy = -float(np.sum(probability * np.log(probability)))
        return float((np.log(self.n_bins) - entropy) / np.log(self.n_bins))

    def mvl(self, amplitude: np.ndarray) -> float:
        amp = amplitude.astype(np.float64, copy=False)
        amp = amp / (np.mean(amp) + 1e-12)
        return float(np.abs(np.mean(amp * self.exp_phase)))

    def glm_r2(self, amplitude: np.ndarray) -> float:
        y = amplitude.astype(np.float64, copy=False)
        y_centered = y - np.mean(y)
        ss_total = float(np.sum(y_centered * y_centered))
        if ss_total <= 0:
            return 0.0
        coeff = self.q.T @ y
        projection_ss = float(np.sum(coeff * coeff))
        residual_ss = float(np.sum(y * y) - projection_ss)
        return float(max(0.0, 1.0 - residual_ss / ss_total))


def surrogate_shifts(n_samples: int, n_surrogates: int, sfreq: float, rng: np.random.Generator) -> np.ndarray:
    min_shift = max(1, int(round(MIN_SURROGATE_SHIFT_SEC * sfreq)))
    max_shift = max(min_shift + 1, n_samples - min_shift)
    if max_shift <= min_shift:
        return np.arange(1, min(n_samples, n_surrogates + 1), dtype=int)
    return rng.integers(low=min_shift, high=max_shift, size=n_surrogates, endpoint=False)


def surrogate_stats(
    amplitude: np.ndarray,
    observed: float,
    metric: Callable[[np.ndarray], float],
    shifts: np.ndarray,
) -> tuple[float, float, float, float]:
    values = np.array([metric(np.roll(amplitude, int(shift))) for shift in shifts], dtype=np.float64)
    values = values[np.isfinite(values)]
    if values.size == 0:
        return math.nan, math.nan, math.nan, math.nan
    mean = float(np.mean(values))
    std = float(np.std(values, ddof=1)) if values.size > 1 else 0.0
    z_value = float((observed - mean) / std) if std > 0 else 0.0
    p_value = float((np.sum(values >= observed) + 1) / (values.size + 1))
    return mean, std, z_value, p_value


def benjamini_hochberg(p_values: pd.Series) -> pd.Series:
    p = pd.to_numeric(p_values, errors="coerce").to_numpy(dtype=float)
    q = np.full(p.shape, np.nan, dtype=float)
    valid = np.isfinite(p)
    if not np.any(valid):
        return pd.Series(q, index=p_values.index)

    p_valid = np.clip(p[valid], 0.0, 1.0)
    order = np.argsort(p_valid)
    ranked = p_valid[order]
    n_tests = ranked.size
    raw_q = ranked * n_tests / np.arange(1, n_tests + 1)
    monotone_q = np.minimum.accumulate(raw_q[::-1])[::-1]
    restored = np.empty_like(monotone_q)
    restored[order] = np.clip(monotone_q, 0.0, 1.0)
    q[valid] = restored
    return pd.Series(q, index=p_values.index)


def add_fdr_columns(results: pd.DataFrame) -> pd.DataFrame:
    corrected = results.copy()
    corrected["p_value"] = pd.to_numeric(corrected["p_value"], errors="coerce")
    corrected["fdr_q_value"] = benjamini_hochberg(corrected["p_value"])
    corrected["p_lt_0_05"] = corrected["p_value"] < 0.05
    corrected["fdr_q_lt_0_05"] = corrected["fdr_q_value"] < 0.05
    corrected["fdr_scope"] = "all_pac_rows"
    return corrected


def compute_segment_pac(row: pd.Series, rng: np.random.Generator, n_surrogates: int) -> list[dict[str, Any]]:
    npz = np.load(row["segment_file"])
    x = np.asarray(npz["signal"], dtype=np.float64)
    sfreq = float(npz["sampling_frequency_hz"])
    shifts = surrogate_shifts(x.size, n_surrogates, sfreq, rng)

    phase_helpers: dict[str, PhaseMetricHelper] = {}
    phase_meta: list[tuple[str, float, float]] = []
    amp_cache: dict[str, np.ndarray] = {}
    amp_meta: list[tuple[str, float, float]] = []

    for label, low, high in PHASE_BANDS:
        if valid_band(sfreq, low, high):
            phase_helpers[label] = PhaseMetricHelper(phase_from_band(x, sfreq, low, high))
            phase_meta.append((label, low, high))

    for label, low, high in AMPLITUDE_BANDS:
        if valid_band(sfreq, low, high):
            amp_cache[label] = amplitude_from_band(x, sfreq, low, high)
            amp_meta.append((label, low, high))

    rows: list[dict[str, Any]] = []
    for phase_label, phase_low, phase_high in phase_meta:
        helper = phase_helpers[phase_label]
        metrics: dict[str, Callable[[np.ndarray], float]] = {
            "tort_mi": helper.tort_mi,
            "mvl": helper.mvl,
            "glm_pac": helper.glm_r2,
        }
        for amp_label, amp_low, amp_high in amp_meta:
            if amp_low <= phase_high:
                continue
            amplitude = amp_cache[amp_label]
            for method, metric in metrics.items():
                observed = float(metric(amplitude))
                s_mean, s_std, z_value, p_value = surrogate_stats(amplitude, observed, metric, shifts)
                rows.append(
                    {
                        "segment_id": row["segment_id"],
                        "cfc_sample_id": row["cfc_sample_id"],
                        "participant_id": row["participant_id"],
                        "run_key": row["run_key"],
                        "acquisition": row["acquisition"],
                        "channel_name": row["channel_name"],
                        "channel_name_key": row["channel_name_key"],
                        "channel_type": row["channel_type"],
                        "soz_label": row["soz_label"],
                        "is_soz": row["is_soz"],
                        "method": method,
                        "method_label": METHOD_LABELS[method],
                        "phase_band": phase_label,
                        "phase_low_hz": phase_low,
                        "phase_high_hz": phase_high,
                        "amplitude_band": amp_label,
                        "amplitude_low_hz": amp_low,
                        "amplitude_high_hz": amp_high,
                        "pac_value": observed,
                        "surrogate_mean": s_mean,
                        "surrogate_std": s_std,
                        "pac_z": z_value,
                        "p_value": p_value,
                        "n_surrogates": n_surrogates,
                        "final_sampling_frequency_hz": sfreq,
                        "segment_file": row["segment_file"],
                    }
                )
    return rows


def cohen_d(a: pd.Series, b: pd.Series) -> float:
    x = pd.to_numeric(a, errors="coerce").dropna().to_numpy(dtype=float)
    y = pd.to_numeric(b, errors="coerce").dropna().to_numpy(dtype=float)
    if x.size < 2 or y.size < 2:
        return math.nan
    pooled = math.sqrt(((x.size - 1) * np.var(x, ddof=1) + (y.size - 1) * np.var(y, ddof=1)) / (x.size + y.size - 2))
    if pooled <= 0:
        return 0.0
    return float((np.mean(x) - np.mean(y)) / pooled)


def build_peak_rows(results: pd.DataFrame) -> pd.DataFrame:
    peak_rows: list[dict[str, Any]] = []
    for (_segment_id, method), group in results.groupby(["segment_id", "method"], dropna=False):
        finite = group[np.isfinite(pd.to_numeric(group["pac_z"], errors="coerce"))]
        if finite.empty:
            continue
        peak = finite.sort_values("pac_z", ascending=False).iloc[0]
        peak_rows.append(
            {
                "segment_id": peak["segment_id"],
                "cfc_sample_id": peak["cfc_sample_id"],
                "participant_id": peak["participant_id"],
                "run_key": peak["run_key"],
                "acquisition": peak["acquisition"],
                "channel_name": peak["channel_name"],
                "channel_type": peak["channel_type"],
                "soz_label": peak["soz_label"],
                "method": method,
                "method_label": METHOD_LABELS[method],
                "peak_phase_band": peak["phase_band"],
                "peak_phase_low_hz": peak["phase_low_hz"],
                "peak_phase_high_hz": peak["phase_high_hz"],
                "peak_amplitude_band": peak["amplitude_band"],
                "peak_amplitude_low_hz": peak["amplitude_low_hz"],
                "peak_amplitude_high_hz": peak["amplitude_high_hz"],
                "peak_pac_value": peak["pac_value"],
                "peak_z": peak["pac_z"],
                "peak_p_value": peak["p_value"],
                "peak_fdr_q_value": peak["fdr_q_value"],
                "peak_fdr_q_lt_0_05": peak["fdr_q_lt_0_05"],
                "n_surrogates": peak["n_surrogates"],
            }
        )
    return pd.DataFrame(peak_rows)


def scope_frames(results: pd.DataFrame) -> list[tuple[str, pd.DataFrame]]:
    frames = [("combined", results)]
    for acquisition in ["ecog", "seeg"]:
        frames.append((f"{acquisition}_only", results[results["acquisition"] == acquisition]))
    return frames


def summarize_results(results: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    method_rows: list[dict[str, Any]] = []
    pair_rows: list[dict[str, Any]] = []
    comparison_rows: list[dict[str, Any]] = []

    for scope, scope_df in scope_frames(results):
        if scope_df.empty:
            continue
        for keys, group in scope_df.groupby(["method", "method_label", "soz_label"], dropna=False):
            method, method_label, soz_label = keys
            method_rows.append(
                {
                    "analysis_scope": scope,
                    "method": method,
                    "method_label": method_label,
                    "soz_label": soz_label,
                    "rows": len(group),
                    "segment_count": group["segment_id"].nunique(),
                    "mean_pac_value": float(pd.to_numeric(group["pac_value"]).mean()),
                    "mean_pac_z": float(pd.to_numeric(group["pac_z"]).mean()),
                    "median_pac_z": float(pd.to_numeric(group["pac_z"]).median()),
                    "p_lt_0_05_percent": round(100 * pd.to_numeric(group["p_lt_0_05"]).mean(), 3),
                    "fdr_q_lt_0_05_percent": round(100 * pd.to_numeric(group["fdr_q_lt_0_05"]).mean(), 3),
                }
            )

        for keys, group in scope_df.groupby(["method", "method_label", "phase_band", "amplitude_band", "soz_label"], dropna=False):
            method, method_label, phase_band, amp_band, soz_label = keys
            pair_rows.append(
                {
                    "analysis_scope": scope,
                    "method": method,
                    "method_label": method_label,
                    "phase_band": phase_band,
                    "amplitude_band": amp_band,
                    "soz_label": soz_label,
                    "rows": len(group),
                    "segment_count": group["segment_id"].nunique(),
                    "mean_pac_z": float(pd.to_numeric(group["pac_z"]).mean()),
                    "median_pac_z": float(pd.to_numeric(group["pac_z"]).median()),
                    "mean_pac_value": float(pd.to_numeric(group["pac_value"]).mean()),
                    "p_lt_0_05_percent": round(100 * pd.to_numeric(group["p_lt_0_05"]).mean(), 3),
                    "fdr_q_lt_0_05_percent": round(100 * pd.to_numeric(group["fdr_q_lt_0_05"]).mean(), 3),
                }
            )

        for keys, group in scope_df.groupby(["method", "method_label", "phase_band", "amplitude_band"], dropna=False):
            method, method_label, phase_band, amp_band = keys
            soz = group[group["soz_label"] == "SOZ"]
            non = group[group["soz_label"] == "non-SOZ"]
            comparison_rows.append(
                {
                    "analysis_scope": scope,
                    "method": method,
                    "method_label": method_label,
                    "phase_band": phase_band,
                    "amplitude_band": amp_band,
                    "soz_rows": len(soz),
                    "non_soz_rows": len(non),
                    "soz_mean_z": float(pd.to_numeric(soz["pac_z"]).mean()) if len(soz) else math.nan,
                    "non_soz_mean_z": float(pd.to_numeric(non["pac_z"]).mean()) if len(non) else math.nan,
                    "soz_minus_non_soz_mean_z": (
                        float(pd.to_numeric(soz["pac_z"]).mean() - pd.to_numeric(non["pac_z"]).mean())
                        if len(soz) and len(non)
                        else math.nan
                    ),
                    "cohen_d_soz_vs_non_soz_z": cohen_d(soz["pac_z"], non["pac_z"]) if len(soz) and len(non) else math.nan,
                    "soz_mean_value": float(pd.to_numeric(soz["pac_value"]).mean()) if len(soz) else math.nan,
                    "non_soz_mean_value": float(pd.to_numeric(non["pac_value"]).mean()) if len(non) else math.nan,
                    "soz_fdr_q_lt_0_05_percent": (
                        round(100 * pd.to_numeric(soz["fdr_q_lt_0_05"]).mean(), 3) if len(soz) else math.nan
                    ),
                    "non_soz_fdr_q_lt_0_05_percent": (
                        round(100 * pd.to_numeric(non["fdr_q_lt_0_05"]).mean(), 3) if len(non) else math.nan
                    ),
                }
            )

    comparison = pd.DataFrame(comparison_rows)
    if not comparison.empty:
        comparison = comparison.sort_values(["analysis_scope", "soz_minus_non_soz_mean_z"], ascending=[True, False])
    return pd.DataFrame(method_rows), pd.DataFrame(pair_rows), comparison


def build_column_dictionary() -> pd.DataFrame:
    rows = [
        ("pac_value", "真实PAC指标值"),
        ("surrogate_mean", "随机surrogate PAC均值"),
        ("surrogate_std", "随机surrogate PAC标准差"),
        ("pac_z", "真实PAC相对surrogate分布的z值"),
        ("p_value", "经验p值"),
        ("fdr_q_value", "BH-FDR校正后的q值"),
        ("analysis_scope", "分析范围：combined/ecog_only/seeg_only"),
        ("phase_band", "低频相位频段"),
        ("amplitude_band", "高频振幅频段"),
        ("soz_minus_non_soz_mean_z", "SOZ平均z值减去non-SOZ平均z值"),
        ("cohen_d_soz_vs_non_soz_z", "SOZ和non-SOZ z值差异的Cohen d效应量"),
    ]
    return pd.DataFrame(rows, columns=["column", "中文含义"])


def write_summary_md(
    index_df: pd.DataFrame,
    results: pd.DataFrame,
    peaks: pd.DataFrame,
    method_summary: pd.DataFrame,
    comparison: pd.DataFrame,
    n_surrogates: int,
) -> None:
    top_combined = comparison[comparison["analysis_scope"] == "combined"].head(10) if not comparison.empty else pd.DataFrame()
    lines = [
        "# Step 5 ds004100 PAC标准版计算报告",
        "",
        "## 1. 这一步做什么",
        "",
        "这一步基于 Step 4 的30秒预处理片段计算 PAC，也就是低频相位是否调制高频振幅。这里同时复现三种 PAC 计算方法：Tort MI、MVL 和 GLM-PAC R2。",
        "",
        "## 2. 统计口径",
        "",
        f"- 输入文件：`{INPUT_INDEX}`",
        f"- surrogate次数：`{n_surrogates}`",
        "- p值计算：把真实PAC和随机平移振幅包络得到的surrogate分布比较。",
        "- z值计算：真实PAC相对surrogate均值和标准差的偏离程度。",
        "- 多重比较校正：Benjamini-Hochberg FDR。",
        "- 输出三种分析范围：`combined`、`ecog_only`、`seeg_only`。",
        "",
        "## 3. 频段设置",
        "",
        "| 类型 | 频段 | 范围Hz |",
        "|---|---|---:|",
    ]
    for label, low, high in PHASE_BANDS:
        lines.append(f"| phase | {label} | {low:g}-{high:g} |")
    for label, low, high in AMPLITUDE_BANDS:
        lines.append(f"| amplitude | {label} | {low:g}-{high:g} |")

    lines.extend(
        [
            "",
            "## 4. 主要结果规模",
            "",
            f"- 输入片段数：{len(index_df)}",
            f"- PAC长表行数：{len(results)}",
            f"- 峰值表行数：{len(peaks)}",
            f"- 患者数：{index_df['participant_id'].nunique() if not index_df.empty else 0}",
            f"- run数：{index_df['run_key'].nunique() if not index_df.empty else 0}",
            "",
            "## 5. 方法和标签汇总",
            "",
            "| 范围 | 方法 | 标签 | 片段数 | 平均z值 | 中位z值 | p<0.05比例% | FDR q<0.05比例% |",
            "|---|---|---|---:|---:|---:|---:|---:|",
        ]
    )
    for _idx, row in method_summary.iterrows():
        lines.append(
            f"| {row.get('analysis_scope', '')} | {row.get('method_label', '')} | {row.get('soz_label', '')} | "
            f"{row.get('segment_count', '')} | {float(row.get('mean_pac_z', 0)):.4f} | "
            f"{float(row.get('median_pac_z', 0)):.4f} | {row.get('p_lt_0_05_percent', '')} | "
            f"{row.get('fdr_q_lt_0_05_percent', '')} |"
        )

    lines.extend(
        [
            "",
            "## 6. combined范围内SOZ高于non-SOZ最多的频段组合",
            "",
            "| 方法 | phase | amplitude | SOZ平均z | non-SOZ平均z | 差值 | Cohen d | SOZ FDR显著% | non-SOZ FDR显著% |",
            "|---|---|---|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for _idx, row in top_combined.iterrows():
        lines.append(
            f"| {row.get('method_label', '')} | {row.get('phase_band', '')} | {row.get('amplitude_band', '')} | "
            f"{float(row.get('soz_mean_z', 0)):.4f} | {float(row.get('non_soz_mean_z', 0)):.4f} | "
            f"{float(row.get('soz_minus_non_soz_mean_z', 0)):.4f} | "
            f"{float(row.get('cohen_d_soz_vs_non_soz_z', 0)):.4f} | "
            f"{row.get('soz_fdr_q_lt_0_05_percent', '')} | {row.get('non_soz_fdr_q_lt_0_05_percent', '')} |"
        )

    lines.extend(
        [
            "",
            "## 7. 输出文件说明",
            "",
            "- `05_pac_results_long.csv`：完整PAC长表，一行是一个片段、一个方法、一个相位-振幅频段组合。",
            "- `05_pac_peak_by_segment.csv`：每个片段、每种PAC方法中z值最大的频段组合。",
            "- `05_pac_summary_by_scope_label_method.csv`：按combined/ECOG/SEEG、SOZ标签和方法汇总。",
            "- `05_pac_frequency_pair_summary.csv`：按频段组合汇总。",
            "- `05_pac_soz_nonsoz_comparison.csv`：SOZ和non-SOZ的频段差异对比表。",
            "- `05_column_dictionary_中文说明.csv`：主要列名中文解释。",
            "- `05_pac_config.json`：本次PAC参数记录。",
            "",
            "## 8. 下一步",
            "",
            "下一步建议进入 PPC，计算不同频段相位之间的同步/锁定关系，并继续按 combined、ECOG-only、SEEG-only 三套范围输出结果。",
            "",
        ]
    )
    (OUTPUT_DIR / "05_pac_standard_summary.md").write_text("\n".join(lines), encoding="utf-8-sig")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Compute standard PAC features for ds004100 CFC segments.")
    parser.add_argument("--n-surrogates", type=int, default=DEFAULT_N_SURROGATES)
    parser.add_argument("--max-segments", type=int, default=0, help="Optional smoke-test limit; 0 means all segments.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    if not INPUT_INDEX.exists():
        raise FileNotFoundError(f"Missing Step 4 index: {INPUT_INDEX}")

    index_df = read_csv(INPUT_INDEX)
    if args.max_segments and args.max_segments > 0:
        index_df = index_df.head(args.max_segments).copy()

    rng = np.random.default_rng(RANDOM_SEED)
    result_rows: list[dict[str, Any]] = []
    started_at = time.monotonic()
    last_progress_at = 0.0

    for i, (_idx, row) in enumerate(index_df.iterrows(), start=1):
        now = time.monotonic()
        if i == 1 or i == len(index_df) or now - last_progress_at >= PROGRESS_INTERVAL_SEC:
            elapsed = now - started_at
            print(
                f"epoch {i}/{len(index_df)} | elapsed={elapsed:.1f}s | "
                f"{row['segment_id']} {row['acquisition']} {row['channel_name']} {row['soz_label']}",
                flush=True,
            )
            last_progress_at = now
        result_rows.extend(compute_segment_pac(row, rng, args.n_surrogates))

    results = add_fdr_columns(pd.DataFrame(result_rows))
    peaks = build_peak_rows(results)
    method_summary, pair_summary, comparison = summarize_results(results)
    column_dictionary = build_column_dictionary()

    write_csv(results, OUTPUT_DIR / "05_pac_results_long.csv")
    write_csv(peaks, OUTPUT_DIR / "05_pac_peak_by_segment.csv")
    write_csv(method_summary, OUTPUT_DIR / "05_pac_summary_by_scope_label_method.csv")
    write_csv(pair_summary, OUTPUT_DIR / "05_pac_frequency_pair_summary.csv")
    write_csv(comparison, OUTPUT_DIR / "05_pac_soz_nonsoz_comparison.csv")
    write_csv(column_dictionary, OUTPUT_DIR / "05_column_dictionary_中文说明.csv")

    config = {
        "input_index": str(INPUT_INDEX),
        "output_dir": str(OUTPUT_DIR),
        "phase_bands": PHASE_BANDS,
        "amplitude_bands": AMPLITUDE_BANDS,
        "methods": METHOD_LABELS,
        "n_surrogates": args.n_surrogates,
        "n_phase_bins": N_PHASE_BINS,
        "random_seed": RANDOM_SEED,
        "fdr_method": "Benjamini-Hochberg",
        "fdr_scope": "all PAC result rows across all segments, methods, and phase-amplitude frequency pairs",
        "analysis_scopes": ["combined", "ecog_only", "seeg_only"],
        "max_segments": args.max_segments,
    }
    (OUTPUT_DIR / "05_pac_config.json").write_text(
        json.dumps(config, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    write_summary_md(index_df, results, peaks, method_summary, comparison, args.n_surrogates)

    print(f"Done. PAC rows={len(results)}, peaks={len(peaks)}", flush=True)
    print(f"Output dir: {OUTPUT_DIR}", flush=True)


if __name__ == "__main__":
    main()


