"""Coherence between a low-frequency signal and a high-frequency envelope.

pipeline.configure selects the frozen 4-s or 2-s Welch duration for each run.
This is not ordinary coherence between two unmodified EEG frequency bands.
"""
from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
INPUT_INDEX = PROJECT_ROOT / "outputs" / "cfc_ds004100_fs_ge500_full" / "preprocessed_segments" / "04_cfc_segments_index.csv"
OUTPUT_DIR = PROJECT_ROOT / "outputs" / "cfc_ds004100_fs_ge500_full" / "cfc_coherence_standard"

RANDOM_SEED = 20260714
DEFAULT_N_SURROGATES = 200
WELCH_WINDOW_SEC = 4.0
WELCH_OVERLAP = 0.5
ENVELOPE_SMOOTHING_SEC = 0.2
PROGRESS_INTERVAL_SEC = 10.0

LOW_SIGNAL_BANDS = [
    ("delta", "delta", 2.0, 4.0),
    ("theta", "theta", 4.0, 8.0),
    ("alpha", "alpha", 8.0, 13.0),
    ("beta", "beta", 13.0, 30.0),
]

HIGH_AMPLITUDE_BANDS = [
    ("low_gamma", "low-gamma", 30.0, 55.0),
    ("high_gamma", "high-gamma", 65.0, 100.0),
    ("ripple", "ripple", 100.0, 150.0),
    ("fast_ripple_low", "fast-ripple-low", 150.0, 200.0),
]


def read_csv(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    df.columns = [str(col).strip() for col in df.columns]
    return df


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8-sig")


def next_power_of_two(value: int) -> int:
    return int(2 ** math.ceil(math.log2(max(2, value))))


def fft_bandpass(x: np.ndarray, sfreq: float, low_hz: float, high_hz: float) -> np.ndarray:
    y = np.asarray(x, dtype=np.float64)
    y = y - np.mean(y)
    freqs = np.fft.rfftfreq(y.size, d=1.0 / sfreq)
    spectrum = np.fft.rfft(y)
    spectrum *= (freqs >= low_hz) & (freqs <= high_hz)
    return np.fft.irfft(spectrum, n=y.size)


def analytic_signal(x: np.ndarray) -> np.ndarray:
    y = np.asarray(x, dtype=np.float64)
    n = y.size
    spectrum = np.fft.fft(y)
    h = np.zeros(n, dtype=np.float64)
    if n % 2 == 0:
        h[0] = 1.0
        h[n // 2] = 1.0
        h[1 : n // 2] = 2.0
    else:
        h[0] = 1.0
        h[1 : (n + 1) // 2] = 2.0
    return np.fft.ifft(spectrum * h)


def valid_band(sfreq: float, low_hz: float, high_hz: float) -> bool:
    nyquist = sfreq / 2.0
    return low_hz > 0 and high_hz > low_hz and high_hz < nyquist - 1.0


def zscore(x: np.ndarray) -> np.ndarray:
    y = np.asarray(x, dtype=np.float64)
    std = float(np.std(y))
    if std <= 0 or not np.isfinite(std):
        return np.zeros_like(y, dtype=np.float64)
    return (y - float(np.mean(y))) / std


def moving_average(x: np.ndarray, window_samples: int) -> np.ndarray:
    if window_samples <= 1:
        return x
    kernel = np.ones(int(window_samples), dtype=np.float64) / float(window_samples)
    return np.convolve(x, kernel, mode="same")


def amplitude_envelope_from_band(x: np.ndarray, sfreq: float, low_hz: float, high_hz: float) -> np.ndarray:
    filtered = fft_bandpass(x, sfreq, low_hz, high_hz)
    envelope = np.abs(analytic_signal(filtered))
    log_envelope = np.log(envelope + np.finfo(np.float64).eps)
    smooth_window = max(1, int(round(ENVELOPE_SMOOTHING_SEC * sfreq)))
    smoothed = moving_average(log_envelope, smooth_window)
    return zscore(smoothed)


def make_welch_windows(x: np.ndarray, sfreq: float) -> tuple[np.ndarray, int, int, int]:
    window_samples = int(round(WELCH_WINDOW_SEC * sfreq))
    step_samples = max(1, int(round(window_samples * (1.0 - WELCH_OVERLAP))))
    if window_samples <= 1:
        raise ValueError("Welch window is too short")
    if x.size < window_samples:
        raise ValueError("signal is shorter than one Welch window")
    starts = np.arange(0, x.size - window_samples + 1, step_samples, dtype=int)
    windows = np.stack([x[start : start + window_samples] for start in starts], axis=0).astype(np.float64)
    windows -= np.mean(windows, axis=1, keepdims=True)
    taper = np.hanning(window_samples + 1)[:-1]
    windows *= taper[np.newaxis, :]
    nfft = next_power_of_two(window_samples)
    return windows, window_samples, step_samples, nfft


def welch_fft(x: np.ndarray, sfreq: float) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    windows, window_samples, step_samples, nfft = make_welch_windows(x=x, sfreq=sfreq)
    spectrum = np.fft.rfft(windows, n=nfft, axis=1)
    freqs = np.fft.rfftfreq(nfft, d=1.0 / sfreq)
    info = {
        "welch_window_count": int(windows.shape[0]),
        "welch_window_samples": int(window_samples),
        "welch_window_step_samples": int(step_samples),
        "welch_nfft": int(nfft),
        "welch_frequency_resolution_hz": float(freqs[1] - freqs[0]),
    }
    return spectrum, freqs, info


def coherence_peak_mean(
    low_fft_band: np.ndarray,
    high_fft_band: np.ndarray,
    band_freqs: np.ndarray,
) -> tuple[float, float, float]:
    pxx = np.mean(np.abs(low_fft_band) ** 2, axis=0)
    pyy = np.mean(np.abs(high_fft_band) ** 2, axis=0)
    pxy = np.mean(low_fft_band * np.conj(high_fft_band), axis=0)
    denominator = pxx * pyy
    coherence = np.full_like(pxx, np.nan, dtype=np.float64)
    valid = denominator > 0
    coherence[valid] = np.clip(np.abs(pxy[valid]) ** 2 / denominator[valid], 0.0, 1.0)
    finite = np.isfinite(coherence)
    if not np.any(finite):
        return math.nan, math.nan, math.nan
    finite_values = coherence[finite]
    finite_freqs = band_freqs[finite]
    peak_idx = int(np.argmax(finite_values))
    return float(finite_values[peak_idx]), float(np.mean(finite_values)), float(finite_freqs[peak_idx])


def surrogate_stats(
    low_fft_band: np.ndarray,
    high_fft_band: np.ndarray,
    observed: float,
    permutations: np.ndarray,
) -> tuple[float, float, float, float]:
    if not np.isfinite(observed):
        return math.nan, math.nan, math.nan, math.nan

    permuted_high = high_fft_band[permutations]
    pxx = np.mean(np.abs(low_fft_band) ** 2, axis=0)
    pyy = np.mean(np.abs(permuted_high) ** 2, axis=1)
    pxy = np.mean(low_fft_band[np.newaxis, :, :] * np.conj(permuted_high), axis=1)
    denominator = pxx[np.newaxis, :] * pyy
    coherence = np.full_like(denominator, np.nan, dtype=np.float64)
    valid = denominator > 0
    coherence[valid] = np.clip(np.abs(pxy[valid]) ** 2 / denominator[valid], 0.0, 1.0)
    values = np.nanmax(coherence, axis=1)
    values = values[np.isfinite(values)]
    if values.size == 0:
        return math.nan, math.nan, math.nan, math.nan
    mean = float(np.mean(values))
    std = float(np.std(values, ddof=1)) if values.size > 1 else 0.0
    z_value = float((observed - mean) / std) if std > 0 else 0.0
    p_value = float((np.sum(values >= observed) + 1) / (values.size + 1))
    return mean, std, z_value, p_value


def benjamini_hochberg(p_values: pd.Series) -> pd.Series:
    p = pd.to_numeric(p_values, errors="coerce").to_numpy(dtype=float)
    q = np.full(p.shape, np.nan, dtype=float)
    valid = np.isfinite(p)
    if not np.any(valid):
        return pd.Series(q, index=p_values.index)
    p_valid = np.clip(p[valid], 0.0, 1.0)
    order = np.argsort(p_valid)
    ranked = p_valid[order]
    n_tests = ranked.size
    raw_q = ranked * n_tests / np.arange(1, n_tests + 1)
    monotone = np.minimum.accumulate(raw_q[::-1])[::-1]
    restored = np.empty_like(monotone)
    restored[order] = np.clip(monotone, 0.0, 1.0)
    q[valid] = restored
    return pd.Series(q, index=p_values.index)


def add_fdr_columns(results: pd.DataFrame) -> pd.DataFrame:
    out = results.copy()
    out["p_value"] = pd.to_numeric(out["p_value"], errors="coerce")
    out["fdr_q_value"] = benjamini_hochberg(out["p_value"])
    out["p_lt_0_05"] = out["p_value"] < 0.05
    out["fdr_q_lt_0_05"] = out["fdr_q_value"] < 0.05
    out["fdr_scope"] = "all_cfc_coherence_rows"
    return out


def build_band_pairs() -> list[dict[str, Any]]:
    pairs: list[dict[str, Any]] = []
    for low_band in LOW_SIGNAL_BANDS:
        for high_band in HIGH_AMPLITUDE_BANDS:
            pairs.append(
                {
                    "low_signal_band": low_band[0],
                    "low_signal_band_label": low_band[1],
                    "low_signal_low_hz": low_band[2],
                    "low_signal_high_hz": low_band[3],
                    "high_amplitude_band": high_band[0],
                    "high_amplitude_band_label": high_band[1],
                    "high_amplitude_low_hz": high_band[2],
                    "high_amplitude_high_hz": high_band[3],
                }
            )
    return pairs


def compute_segment_cfc_coherence(
    row: pd.Series,
    band_pairs: list[dict[str, Any]],
    n_surrogates: int,
    rng: np.random.Generator,
) -> list[dict[str, Any]]:
    loaded = np.load(row["segment_file"])
    x = np.asarray(loaded["signal"], dtype=np.float64)
    sfreq = float(loaded["sampling_frequency_hz"])

    low_fft_cache: dict[tuple[float, float], tuple[np.ndarray, np.ndarray, dict[str, Any]]] = {}
    high_fft_cache: dict[tuple[float, float], np.ndarray] = {}
    high_envelope_cache: dict[tuple[float, float], np.ndarray] = {}

    needed_low = sorted({(float(p["low_signal_low_hz"]), float(p["low_signal_high_hz"])) for p in band_pairs})
    needed_high = sorted({(float(p["high_amplitude_low_hz"]), float(p["high_amplitude_high_hz"])) for p in band_pairs})

    for low_hz, high_hz in needed_low:
        if not valid_band(sfreq, low_hz, high_hz):
            continue
        low_signal = zscore(fft_bandpass(x, sfreq, low_hz, high_hz))
        low_fft_cache[(low_hz, high_hz)] = welch_fft(low_signal, sfreq)

    for low_hz, high_hz in needed_high:
        if not valid_band(sfreq, low_hz, high_hz):
            continue
        high_envelope_cache[(low_hz, high_hz)] = amplitude_envelope_from_band(x, sfreq, low_hz, high_hz)

    rows: list[dict[str, Any]] = []
    for pair in band_pairs:
        low_key = (float(pair["low_signal_low_hz"]), float(pair["low_signal_high_hz"]))
        high_key = (float(pair["high_amplitude_low_hz"]), float(pair["high_amplitude_high_hz"]))
        if low_key not in low_fft_cache or high_key not in high_envelope_cache:
            continue

        low_fft, freqs, info = low_fft_cache[low_key]
        if high_key not in high_fft_cache:
            high_fft, high_freqs, _high_info = welch_fft(high_envelope_cache[high_key], sfreq)
            if high_fft.shape != low_fft.shape or not np.allclose(high_freqs, freqs):
                raise ValueError("Low signal and high envelope FFT grids do not match")
            high_fft_cache[high_key] = high_fft
        high_fft = high_fft_cache[high_key]

        freq_mask = (freqs >= low_key[0]) & (freqs <= low_key[1])
        if not np.any(freq_mask):
            continue
        low_fft_band = low_fft[:, freq_mask]
        high_fft_band = high_fft[:, freq_mask]
        band_freqs = freqs[freq_mask]

        observed, mean_coherence, peak_freq = coherence_peak_mean(low_fft_band, high_fft_band, band_freqs)
        n_windows = int(info["welch_window_count"])
        permutations = np.vstack([rng.permutation(n_windows) for _ in range(n_surrogates)])
        surrogate_mean, surrogate_std, z_value, p_value = surrogate_stats(
            low_fft_band=low_fft_band,
            high_fft_band=high_fft_band,
            observed=observed,
            permutations=permutations,
        )

        rows.append(
            {
                "segment_id": row["segment_id"],
                "cfc_sample_id": row["cfc_sample_id"],
                "participant_id": row["participant_id"],
                "run_key": row["run_key"],
                "acquisition": row["acquisition"],
                "channel_name": row["channel_name"],
                "channel_name_key": row["channel_name_key"],
                "channel_type": row["channel_type"],
                "soz_label": row["soz_label"],
                "is_soz": row["is_soz"],
                "low_signal_band": pair["low_signal_band"],
                "low_signal_band_label": pair["low_signal_band_label"],
                "low_signal_low_hz": pair["low_signal_low_hz"],
                "low_signal_high_hz": pair["low_signal_high_hz"],
                "high_amplitude_band": pair["high_amplitude_band"],
                "high_amplitude_band_label": pair["high_amplitude_band_label"],
                "high_amplitude_low_hz": pair["high_amplitude_low_hz"],
                "high_amplitude_high_hz": pair["high_amplitude_high_hz"],
                "coherence_peak_value": observed,
                "coherence_mean_in_low_band": mean_coherence,
                "coherence_peak_freq_hz": peak_freq,
                "surrogate_mean": surrogate_mean,
                "surrogate_std": surrogate_std,
                "coherence_z": z_value,
                "p_value": p_value,
                "n_surrogates": n_surrogates,
                "welch_window_sec": WELCH_WINDOW_SEC,
                "welch_overlap": WELCH_OVERLAP,
                "envelope_smoothing_sec": ENVELOPE_SMOOTHING_SEC,
                "final_sampling_frequency_hz": sfreq,
                "segment_file": row["segment_file"],
                **info,
            }
        )
    return rows


def cohen_d(a: pd.Series, b: pd.Series) -> float:
    x = pd.to_numeric(a, errors="coerce").dropna().to_numpy(dtype=float)
    y = pd.to_numeric(b, errors="coerce").dropna().to_numpy(dtype=float)
    if x.size < 2 or y.size < 2:
        return math.nan
    pooled = math.sqrt(((x.size - 1) * np.var(x, ddof=1) + (y.size - 1) * np.var(y, ddof=1)) / (x.size + y.size - 2))
    if pooled <= 0:
        return 0.0
    return float((np.mean(x) - np.mean(y)) / pooled)


def scope_frames(results: pd.DataFrame) -> list[tuple[str, pd.DataFrame]]:
    frames = [("combined", results)]
    for acquisition in ["ecog", "seeg"]:
        frames.append((f"{acquisition}_only", results[results["acquisition"] == acquisition]))
    return frames


def build_peak_rows(results: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for segment_id, group in results.groupby("segment_id", dropna=False):
        finite = group[np.isfinite(pd.to_numeric(group["coherence_z"], errors="coerce"))]
        if finite.empty:
            continue
        peak = finite.sort_values("coherence_z", ascending=False).iloc[0]
        rows.append(
            {
                "segment_id": segment_id,
                "cfc_sample_id": peak["cfc_sample_id"],
                "participant_id": peak["participant_id"],
                "run_key": peak["run_key"],
                "acquisition": peak["acquisition"],
                "channel_name": peak["channel_name"],
                "channel_type": peak["channel_type"],
                "soz_label": peak["soz_label"],
                "peak_low_signal_band": peak["low_signal_band"],
                "peak_high_amplitude_band": peak["high_amplitude_band"],
                "peak_coherence_value": peak["coherence_peak_value"],
                "peak_coherence_freq_hz": peak["coherence_peak_freq_hz"],
                "peak_z": peak["coherence_z"],
                "peak_p_value": peak["p_value"],
                "peak_fdr_q_value": peak["fdr_q_value"],
                "peak_fdr_q_lt_0_05": peak["fdr_q_lt_0_05"],
                "n_surrogates": peak["n_surrogates"],
            }
        )
    return pd.DataFrame(rows)


def summarize_results(results: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    label_rows: list[dict[str, Any]] = []
    pair_rows: list[dict[str, Any]] = []
    comparison_rows: list[dict[str, Any]] = []

    for scope, scope_df in scope_frames(results):
        if scope_df.empty:
            continue

        for label, group in scope_df.groupby("soz_label", dropna=False):
            label_rows.append(
                {
                    "analysis_scope": scope,
                    "soz_label": label,
                    "rows": len(group),
                    "segment_count": group["segment_id"].nunique(),
                    "mean_coherence_peak_value": float(pd.to_numeric(group["coherence_peak_value"]).mean()),
                    "mean_coherence_z": float(pd.to_numeric(group["coherence_z"]).mean()),
                    "median_coherence_z": float(pd.to_numeric(group["coherence_z"]).median()),
                    "p_lt_0_05_percent": round(100 * pd.to_numeric(group["p_lt_0_05"]).mean(), 3),
                    "fdr_q_lt_0_05_percent": round(100 * pd.to_numeric(group["fdr_q_lt_0_05"]).mean(), 3),
                }
            )

        pair_group_cols = ["low_signal_band", "high_amplitude_band", "soz_label"]
        for keys, group in scope_df.groupby(pair_group_cols, dropna=False):
            low_band, high_band, label = keys
            pair_rows.append(
                {
                    "analysis_scope": scope,
                    "low_signal_band": low_band,
                    "high_amplitude_band": high_band,
                    "soz_label": label,
                    "rows": len(group),
                    "segment_count": group["segment_id"].nunique(),
                    "mean_coherence_peak_value": float(pd.to_numeric(group["coherence_peak_value"]).mean()),
                    "mean_coherence_z": float(pd.to_numeric(group["coherence_z"]).mean()),
                    "median_coherence_z": float(pd.to_numeric(group["coherence_z"]).median()),
                    "fdr_q_lt_0_05_percent": round(100 * pd.to_numeric(group["fdr_q_lt_0_05"]).mean(), 3),
                }
            )

        comp_cols = ["low_signal_band", "high_amplitude_band"]
        for keys, group in scope_df.groupby(comp_cols, dropna=False):
            low_band, high_band = keys
            soz = group[group["soz_label"] == "SOZ"]
            non = group[group["soz_label"] == "non-SOZ"]
            comparison_rows.append(
                {
                    "analysis_scope": scope,
                    "low_signal_band": low_band,
                    "high_amplitude_band": high_band,
                    "soz_rows": len(soz),
                    "non_soz_rows": len(non),
                    "soz_mean_z": float(pd.to_numeric(soz["coherence_z"]).mean()) if len(soz) else math.nan,
                    "non_soz_mean_z": float(pd.to_numeric(non["coherence_z"]).mean()) if len(non) else math.nan,
                    "soz_minus_non_soz_mean_z": (
                        float(pd.to_numeric(soz["coherence_z"]).mean() - pd.to_numeric(non["coherence_z"]).mean())
                        if len(soz) and len(non)
                        else math.nan
                    ),
                    "cohen_d_soz_vs_non_soz_z": cohen_d(soz["coherence_z"], non["coherence_z"]) if len(soz) and len(non) else math.nan,
                    "soz_mean_value": float(pd.to_numeric(soz["coherence_peak_value"]).mean()) if len(soz) else math.nan,
                    "non_soz_mean_value": float(pd.to_numeric(non["coherence_peak_value"]).mean()) if len(non) else math.nan,
                    "soz_fdr_q_lt_0_05_percent": round(100 * pd.to_numeric(soz["fdr_q_lt_0_05"]).mean(), 3) if len(soz) else math.nan,
                    "non_soz_fdr_q_lt_0_05_percent": round(100 * pd.to_numeric(non["fdr_q_lt_0_05"]).mean(), 3) if len(non) else math.nan,
                }
            )

    comparison = pd.DataFrame(comparison_rows)
    if not comparison.empty:
        comparison = comparison.sort_values(["analysis_scope", "soz_minus_non_soz_mean_z"], ascending=[True, False])
    return pd.DataFrame(label_rows), pd.DataFrame(pair_rows), comparison


def build_column_dictionary() -> pd.DataFrame:
    rows = [
        ("coherence_peak_value", "低频范围内最高的跨频相干值"),
        ("coherence_mean_in_low_band", "低频范围内平均跨频相干值"),
        ("coherence_peak_freq_hz", "相干峰值对应的频率"),
        ("coherence_z", "真实相干峰值相对于surrogate分布的Z值"),
        ("low_signal_band", "低频原始信号频段"),
        ("high_amplitude_band", "高频振幅包络频段"),
        ("surrogate_mean", "随机打乱Welch短窗后的surrogate平均相干值"),
        ("surrogate_std", "surrogate相干值标准差"),
        ("p_value", "经验p值，表示surrogate结果大于等于真实结果的比例"),
        ("fdr_q_value", "BH-FDR多重比较校正后的q值"),
        ("analysis_scope", "分析范围：combined为全部，ecog_only只看ECOG，seeg_only只看SEEG"),
        ("soz_minus_non_soz_mean_z", "SOZ平均Z值减去non-SOZ平均Z值"),
        ("cohen_d_soz_vs_non_soz_z", "SOZ与non-SOZ的Z值差异效应量"),
    ]
    return pd.DataFrame(rows, columns=["column", "中文含义"])


def write_summary_md(
    output_dir: Path,
    index_df: pd.DataFrame,
    band_pairs: list[dict[str, Any]],
    results: pd.DataFrame,
    peaks: pd.DataFrame,
    failures: pd.DataFrame,
    label_summary: pd.DataFrame,
    comparison: pd.DataFrame,
    n_surrogates: int,
) -> None:
    top_combined = comparison[comparison["analysis_scope"] == "combined"].head(10) if not comparison.empty else pd.DataFrame()
    lines = [
        "# Step 9 ds004100 跨频相干标准版计算报告",
        "",
        "## 1. 这一步做什么",
        "",
        "跨频相干看的是低频信号与高频振幅包络之间是否存在稳定的谱相干关系。直观地说，如果高频能量包络随某个低频节律同步变化，那么相干值会偏高。",
        "",
        "## 2. 统计口径",
        "",
        f"- 输入文件：`{INPUT_INDEX}`",
        f"- surrogate次数：`{n_surrogates}`",
        f"- Welch短窗长度：`{WELCH_WINDOW_SEC}` 秒",
        f"- Welch短窗重叠：`{WELCH_OVERLAP}`",
        f"- 候选频段组合数量：`{len(band_pairs)}`",
        f"- 高频包络平滑窗口：`{ENVELOPE_SMOOTHING_SEC}` 秒",
        "- 多重比较校正：Benjamini-Hochberg FDR。",
        "- 输出三种分析范围：`combined`、`ecog_only`、`seeg_only`。",
        "",
        "## 3. 主要结果规模",
        "",
        f"- 输入片段数：{len(index_df)}",
        f"- 成功片段数：{results['segment_id'].nunique() if not results.empty else 0}",
        f"- 失败片段数：{len(failures)}",
        f"- 跨频相干长表行数：{len(results)}",
        f"- 峰值表行数：{len(peaks)}",
        "",
        "## 4. 标签汇总",
        "",
        "| 范围 | 标签 | 片段数 | 平均相干峰值 | 平均z值 | 中位z值 | p<0.05比例% | FDR q<0.05比例% |",
        "|---|---|---:|---:|---:|---:|---:|---:|",
    ]
    for _idx, row in label_summary.iterrows():
        lines.append(
            f"| {row.get('analysis_scope', '')} | {row.get('soz_label', '')} | {row.get('segment_count', '')} | "
            f"{float(row.get('mean_coherence_peak_value', 0)):.4f} | {float(row.get('mean_coherence_z', 0)):.4f} | "
            f"{float(row.get('median_coherence_z', 0)):.4f} | {row.get('p_lt_0_05_percent', '')} | "
            f"{row.get('fdr_q_lt_0_05_percent', '')} |"
        )

    lines.extend(
        [
            "",
            "## 5. combined范围内SOZ高于non-SOZ最多的频段组合",
            "",
            "| 低频信号 | 高频振幅包络 | SOZ平均z | non-SOZ平均z | 差值 | Cohen d | SOZ FDR显著% | non-SOZ FDR显著% |",
            "|---|---|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for _idx, row in top_combined.iterrows():
        lines.append(
            f"| {row.get('low_signal_band', '')} | {row.get('high_amplitude_band', '')} | "
            f"{float(row.get('soz_mean_z', 0)):.4f} | {float(row.get('non_soz_mean_z', 0)):.4f} | "
            f"{float(row.get('soz_minus_non_soz_mean_z', 0)):.4f} | {float(row.get('cohen_d_soz_vs_non_soz_z', 0)):.4f} | "
            f"{row.get('soz_fdr_q_lt_0_05_percent', '')} | {row.get('non_soz_fdr_q_lt_0_05_percent', '')} |"
        )

    lines.extend(
        [
            "",
            "## 6. 输出文件说明",
            "",
            "- `09_cfc_coherence_results_long.csv`：完整跨频相干长表。",
            "- `09_cfc_coherence_peak_by_segment.csv`：每个片段中coherence_z最高的频段组合。",
            "- `09_cfc_coherence_summary_by_scope_label.csv`：按combined/ECOG/SEEG和SOZ标签汇总。",
            "- `09_cfc_coherence_frequency_pair_summary.csv`：按频段组合汇总。",
            "- `09_cfc_coherence_soz_nonsoz_comparison.csv`：SOZ与non-SOZ在每个频段组合上的差异对比表。",
            "- `09_cfc_coherence_failures.csv`：失败片段记录；如果为空说明没有失败。",
            "- `09_column_dictionary_中文说明.csv`：主要列名中文解释。",
            "- `09_cfc_coherence_config.json`：本次参数记录。",
            "",
        ]
    )
    (output_dir / "09_cfc_coherence_standard_summary.md").write_text("\n".join(lines), encoding="utf-8-sig")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Compute ds004100 cross-frequency coherence features.")
    parser.add_argument("--n-surrogates", type=int, default=DEFAULT_N_SURROGATES)
    parser.add_argument("--max-segments", type=int, default=0)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    if not INPUT_INDEX.exists():
        raise FileNotFoundError(f"Missing Step 4 index: {INPUT_INDEX}")

    index_df = read_csv(INPUT_INDEX)
    if args.max_segments and args.max_segments > 0:
        index_df = index_df.head(args.max_segments).copy()
    band_pairs = build_band_pairs()
    print(f"CFC coherence band pairs: {len(band_pairs)}", flush=True)

    rng = np.random.default_rng(RANDOM_SEED)
    rows: list[dict[str, Any]] = []
    failure_rows: list[dict[str, Any]] = []
    started_at = time.monotonic()
    last_progress_at = 0.0
    for i, (_idx, row) in enumerate(index_df.iterrows(), start=1):
        now = time.monotonic()
        if i == 1 or i == len(index_df) or now - last_progress_at >= PROGRESS_INTERVAL_SEC:
            print(
                f"epoch {i}/{len(index_df)} | elapsed={now-started_at:.1f}s | "
                f"{row['segment_id']} {row['acquisition']} {row['channel_name']} {row['soz_label']}",
                flush=True,
            )
            last_progress_at = now
        try:
            rows.extend(compute_segment_cfc_coherence(row, band_pairs, args.n_surrogates, rng))
        except Exception as exc:
            failure_rows.append(
                {
                    "segment_id": row.get("segment_id", ""),
                    "participant_id": row.get("participant_id", ""),
                    "run_key": row.get("run_key", ""),
                    "channel_name": row.get("channel_name", ""),
                    "soz_label": row.get("soz_label", ""),
                    "error": repr(exc),
                }
            )

    results = add_fdr_columns(pd.DataFrame(rows))
    failures = pd.DataFrame(failure_rows)
    peaks = build_peak_rows(results) if not results.empty else pd.DataFrame()
    label_summary, pair_summary, comparison = summarize_results(results) if not results.empty else (pd.DataFrame(), pd.DataFrame(), pd.DataFrame())
    column_dictionary = build_column_dictionary()

    write_csv(results, output_dir / "09_cfc_coherence_results_long.csv")
    write_csv(peaks, output_dir / "09_cfc_coherence_peak_by_segment.csv")
    write_csv(failures, output_dir / "09_cfc_coherence_failures.csv")
    write_csv(label_summary, output_dir / "09_cfc_coherence_summary_by_scope_label.csv")
    write_csv(pair_summary, output_dir / "09_cfc_coherence_frequency_pair_summary.csv")
    write_csv(comparison, output_dir / "09_cfc_coherence_soz_nonsoz_comparison.csv")
    write_csv(column_dictionary, output_dir / "09_column_dictionary_中文说明.csv")

    config = {
        "input_index": str(INPUT_INDEX),
        "output_dir": str(output_dir),
        "low_signal_bands": LOW_SIGNAL_BANDS,
        "high_amplitude_bands": HIGH_AMPLITUDE_BANDS,
        "band_pair_count_before_nyquist_filtering": len(band_pairs),
        "welch_window_sec": WELCH_WINDOW_SEC,
        "welch_overlap": WELCH_OVERLAP,
        "envelope_smoothing_sec": ENVELOPE_SMOOTHING_SEC,
        "n_surrogates": args.n_surrogates,
        "random_seed": RANDOM_SEED,
        "fdr_method": "Benjamini-Hochberg",
        "fdr_scope": "all CFC coherence result rows",
        "analysis_scopes": ["combined", "ecog_only", "seeg_only"],
        "max_segments": args.max_segments,
    }
    (output_dir / "09_cfc_coherence_config.json").write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    write_summary_md(output_dir, index_df, band_pairs, results, peaks, failures, label_summary, comparison, args.n_surrogates)

    elapsed = time.monotonic() - started_at
    print(f"Done. CFC coherence rows={len(results)}, peaks={len(peaks)}, failures={len(failures)}, elapsed={elapsed:.1f}s", flush=True)
    print(f"Output dir: {output_dir}", flush=True)


if __name__ == "__main__":
    main()


