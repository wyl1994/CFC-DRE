"""Event-based conservative spike interpolation used in the PAC sensitivity analysis.

Scientific definitions follow the frozen author analysis; see REPRODUCE.md.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from scipy import signal

from . import raw_sensitivity as raw
from . import metrics as cfc
from . import surrogates as convergence


N_SURROGATES = 1000
SEED = 20260919
FEATURES_PER_WINDOW = 45
WINDOWS = raw.PRIMARY_WINDOWS


def append_csv(path: Path, row: dict[str, Any]) -> None:
    exists = path.exists()
    with path.open("a", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(row))
        if not exists:
            writer.writeheader()
        writer.writerow(row)


def conservative_spike_mask(values: np.ndarray) -> tuple[np.ndarray, dict[str, float]]:
    x = np.asarray(values, dtype=np.float64)
    amplitude = np.abs(x - np.median(x))
    amp_scale = 1.4826 * np.median(np.abs(amplitude - np.median(amplitude))) + np.finfo(float).eps
    derivative = np.abs(np.diff(x, prepend=x[0]) - np.median(np.diff(x, prepend=x[0])))
    derivative_scale = 1.4826 * np.median(np.abs(derivative - np.median(derivative))) + np.finfo(float).eps
    score = np.maximum(amplitude / amp_scale, derivative / derivative_scale)
    peaks, properties = signal.find_peaks(
        score,
        height=8.0,
        prominence=2.0,
        distance=int(round(0.08 * cfc.TARGET_SFREQ)),
    )
    half_width = int(round(0.025 * cfc.TARGET_SFREQ))
    mask = np.zeros(x.size, dtype=bool)
    for peak in peaks:
        mask[max(0, peak - half_width): min(x.size, peak + half_width + 1)] = True
    cleaned = x.copy()
    good = ~mask
    if mask.any() and good.sum() >= 2:
        samples = np.arange(x.size)
        cleaned[mask] = np.interp(samples[mask], samples[good], x[good])
    return cleaned, {
        "event_count": int(len(peaks)),
        "event_rate_hz": float(len(peaks) / (x.size / cfc.TARGET_SFREQ)),
        "mask_fraction": float(mask.mean()),
        "median_peak_score": float(np.median(properties["peak_heights"])) if len(peaks) else 0.0,
    }


def process_record(record: dict[str, str], channels: list[dict[str, str]], output: Path) -> dict[str, Any]:
    started = time.perf_counter()
    directory = output / "raw_cache" / raw.safe_name(record["dataset_id"]) / raw.safe_name(record["patient_id"])
    path = directory / f"{raw.safe_name(record['recording_id'])}_conservative_spike_PAC.parquet"
    expected = len(channels) * len(WINDOWS) * FEATURES_PER_WINDOW
    if path.exists() and raw.parquet_rows(path) == expected:
        return {"status": "skipped_valid", "rows": expected, "seconds": 0.0}
    references, source_sfreq = raw.read_references(record, channels)
    rows: list[dict[str, Any]] = []
    for position, channel in enumerate(channels):
        cleaned, diagnostics = conservative_spike_mask(references["CAR"][position])
        metadata = {
            "analysis_id": "conservative_spike_masked", "dataset_id": record["dataset_id"],
            "patient_id": record["patient_id"], "recording_id": record["recording_id"],
            "implant_type": record["implant_type"], "onset_sec": float(record["onset_sec"]),
            "source_sampling_frequency_hz": source_sfreq, "channel_name": channel["channel_name_raw"],
            "channel_index_1based": int(channel["channel_index_1based"]), "soz_label": channel["soz_label"],
            "reference": "CAR_conservative_spike_masked", "n_reference_channels": len(channels), "seed_id": SEED,
        }
        components = raw.targeted_components(cleaned)
        for window in WINDOWS:
            section = cfc.window_slice(window)
            window_rows = convergence.compute_pac(metadata, window, components, section, SEED)
            if len(window_rows) != FEATURES_PER_WINDOW:
                raise AssertionError(f"expected_{FEATURES_PER_WINDOW}_got_{len(window_rows)}")
            for row in window_rows:
                row.update({
                    "analysis_id": "conservative_spike_masked", "window_start_sec": window.start_sec,
                    "window_end_sec": window.end_sec, "window_duration_sec": window.end_sec - window.start_sec,
                    "spike_event_count": diagnostics["event_count"], "spike_event_rate_hz": diagnostics["event_rate_hz"],
                    "spike_mask_fraction": diagnostics["mask_fraction"], "median_peak_score": diagnostics["median_peak_score"],
                })
                rows.append(row)
    frame = pd.DataFrame(rows)
    if len(frame) != expected or not frame["finite_pass"].eq(1).all():
        raise AssertionError(f"invalid_rows:{len(frame)}:{expected}")
    numeric = ["onset_sec", "source_sampling_frequency_hz", "channel_index_1based", "n_reference_channels",
               "seed_id", "window_start_sec", "window_end_sec", "window_duration_sec", "n_surrogates",
               "frequency_1", "frequency_2", "frequency_3", "observed_value", "surrogate_mean", "surrogate_std",
               "z_value", "empirical_p", "spectral_window_count", "finite_pass", "zero_surrogate_variance",
               "spike_event_count", "spike_event_rate_hz", "spike_mask_fraction", "median_peak_score"]
    for column in numeric:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    for column in set(frame.columns) - set(numeric):
        frame[column] = frame[column].fillna("").astype(str)
    raw.write_parquet_atomic(frame, path)
    return {"status": "complete", "rows": len(frame), "seconds": round(time.perf_counter() - started, 3)}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-records", type=int, default=0)
    args = parser.parse_args()
    if cfc.DEVICE is None or cfc.DEVICE.type != "cuda":
        raise RuntimeError("CUDA is required")
    convergence.COUNTS = (N_SURROGATES,)
    args.output.mkdir(parents=True, exist_ok=True)
    seizures = cfc.preprocessing.read_csv(raw.INPUT / "Seizures_post_QC.csv")
    channel_rows = cfc.preprocessing.read_csv(raw.INPUT / "Channels_post_QC.csv")
    channels_by_record: dict[tuple[str, str], list[dict[str, str]]] = {}
    for row in channel_rows:
        channels_by_record.setdefault((row["dataset_id"], row["recording_id"]), []).append(row)
    records = sorted(seizures, key=lambda row: (row["dataset_id"], row["patient_id"], row["recording_id"]))
    raw.repair_signal_paths(records)
    if args.max_records:
        records = records[:args.max_records]
    (args.output / "frozen_config.json").write_text(json.dumps({
        "analysis": "conservative event-level spike-masked PAC", "records": len(records), "n_surrogates": N_SURROGATES,
        "threshold_mad": 8.0, "minimum_event_distance_ms": 80, "mask_half_width_ms": 25,
        "windows": [[-10, 0], [0, 10]], "features": 45, "device": str(cfc.DEVICE),
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    for index, record in enumerate(records, 1):
        channels = sorted(channels_by_record[(record["dataset_id"], record["recording_id"])], key=lambda row: int(row["channel_index_1based"]))
        try:
            result = process_record(record, channels, args.output)
            if result["status"] != "skipped_valid":
                append_csv(args.output / "runtime_log.csv", {"index": index, "total": len(records), "dataset_id": record["dataset_id"],
                           "patient_id": record["patient_id"], "recording_id": record["recording_id"], **result, "error": ""})
            print(f"[{index}/{len(records)}] {record['recording_id']} {result['status']} rows={result['rows']} seconds={result['seconds']}", flush=True)
        except Exception as exc:
            append_csv(args.output / "runtime_log.csv", {"index": index, "total": len(records), "dataset_id": record["dataset_id"],
                       "patient_id": record["patient_id"], "recording_id": record["recording_id"], "status": "failed",
                       "rows": 0, "seconds": 0, "error": f"{type(exc).__name__}: {exc}"})
            print(f"[{index}/{len(records)}] FAILED {record['recording_id']}: {exc}", flush=True)


if __name__ == "__main__":
    main()
