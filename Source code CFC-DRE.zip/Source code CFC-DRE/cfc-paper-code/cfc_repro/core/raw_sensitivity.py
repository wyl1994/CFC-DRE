"""Guard windows, median reference, aggressive masks, power and harmonic diagnostics.

Scientific definitions follow the frozen author analysis; see REPRODUCE.md.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from scipy import signal

from . import metrics as cfc
from . import surrogates as convergence


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "signal_content_qc_20260907" / "full" / "post_qc_manifests"
DATA_ROOT = Path("data/raw")
N_SURROGATES = 1000
SEED = 20260918
FEATURES_PER_WINDOW = 61  # 45 PAC + 16 CFC coherence

PRIMARY_WINDOWS = (
    cfc.WindowSpec("pre_cumulative_10", "temporal_late", "preictal", -10.0, 0.0),
    cfc.WindowSpec("post_cumulative_10", "temporal_early", "ictal", 0.0, 10.0),
)
GUARD_WINDOWS = (
    cfc.WindowSpec("guard_pre_-12_-2", "onset_guard", "preictal", -12.0, -2.0),
    cfc.WindowSpec("guard_post_2_12", "onset_guard", "ictal", 2.0, 12.0),
)

CFC_FIELDS = (
    "analysis_id", "dataset_id", "patient_id", "recording_id", "implant_type", "onset_sec",
    "source_sampling_frequency_hz", "channel_name", "channel_index_1based", "soz_label",
    "reference", "n_reference_channels", "window_id", "state", "window_start_sec",
    "window_end_sec", "window_duration_sec", "seed_id", "n_surrogates", "cfc_family",
    "method", "feature_id", "frequency_1", "frequency_2", "frequency_3", "band_1",
    "band_2", "ratio_label", "observed_value", "surrogate_mean", "surrogate_std",
    "z_value", "empirical_p", "spectral_window_count", "finite_pass",
    "zero_surrogate_variance", "spike_mask_fraction",
)


def safe_name(value: str) -> str:
    return "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in value)


def parquet_rows(path: Path) -> int:
    try:
        return int(pq.ParquetFile(path).metadata.num_rows)
    except Exception:
        return -1


def append_csv(path: Path, row: dict[str, Any]) -> None:
    exists = path.exists()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(row))
        if not exists:
            writer.writeheader()
        writer.writerow(row)


def write_parquet_atomic(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".partial.parquet")
    if temporary.exists():
        temporary.unlink()
    table = pa.Table.from_pandas(frame, preserve_index=False)
    pq.write_table(table, temporary, compression="zstd", compression_level=3)
    temporary.replace(path)


def read_references(record: dict[str, str], channels: list[dict[str, str]]) -> tuple[dict[str, np.ndarray], float]:
    reader = cfc.preprocessing.make_reader(Path(record["signal_path"]), record["file_format"])
    try:
        arrays: list[np.ndarray] = []
        frequencies: list[float] = []
        for channel in channels:
            index = reader.resolve(channel["channel_name_raw"], int(channel["channel_index_1based"]))
            values, sfreq, unit = reader.read(index, float(record["onset_sec"]) - 34.0, cfc.CONTEXT_SEC)
            scale = cfc.preprocessing.unit_scale_to_uv(unit)
            if scale is None:
                raise ValueError(f"Unknown signal unit {unit!r}; correct source metadata before computing")
            arrays.append(values * scale)
            frequencies.append(float(sfreq))
    finally:
        reader.close()
    if not frequencies or max(frequencies) - min(frequencies) > 1e-6:
        raise ValueError("missing_or_mixed_sampling_frequencies")
    sfreq = frequencies[0]
    source = signal.detrend(np.asarray(arrays, dtype=np.float64), axis=-1, type="linear")
    referenced = {
        "CAR": source - np.mean(source, axis=0, keepdims=True),
        "median": source - np.median(source, axis=0, keepdims=True),
    }
    return {
        name: cfc.preprocess_selected(values, sfreq, cfc.preprocessing.LINE_HZ[record["dataset_id"]])
        for name, values in referenced.items()
    }, sfreq


def targeted_components(values: np.ndarray) -> dict[str, Any]:
    components: dict[str, Any] = {"pac_phase": {}, "pac_amplitude": {}, "envelope": {}, "coherence_low": {}}
    for name, low, high in cfc.ALL_BANDS:
        filtered = cfc.fft_bandpass_full(values, low, high)
        analytic = signal.hilbert(filtered)
        if name in {band[0] for band in cfc.PHASE_BANDS}:
            components["pac_phase"][name] = np.angle(analytic)
            components["coherence_low"][name] = filtered
        else:
            components["pac_amplitude"][name] = np.abs(analytic)
        components["envelope"][name] = cfc.smooth_log_envelope(filtered)
    return components


def robust_spike_mask(values: np.ndarray) -> tuple[np.ndarray, dict[str, float]]:
    x = np.asarray(values, dtype=np.float64)
    med = float(np.median(x))
    mad = float(np.median(np.abs(x - med))) * 1.4826 + np.finfo(float).eps
    dx = np.diff(x, prepend=x[0])
    dmed = float(np.median(dx))
    dmad = float(np.median(np.abs(dx - dmed))) * 1.4826 + np.finfo(float).eps
    candidates = (np.abs(x - med) > 6.0 * mad) | (np.abs(dx - dmed) > 6.0 * dmad)
    starts = candidates & ~np.r_[False, candidates[:-1]]
    dilation = int(round(0.10 * cfc.TARGET_SFREQ))
    kernel = np.ones(2 * dilation + 1, dtype=np.int16)
    mask = np.convolve(candidates.astype(np.int16), kernel, mode="same") > 0
    cleaned = x.copy()
    good = ~mask
    if good.sum() >= 2 and mask.any():
        samples = np.arange(x.size)
        cleaned[mask] = np.interp(samples[mask], samples[good], x[good])
    return cleaned, {
        "spike_event_count": int(starts.sum()),
        "spike_event_rate_hz": float(starts.sum() / (x.size / cfc.TARGET_SFREQ)),
        "spike_mask_fraction": float(mask.mean()),
        "amplitude_mad_uv": mad,
        "derivative_mad_uv_per_sample": dmad,
    }


def compute_cfc_rows(
    metadata: dict[str, Any], window: cfc.WindowSpec, components: dict[str, Any], analysis_id: str,
    spike_mask_fraction: float = math.nan,
) -> list[dict[str, Any]]:
    section = cfc.window_slice(window)
    rows = convergence.compute_pac(metadata, window, components, section, SEED)
    rows.extend(convergence.compute_coherence(metadata, window, components, section, SEED))
    if len(rows) != FEATURES_PER_WINDOW:
        raise AssertionError(f"expected_{FEATURES_PER_WINDOW}_got_{len(rows)}")
    for row in rows:
        row.update({
            "analysis_id": analysis_id,
            "window_start_sec": window.start_sec,
            "window_end_sec": window.end_sec,
            "window_duration_sec": window.end_sec - window.start_sec,
            "spike_mask_fraction": spike_mask_fraction,
        })
    return rows


def band_power_rows(metadata: dict[str, Any], values: np.ndarray) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for window in PRIMARY_WINDOWS:
        segment = values[cfc.window_slice(window)]
        frequencies, psd = signal.welch(segment, fs=cfc.TARGET_SFREQ, window="hann", nperseg=1000, noverlap=500)
        for band, low, high in cfc.ALL_BANDS:
            mask = (frequencies >= low) & (frequencies <= high)
            power = float(np.trapz(psd[mask], frequencies[mask])) if mask.sum() >= 2 else math.nan
            rows.append({**metadata, "window_id": window.window_id, "band": band, "low_hz": low,
                         "high_hz": high, "log10_power_uv2": math.log10(max(power, np.finfo(float).tiny))})
    return rows


def harmonic_rows(metadata: dict[str, Any], values: np.ndarray, spike_info: dict[str, float]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for window in PRIMARY_WINDOWS:
        segment = values[cfc.window_slice(window)]
        frequencies, psd = signal.welch(segment, fs=cfc.TARGET_SFREQ, window="hann", nperseg=1000, noverlap=500)
        log_psd = 10.0 * np.log10(psd + np.finfo(float).tiny)
        for band, low, high in cfc.PHASE_BANDS:
            base_mask = (frequencies >= low) & (frequencies <= high)
            f0 = float(frequencies[np.flatnonzero(base_mask)[np.argmax(psd[base_mask])]])
            excesses: list[float] = []
            for multiple in range(2, int(200.0 // max(f0, 1e-6)) + 1):
                target = multiple * f0
                peak_mask = np.abs(frequencies - target) <= 0.5
                background = (np.abs(frequencies - target) >= 0.75) & (np.abs(frequencies - target) <= 2.0)
                if peak_mask.any() and background.any():
                    excesses.append(float(np.max(log_psd[peak_mask]) - np.median(log_psd[background])))
            rows.append({
                **metadata, "window_id": window.window_id, "phase_band": band, "dominant_frequency_hz": f0,
                "harmonics_tested": len(excesses), "harmonics_above_6db": int(np.sum(np.asarray(excesses) > 6.0)),
                "median_harmonic_excess_db": float(np.median(excesses)) if excesses else math.nan,
                "max_harmonic_excess_db": float(np.max(excesses)) if excesses else math.nan, **spike_info,
            })
    return rows


def process_record(record: dict[str, str], channels: list[dict[str, str]], output: Path) -> dict[str, Any]:
    started = time.perf_counter()
    stem = output / "raw_cache" / safe_name(record["dataset_id"]) / safe_name(record["patient_id"]) / safe_name(record["recording_id"])
    cfc_path = stem.with_name(stem.name + "_targeted_cfc.parquet")
    power_path = stem.with_name(stem.name + "_power.parquet")
    diagnostic_path = stem.with_name(stem.name + "_spike_harmonic.parquet")
    expected = len(channels) * 6 * FEATURES_PER_WINDOW
    if cfc_path.exists() and power_path.exists() and diagnostic_path.exists() and parquet_rows(cfc_path) == expected:
        return {"status": "skipped_valid", "rows": expected, "seconds": 0.0}
    references, source_sfreq = read_references(record, channels)
    cfc_rows: list[dict[str, Any]] = []
    power_rows: list[dict[str, Any]] = []
    diagnostic_rows: list[dict[str, Any]] = []
    for position, channel in enumerate(channels):
        base = {
            "dataset_id": record["dataset_id"], "patient_id": record["patient_id"],
            "recording_id": record["recording_id"], "implant_type": record["implant_type"],
            "onset_sec": float(record["onset_sec"]), "source_sampling_frequency_hz": source_sfreq,
            "channel_name": channel["channel_name_raw"], "channel_index_1based": int(channel["channel_index_1based"]),
            "soz_label": channel["soz_label"], "n_reference_channels": len(channels), "seed_id": SEED,
        }
        car = references["CAR"][position]
        median = references["median"][position]
        cleaned, spike_info = robust_spike_mask(car)
        for analysis_id, reference, values, windows, mask_fraction in (
            ("guard_window", "CAR", car, GUARD_WINDOWS, math.nan),
            ("alternative_reference", "median", median, PRIMARY_WINDOWS, math.nan),
            ("spike_masked", "CAR_spike_masked", cleaned, PRIMARY_WINDOWS, spike_info["spike_mask_fraction"]),
        ):
            metadata = {**base, "reference": reference}
            components = targeted_components(values)
            for window in windows:
                cfc_rows.extend(compute_cfc_rows(metadata, window, components, analysis_id, mask_fraction))
        power_rows.extend(band_power_rows({**base, "reference": "CAR"}, car))
        diagnostic_rows.extend(harmonic_rows({**base, "reference": "CAR"}, car, spike_info))
    cfc_frame = pd.DataFrame(cfc_rows, columns=CFC_FIELDS)
    if len(cfc_frame) != expected or not cfc_frame["finite_pass"].eq(1).all():
        raise AssertionError(f"invalid_targeted_rows:{len(cfc_frame)}:{expected}")
    numeric_columns = (
        "onset_sec", "source_sampling_frequency_hz", "channel_index_1based", "n_reference_channels",
        "window_start_sec", "window_end_sec", "window_duration_sec", "seed_id", "n_surrogates",
        "frequency_1", "frequency_2", "frequency_3", "observed_value", "surrogate_mean",
        "surrogate_std", "z_value", "empirical_p", "spectral_window_count", "finite_pass",
        "zero_surrogate_variance", "spike_mask_fraction",
    )
    for column in numeric_columns:
        cfc_frame[column] = pd.to_numeric(cfc_frame[column], errors="coerce")
    for column in set(CFC_FIELDS) - set(numeric_columns):
        cfc_frame[column] = cfc_frame[column].fillna("").astype(str)
    write_parquet_atomic(cfc_frame, cfc_path)
    write_parquet_atomic(pd.DataFrame(power_rows), power_path)
    write_parquet_atomic(pd.DataFrame(diagnostic_rows), diagnostic_path)
    return {"status": "complete", "rows": len(cfc_frame), "seconds": round(time.perf_counter() - started, 3)}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Raw-signal sensitivity checks for revised Experiment 3")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-records", type=int, default=0)
    parser.add_argument("--recording-id", default="")
    return parser.parse_args()


def repair_signal_paths(records: list[dict[str, str]]) -> None:
    lanzhou_files = {path.name: path for path in DATA_ROOT.rglob("LZ*_raw68s.edf")}
    for record in records:
        original = Path(record["signal_path"])
        if original.exists():
            continue
        if record["dataset_id"] == "Lanzhou":
            candidate = lanzhou_files.get(original.name)
        else:
            parts = str(record["signal_path"]).split("\\")
            dataset_index = next((i for i, part in enumerate(parts) if part.startswith("ds00") and part.endswith("-download")), None)
            candidate = DATA_ROOT.joinpath(*parts[dataset_index:]) if dataset_index is not None else None
        if candidate is None or not candidate.exists():
            raise FileNotFoundError(f"cannot_repair_signal_path:{record['recording_id']}:{record['signal_path']}")
        record["signal_path"] = str(candidate)


def main() -> None:
    if cfc.DEVICE is None or cfc.DEVICE.type != "cuda":
        raise RuntimeError("CUDA is required; use the xiaoluozai environment")
    convergence.COUNTS = (N_SURROGATES,)
    args = parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    seizures = cfc.preprocessing.read_csv(INPUT / "Seizures_post_QC.csv")
    channel_rows = cfc.preprocessing.read_csv(INPUT / "Channels_post_QC.csv")
    channels_by_record: dict[tuple[str, str], list[dict[str, str]]] = {}
    for row in channel_rows:
        channels_by_record.setdefault((row["dataset_id"], row["recording_id"]), []).append(row)
    records = sorted(seizures, key=lambda row: (row["dataset_id"], row["patient_id"], row["recording_id"]))
    repair_signal_paths(records)
    if args.recording_id:
        records = [row for row in records if row["recording_id"] == args.recording_id]
    if args.max_records:
        records = records[:args.max_records]
    (args.output / "frozen_config.json").write_text(json.dumps({
        "created": "2026-09-18", "records": len(records), "n_surrogates": N_SURROGATES,
        "families": ["PAC", "CFC_coherence"], "guard_windows": [[-12, -2], [2, 12]],
        "alternative_reference": "all-channel median reference", "spike_threshold_mad": 6.0,
        "spike_mask_dilation_ms_each_side": 100, "harmonic_peak_threshold_db": 6.0,
        "target_sampling_frequency_hz": cfc.TARGET_SFREQ, "device": str(cfc.DEVICE),
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    failures = 0
    for index, record in enumerate(records, 1):
        channels = sorted(channels_by_record[(record["dataset_id"], record["recording_id"])], key=lambda row: int(row["channel_index_1based"]))
        try:
            result = process_record(record, channels, args.output)
            if result["status"] != "skipped_valid":
                append_csv(args.output / "runtime_log.csv", {"index": index, "total": len(records), "dataset_id": record["dataset_id"],
                           "patient_id": record["patient_id"], "recording_id": record["recording_id"], **result, "error": ""})
            print(f"[{index}/{len(records)}] {record['dataset_id']} {record['recording_id']} {result['status']} rows={result['rows']} seconds={result['seconds']}", flush=True)
        except Exception as exc:
            failures += 1
            append_csv(args.output / "runtime_log.csv", {"index": index, "total": len(records), "dataset_id": record["dataset_id"],
                       "patient_id": record["patient_id"], "recording_id": record["recording_id"], "status": "failed",
                       "rows": 0, "seconds": 0, "error": f"{type(exc).__name__}: {exc}"})
            print(f"[{index}/{len(records)}] FAILED {record['recording_id']}: {exc}", flush=True)
    print(json.dumps({"records": len(records), "failures": failures, "output": str(args.output)}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
