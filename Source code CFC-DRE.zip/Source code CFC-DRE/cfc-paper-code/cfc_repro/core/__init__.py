"""Signal readers, estimators, and measure-specific surrogate construction."""

