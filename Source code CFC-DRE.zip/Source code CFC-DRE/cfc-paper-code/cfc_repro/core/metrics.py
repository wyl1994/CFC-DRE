"""Frozen 312-feature grids, buffered filtering, and the five CFC estimators.

Scientific definitions follow the frozen author analysis; see REPRODUCE.md.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import math
import sys
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Any, Callable

import numpy as np
from scipy import signal
from scipy.stats import rankdata

try:
    import torch
except ImportError:
    torch = None

from . import preprocessing


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "signal_content_qc_20260907" / "full" / "post_qc_manifests"
STANDARD_ROOT = ROOT
TARGET_SFREQ = 500.0
PADDING_SEC = 4.0
CONTEXT_SEC = 68.0
RNG_SEED = 20260907

PHASE_BANDS = (
    ("delta", 2.0, 4.0),
    ("theta", 4.0, 8.0),
    ("alpha", 8.0, 13.0),
    ("beta", 13.0, 30.0),
)
AMPLITUDE_BANDS = (
    ("low_gamma", 30.0, 55.0),
    ("high_gamma", 65.0, 100.0),
    ("ripple", 100.0, 150.0),
    # Legacy feature-ID key; report this band as Upper-ripple (150-200 Hz), not fast ripple.
    ("fast_ripple_low", 150.0, 200.0),
)
ALL_BANDS = PHASE_BANDS + AMPLITUDE_BANDS
PPC_FREQS = (2.0, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0, 12.0, 16.0, 20.0, 24.0, 30.0, 40.0, 50.0, 70.0, 90.0, 110.0)


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


# Preserve the helper module identities used by the frozen implementation.
PAC = load_module("window_pac_standard", STANDARD_ROOT / "pac.py")
BICOHERENCE = load_module("window_bicoherence_standard", STANDARD_ROOT / "bicoherence.py")
COHERENCE = load_module("window_coherence_standard", STANDARD_ROOT / "cfc_coherence.py")
DEVICE = torch.device("cuda" if torch is not None and torch.cuda.is_available() else "cpu") if torch is not None else None
RANK_POLICY = "ordinal_frozen"


@dataclass(frozen=True)
class WindowSpec:
    window_id: str
    window_role: str
    state: str
    start_sec: float
    end_sec: float


WINDOWS = (
    WindowSpec("pre_cumulative_10", "cumulative;temporal_late", "preictal", -10.0, 0.0),
    WindowSpec("pre_cumulative_20", "cumulative", "preictal", -20.0, 0.0),
    WindowSpec("pre_cumulative_30", "cumulative", "preictal", -30.0, 0.0),
    WindowSpec("post_cumulative_10", "cumulative;temporal_early", "ictal", 0.0, 10.0),
    WindowSpec("post_cumulative_20", "cumulative", "ictal", 0.0, 20.0),
    WindowSpec("post_cumulative_30", "cumulative", "ictal", 0.0, 30.0),
    WindowSpec("pre_temporal_early", "temporal_early", "preictal", -30.0, -20.0),
    WindowSpec("pre_temporal_middle", "temporal_middle", "preictal", -20.0, -10.0),
    WindowSpec("post_temporal_middle", "temporal_middle", "ictal", 10.0, 20.0),
    WindowSpec("post_temporal_late", "temporal_late", "ictal", 20.0, 30.0),
)

OUTPUT_FIELDS = (
    "dataset_id", "patient_id", "recording_id", "implant_type", "source_sampling_frequency_hz",
    "channel_name", "soz_label", "reference", "n_reference_channels", "window_id", "window_role",
    "state", "window_start_sec", "window_end_sec", "window_duration_sec", "cfc_family", "method",
    "feature_id", "frequency_1", "frequency_2", "frequency_3", "band_1", "band_2", "ratio_label",
    "observed_value", "surrogate_mean", "surrogate_std", "z_value", "empirical_p", "n_surrogates",
    "spectral_window_count", "finite_pass", "zero_surrogate_variance",
)


def stable_rng(*parts: Any) -> np.random.Generator:
    text = "|".join(str(part) for part in (RNG_SEED, *parts))
    seed = int.from_bytes(hashlib.sha256(text.encode("utf-8")).digest()[:8], "little")
    return np.random.default_rng(seed)


def generic_stats(observed: float, surrogates: np.ndarray) -> tuple[float, float, float, float]:
    """Return null mean, sample SD, standardized value, and one-sided null p.

    This per-contact surrogate probability is not a patient-level group test.
    Non-degenerate null variance is required by the formal pipeline.
    """
    values = np.asarray(surrogates, dtype=np.float64)
    values = values[np.isfinite(values)]
    if not np.isfinite(observed) or values.size == 0:
        return math.nan, math.nan, math.nan, math.nan
    mean = float(np.mean(values))
    std = float(np.std(values, ddof=1)) if values.size > 1 else 0.0
    z_value = float((observed - mean) / std) if std > 0 else 0.0
    p_value = float((np.sum(values >= observed) + 1) / (values.size + 1))
    return mean, std, z_value, p_value


def pac_metric_values_gpu(phase: np.ndarray, amplitude: np.ndarray, shifts: np.ndarray) -> dict[str, tuple[float, np.ndarray]]:
    if torch is None or DEVICE is None or DEVICE.type != "cuda":
        # Reuse the archived float64 CPU estimators with the identical shift array.
        helper = PAC.PhaseMetricHelper(np.asarray(phase, dtype=np.float64))
        metrics = {"tort_mi": helper.tort_mi, "mvl": helper.mvl, "glm_pac": helper.glm_r2}
        return {
            name: (float(metric(amplitude)), np.array([metric(np.roll(amplitude, int(s))) for s in shifts]))
            for name, metric in metrics.items()
        }
    phase64 = np.asarray(phase, dtype=np.float64)
    amplitude32 = np.asarray(amplitude, dtype=np.float32)
    n = phase64.size
    edges = np.linspace(-np.pi, np.pi, 19)
    bin_index = np.digitize(phase64, edges, right=False) - 1
    bin_index[bin_index == 18] = 17
    design = np.column_stack((np.ones_like(phase64), np.sin(phase64), np.cos(phase64)))
    q, _ = np.linalg.qr(design, mode="reduced")
    phase_t = torch.as_tensor(phase64, dtype=torch.float32, device=DEVICE)
    amplitude_t = torch.as_tensor(amplitude32, dtype=torch.float32, device=DEVICE)
    shifts_t = torch.as_tensor(shifts.astype(np.int64), dtype=torch.long, device=DEVICE)
    base_index = torch.arange(n, dtype=torch.long, device=DEVICE)
    shifted_index = (base_index.unsqueeze(0) - shifts_t.unsqueeze(1)) % n
    amplitudes = torch.cat((amplitude_t.unsqueeze(0), amplitude_t[shifted_index]), dim=0)
    bin_t = torch.as_tensor(bin_index, dtype=torch.long, device=DEVICE)
    counts = torch.bincount(bin_t, minlength=18).float().clamp_min_(1.0)
    sums = torch.zeros((amplitudes.shape[0], 18), dtype=torch.float32, device=DEVICE)
    sums.scatter_add_(1, bin_t.unsqueeze(0).expand(amplitudes.shape[0], n), amplitudes)
    means = sums / counts.unsqueeze(0)
    probabilities = means / means.sum(dim=1, keepdim=True).clamp_min(1e-12)
    probabilities = probabilities.clamp_min(1e-12)
    tort = (math.log(18) + (probabilities * torch.log(probabilities)).sum(dim=1)) / math.log(18)
    normalized = amplitudes / amplitudes.mean(dim=1, keepdim=True).clamp_min(1e-12)
    mvl_real = (normalized * torch.cos(phase_t).unsqueeze(0)).mean(dim=1)
    mvl_imag = (normalized * torch.sin(phase_t).unsqueeze(0)).mean(dim=1)
    mvl_values = torch.sqrt(mvl_real * mvl_real + mvl_imag * mvl_imag)
    q_t = torch.as_tensor(q, dtype=torch.float32, device=DEVICE)
    centered = amplitudes - amplitudes.mean(dim=1, keepdim=True)
    total_ss = (centered * centered).sum(dim=1).clamp_min(1e-12)
    coefficients = amplitudes @ q_t
    projection_ss = (coefficients * coefficients).sum(dim=1)
    residual_ss = (amplitudes * amplitudes).sum(dim=1) - projection_ss
    glm_values = torch.clamp(1.0 - residual_ss / total_ss, min=0.0)
    output = {}
    for method, tensor in (("tort_mi", tort), ("mvl", mvl_values), ("glm_pac", glm_values)):
        values = tensor.detach().cpu().numpy().astype(np.float64)
        output[method] = (float(values[0]), values[1:])
    return output


def ppc_values_gpu(low_component: np.ndarray, high_component: np.ndarray, shifts: np.ndarray) -> tuple[float, np.ndarray]:
    if torch is None or DEVICE is None or DEVICE.type != "cuda":
        observed = float(abs(np.mean(low_component * high_component)))
        surrogates = np.array([abs(np.mean(low_component * np.roll(high_component, int(s)))) for s in shifts])
        return observed, surrogates
    low_real = torch.as_tensor(low_component.real.astype(np.float32), device=DEVICE)
    low_imag = torch.as_tensor(low_component.imag.astype(np.float32), device=DEVICE)
    high_real = torch.as_tensor(high_component.real.astype(np.float32), device=DEVICE)
    high_imag = torch.as_tensor(high_component.imag.astype(np.float32), device=DEVICE)
    n = low_real.numel()
    shift_t = torch.as_tensor(shifts.astype(np.int64), dtype=torch.long, device=DEVICE)
    base = torch.arange(n, dtype=torch.long, device=DEVICE)
    indices = (base.unsqueeze(0) - shift_t.unsqueeze(1)) % n
    high_real_shifted = high_real[indices]
    high_imag_shifted = high_imag[indices]
    observed_real = torch.mean(low_real * high_real - low_imag * high_imag)
    observed_imag = torch.mean(low_real * high_imag + low_imag * high_real)
    surrogate_real = torch.mean(low_real.unsqueeze(0) * high_real_shifted - low_imag.unsqueeze(0) * high_imag_shifted, dim=1)
    surrogate_imag = torch.mean(low_real.unsqueeze(0) * high_imag_shifted + low_imag.unsqueeze(0) * high_real_shifted, dim=1)
    observed = torch.sqrt(observed_real * observed_real + observed_imag * observed_imag)
    surrogate = torch.sqrt(surrogate_real * surrogate_real + surrogate_imag * surrogate_imag)
    return float(observed.detach().cpu()), surrogate.detach().cpu().numpy().astype(np.float64)


def correlation_values_gpu(left: np.ndarray, right: np.ndarray, shifts: np.ndarray) -> tuple[float, np.ndarray]:
    if torch is None or DEVICE is None or DEVICE.type != "cuda":
        return float(np.mean(left * right)), np.array([np.mean(left * np.roll(right, int(s))) for s in shifts])
    left_t = torch.as_tensor(left.astype(np.float32), device=DEVICE)
    right_t = torch.as_tensor(right.astype(np.float32), device=DEVICE)
    n = left_t.numel()
    shift_t = torch.as_tensor(shifts.astype(np.int64), dtype=torch.long, device=DEVICE)
    base = torch.arange(n, dtype=torch.long, device=DEVICE)
    indices = (base.unsqueeze(0) - shift_t.unsqueeze(1)) % n
    observed = torch.mean(left_t * right_t)
    surrogate = torch.mean(left_t.unsqueeze(0) * right_t[indices], dim=1)
    return float(observed.detach().cpu()), surrogate.detach().cpu().numpy().astype(np.float64)


def circular_shifts(n_samples: int, sfreq: float, n_surrogates: int, *identity: Any) -> np.ndarray:
    minimum = max(1, int(round(sfreq)))
    maximum = n_samples - minimum
    if maximum <= minimum:
        raise ValueError(f"window_too_short_for_one_second_shift:{n_samples}:{sfreq}")
    return stable_rng(*identity, "circular_shifts").integers(minimum, maximum + 1, size=n_surrogates)


def rank_zscore(values: np.ndarray) -> np.ndarray:
    """Preserve the frozen ordinal ranks; average ranks are an explicit alternate mode."""
    if RANK_POLICY == "average":
        return COHERENCE.zscore(rankdata(values, method="average"))
    if RANK_POLICY != "ordinal_frozen":
        raise ValueError(f"Unknown AAC rank policy: {RANK_POLICY}")
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty(values.size, dtype=np.float64)
    ranks[order] = np.arange(1, values.size + 1, dtype=np.float64)
    return COHERENCE.zscore(ranks)


def preprocess_selected(values: np.ndarray, sfreq: float, mains_hz: float) -> np.ndarray:
    processed = np.asarray(values, dtype=np.float64)
    harmonic = mains_hz
    while harmonic <= 220.0 and harmonic < sfreq / 2.0 - 2.0:
        b, a = signal.iirnotch(harmonic, preprocessing.NOTCH_Q, fs=sfreq)
        processed = signal.filtfilt(b, a, processed, axis=-1)
        harmonic += mains_hz
    high = min(220.0, sfreq / 2.0 - 5.0)
    sos = signal.butter(4, [1.0, high], btype="bandpass", fs=sfreq, output="sos")
    processed = signal.sosfiltfilt(sos, processed, axis=-1)
    target_samples = int(round(CONTEXT_SEC * TARGET_SFREQ))
    if abs(sfreq - TARGET_SFREQ) > 1e-6 or processed.shape[-1] != target_samples:
        processed = signal.resample(processed, target_samples, axis=-1)
    return np.asarray(processed, dtype=np.float64)


def fft_bandpass_full(values: np.ndarray, low_hz: float, high_hz: float) -> np.ndarray:
    centered = np.asarray(values, dtype=np.float64) - np.mean(values)
    frequencies = np.fft.rfftfreq(centered.size, d=1.0 / TARGET_SFREQ)
    spectrum = np.fft.rfft(centered)
    spectrum *= (frequencies >= low_hz) & (frequencies <= high_hz)
    return np.fft.irfft(spectrum, n=centered.size)


def smooth_log_envelope(filtered: np.ndarray) -> np.ndarray:
    envelope = np.abs(signal.hilbert(filtered))
    log_envelope = np.log(envelope + np.finfo(np.float64).eps)
    width = int(round(0.2 * TARGET_SFREQ))
    return np.convolve(log_envelope, np.ones(width) / width, mode="same")


def build_components(values: np.ndarray) -> dict[str, Any]:
    """Extract phase/envelope components over the complete buffered contact.

    Window cropping is deferred to avoid treating each analysis window as a
    separate filtering interval. Input is already preprocessed at 500 Hz.
    """
    components: dict[str, Any] = {
        "pac_phase": {},
        "pac_amplitude": {},
        "ppc_phase": {},
        "envelope": {},
        "coherence_low": {},
    }
    filtered_bands: dict[str, np.ndarray] = {}
    for name, low, high in ALL_BANDS:
        filtered_bands[name] = fft_bandpass_full(values, low, high)
    for name, _low, _high in PHASE_BANDS:
        analytic = signal.hilbert(filtered_bands[name])
        components["pac_phase"][name] = np.angle(analytic)
        components["coherence_low"][name] = filtered_bands[name]
    for name, _low, _high in AMPLITUDE_BANDS:
        analytic = signal.hilbert(filtered_bands[name])
        components["pac_amplitude"][name] = np.abs(analytic)
    for name, _low, _high in ALL_BANDS:
        components["envelope"][name] = smooth_log_envelope(filtered_bands[name])
    for center in PPC_FREQS:
        filtered = fft_bandpass_full(values, center - 1.0, center + 1.0)
        components["ppc_phase"][center] = np.angle(signal.hilbert(filtered))
    return components


def build_ppc_pairs() -> list[dict[str, Any]]:
    pairs = []
    for low in PPC_FREQS:
        for high in PPC_FREQS:
            if high <= low:
                continue
            ratio = high / low
            fraction = Fraction(ratio).limit_denominator(12)
            m, n = int(fraction.numerator), int(fraction.denominator)
            error = abs(ratio - m / n) / ratio
            if max(m, n) <= 12 and error <= 0.015:
                pairs.append({"low": low, "high": high, "m": m, "n": n, "ratio": f"{n}:{m}"})
    if len(pairs) != 90:
        raise AssertionError(f"expected_90_ppc_pairs_got_{len(pairs)}")
    return pairs


PPC_PAIRS = build_ppc_pairs()
AAC_PAIRS = [(left, right) for index, (left, *_rest) in enumerate(ALL_BANDS) for right, *_ in ALL_BANDS[index + 1 :]]
BIC_TRIPLETS = BICOHERENCE.build_frequency_triplets()
COHERENCE_PAIRS = COHERENCE.build_band_pairs()
if len(AAC_PAIRS) != 28 or len(BIC_TRIPLETS) != 105 or len(COHERENCE_PAIRS) != 16:
    raise AssertionError((len(AAC_PAIRS), len(BIC_TRIPLETS), len(COHERENCE_PAIRS)))


def base_row(metadata: dict[str, Any], window: WindowSpec, family: str, method: str, feature_id: str) -> dict[str, Any]:
    return {
        **metadata,
        "window_id": window.window_id,
        "window_role": window.window_role,
        "state": window.state,
        "window_start_sec": window.start_sec,
        "window_end_sec": window.end_sec,
        "window_duration_sec": window.end_sec - window.start_sec,
        "cfc_family": family,
        "method": method,
        "feature_id": feature_id,
        "frequency_1": "",
        "frequency_2": "",
        "frequency_3": "",
        "band_1": "",
        "band_2": "",
        "ratio_label": "",
        "spectral_window_count": "",
    }


def finish_row(row: dict[str, Any], observed: float, stats_values: tuple[float, float, float, float], n_surrogates: int) -> dict[str, Any]:
    mean, std, z_value, p_value = stats_values
    row.update(
        {
            "observed_value": observed,
            "surrogate_mean": mean,
            "surrogate_std": std,
            "z_value": z_value,
            "empirical_p": p_value,
            "n_surrogates": n_surrogates,
            "finite_pass": int(all(np.isfinite(value) for value in (observed, mean, std, z_value, p_value))),
            "zero_surrogate_variance": int(np.isfinite(std) and std <= 0),
        }
    )
    return row


def compute_pac(metadata: dict[str, Any], window: WindowSpec, components: dict[str, Any], section: slice, n_surrogates: int) -> list[dict[str, Any]]:
    phases = {name: values[section] for name, values in components["pac_phase"].items()}
    amplitudes = {name: values[section] for name, values in components["pac_amplitude"].items()}
    n = next(iter(phases.values())).size
    shifts = circular_shifts(n, TARGET_SFREQ, n_surrogates, metadata["recording_id"], metadata["channel_name"], window.window_id, "pac")
    rows = []
    for phase_name, _phase_low, phase_high in PHASE_BANDS:
        helper = PAC.PhaseMetricHelper(phases[phase_name])
        metrics: dict[str, Callable[[np.ndarray], float]] = {
            "tort_mi": helper.tort_mi,
            "mvl": helper.mvl,
            "glm_pac": helper.glm_r2,
        }
        for amplitude_name, amplitude_low, _amplitude_high in AMPLITUDE_BANDS:
            if amplitude_low <= phase_high:
                continue
            amplitude = amplitudes[amplitude_name]
            if DEVICE is not None and DEVICE.type == "cuda":
                all_values = pac_metric_values_gpu(phases[phase_name], amplitude, shifts)
            else:
                all_values = {
                    method: (
                        float(metric(amplitude)),
                        np.array([metric(np.roll(amplitude, int(shift))) for shift in shifts]),
                    )
                    for method, metric in metrics.items()
                }
            for method, (observed, surrogates) in all_values.items():
                row = base_row(metadata, window, "PAC", method, f"PAC|{method}|{phase_name}|{amplitude_name}")
                row.update({"band_1": phase_name, "band_2": amplitude_name})
                rows.append(finish_row(row, observed, generic_stats(observed, surrogates), n_surrogates))
    return rows


def compute_ppc(metadata: dict[str, Any], window: WindowSpec, components: dict[str, Any], section: slice, n_surrogates: int) -> list[dict[str, Any]]:
    phases = {frequency: values[section] for frequency, values in components["ppc_phase"].items()}
    n_samples = next(iter(phases.values())).size
    shifts = circular_shifts(n_samples, TARGET_SFREQ, n_surrogates, metadata["recording_id"], metadata["channel_name"], window.window_id, "ppc")
    rows = []
    for pair in PPC_PAIRS:
        low_component = np.exp(1j * pair["m"] * phases[pair["low"]])
        high_component = np.exp(-1j * pair["n"] * phases[pair["high"]])
        if DEVICE is not None and DEVICE.type == "cuda":
            observed, surrogates = ppc_values_gpu(low_component, high_component, shifts)
        else:
            observed = float(abs(np.mean(low_component * high_component)))
            surrogates = np.array([abs(np.mean(low_component * np.roll(high_component, int(shift)))) for shift in shifts])
        feature = f"PPC|{pair['low']:g}|{pair['high']:g}|{pair['ratio']}"
        row = base_row(metadata, window, "PPC", "phase_locking_value", feature)
        row.update({"frequency_1": pair["low"], "frequency_2": pair["high"], "ratio_label": pair["ratio"]})
        rows.append(finish_row(row, observed, generic_stats(observed, surrogates), n_surrogates))
    return rows


def compute_aac(metadata: dict[str, Any], window: WindowSpec, components: dict[str, Any], section: slice, n_surrogates: int) -> list[dict[str, Any]]:
    step = int(round(TARGET_SFREQ / 50.0))
    envelopes = {name: COHERENCE.zscore(values[section][::step]) for name, values in components["envelope"].items()}
    ranks = {name: rank_zscore(values) for name, values in envelopes.items()}
    n_samples = next(iter(envelopes.values())).size
    shifts = circular_shifts(n_samples, 50.0, n_surrogates, metadata["recording_id"], metadata["channel_name"], window.window_id, "aac")
    rows = []
    for left_name, right_name in AAC_PAIRS:
        for method, left, right in (
            ("pearson", envelopes[left_name], envelopes[right_name]),
            ("spearman", ranks[left_name], ranks[right_name]),
        ):
            if DEVICE is not None and DEVICE.type == "cuda":
                observed, surrogates = correlation_values_gpu(left, right, shifts)
            else:
                observed = float(np.mean(left * right))
                surrogates = np.array([np.mean(left * np.roll(right, int(shift))) for shift in shifts])
            row = base_row(metadata, window, "AAC", method, f"AAC|{method}|{left_name}|{right_name}")
            row.update({"band_1": left_name, "band_2": right_name})
            rows.append(finish_row(row, observed, generic_stats(observed, surrogates), n_surrogates))
    return rows


def compute_bicoherence(metadata: dict[str, Any], window: WindowSpec, values: np.ndarray, n_surrogates: int) -> list[dict[str, Any]]:
    spectrum, frequencies, info = BICOHERENCE.compute_fft_windows(values, TARGET_SFREQ)
    n_windows = int(info["window_count"])
    permutation_rng = stable_rng(metadata["recording_id"], metadata["channel_name"], window.window_id, "bicoherence")
    permutations = np.vstack([permutation_rng.permutation(n_windows) for _ in range(n_surrogates)])
    index_cache: dict[float, int] = {}
    rows = []
    for triplet in BIC_TRIPLETS:
        f1, f2, f3 = triplet["f1_hz"], triplet["f2_hz"], triplet["f3_hz"]
        for frequency in (f1, f2, f3):
            if frequency not in index_cache:
                index_cache[frequency] = BICOHERENCE.nearest_frequency_index(frequencies, frequency)
        x1, x2, x3 = spectrum[:, index_cache[f1]], spectrum[:, index_cache[f2]], spectrum[:, index_cache[f3]]
        observed, product, denominator = BICOHERENCE.bicoherence_from_components(x1, x2, x3)
        statistics = BICOHERENCE.surrogate_stats(product, x3, denominator, observed, permutations)
        row = base_row(metadata, window, "Bicoherence", "squared_bicoherence", f"BIC|{f1:g}|{f2:g}|{f3:g}")
        row.update({"frequency_1": f1, "frequency_2": f2, "frequency_3": f3, "spectral_window_count": n_windows})
        rows.append(finish_row(row, observed, statistics, n_surrogates))
    return rows


def compute_coherence(metadata: dict[str, Any], window: WindowSpec, components: dict[str, Any], section: slice, n_surrogates: int) -> list[dict[str, Any]]:
    low_fft: dict[str, tuple[np.ndarray, np.ndarray, dict[str, Any]]] = {}
    high_fft: dict[str, np.ndarray] = {}
    for name, _low, _high in PHASE_BANDS:
        low_fft[name] = COHERENCE.welch_fft(COHERENCE.zscore(components["coherence_low"][name][section]), TARGET_SFREQ)
    for name, _low, _high in AMPLITUDE_BANDS:
        high_fft[name] = COHERENCE.welch_fft(COHERENCE.zscore(components["envelope"][name][section]), TARGET_SFREQ)[0]
    rows = []
    for pair in COHERENCE_PAIRS:
        low_name = pair["low_signal_band"]
        high_name = pair["high_amplitude_band"]
        low_spectrum, frequencies, info = low_fft[low_name]
        mask = (frequencies >= float(pair["low_signal_low_hz"])) & (frequencies <= float(pair["low_signal_high_hz"]))
        low_band = low_spectrum[:, mask]
        high_band = high_fft[high_name][:, mask]
        band_frequencies = frequencies[mask]
        observed, _mean_coherence, _peak_frequency = COHERENCE.coherence_peak_mean(low_band, high_band, band_frequencies)
        n_windows = int(info["welch_window_count"])
        permutation_rng = stable_rng(metadata["recording_id"], metadata["channel_name"], window.window_id, "coherence", low_name, high_name)
        permutations = np.vstack([permutation_rng.permutation(n_windows) for _ in range(n_surrogates)])
        statistics = COHERENCE.surrogate_stats(low_band, high_band, observed, permutations)
        row = base_row(metadata, window, "CFC_coherence", "coherence_peak", f"COH|{low_name}|{high_name}")
        row.update({"band_1": low_name, "band_2": high_name, "spectral_window_count": n_windows})
        rows.append(finish_row(row, observed, statistics, n_surrogates))
    return rows


def window_slice(window: WindowSpec) -> slice:
    start = int(round((window.start_sec + 30.0 + PADDING_SEC) * TARGET_SFREQ))
    end = int(round((window.end_sec + 30.0 + PADDING_SEC) * TARGET_SFREQ))
    return slice(start, end)


def compute_window_rows(metadata: dict[str, Any], window: WindowSpec, values: np.ndarray, components: dict[str, Any], n_surrogates: int) -> list[dict[str, Any]]:
    section = window_slice(window)
    raw_window = values[section]
    rows = []
    rows.extend(compute_pac(metadata, window, components, section, n_surrogates))
    rows.extend(compute_ppc(metadata, window, components, section, n_surrogates))
    rows.extend(compute_aac(metadata, window, components, section, n_surrogates))
    rows.extend(compute_bicoherence(metadata, window, raw_window, n_surrogates))
    rows.extend(compute_coherence(metadata, window, components, section, n_surrogates))
    if len(rows) != 312:
        counts: dict[str, int] = {}
        for row in rows:
            counts[row["cfc_family"]] = counts.get(row["cfc_family"], 0) + 1
        raise AssertionError(f"expected_312_features_got_{len(rows)}:{counts}")
    return rows


def select_records(seizures: list[dict[str, str]], channels_by_record: dict[tuple[str, str], list[dict[str, str]]], mode: str) -> list[dict[str, str]]:
    if mode == "full":
        return sorted(seizures, key=lambda row: (row["dataset_id"], row["patient_id"], row["recording_id"]))
    if mode == "patient_pilot":
        patients: dict[tuple[str, str], list[dict[str, str]]] = {}
        for row in seizures:
            patients.setdefault((row["dataset_id"], row["patient_id"]), []).append(row)
        selected = []
        for patient_key, candidates in sorted(patients.items()):
            patient_counts = [len(channels_by_record[(row["dataset_id"], row["recording_id"])]) for row in candidates]
            median_count = float(np.median(patient_counts))
            selected.append(
                min(
                    candidates,
                    key=lambda row: (
                        abs(len(channels_by_record[(row["dataset_id"], row["recording_id"])]) - median_count),
                        row["recording_id"],
                    ),
                )
            )
        return selected
    counts = {key: len(rows) for key, rows in channels_by_record.items()}
    pilot_records = preprocessing.select_pilot_records(seizures, counts)
    selected = []
    for dataset in ("ds003029", "ds004100", "Lanzhou"):
        candidates = [row for row in pilot_records if row["dataset_id"] == dataset]
        selected.append(candidates[0])
    return selected


def read_record(record: dict[str, str], all_channels: list[dict[str, str]], selected_channels: list[dict[str, str]]) -> tuple[dict[str, np.ndarray], float]:
    reader = preprocessing.make_reader(Path(record["signal_path"]), record["file_format"])
    try:
        arrays, frequencies = [], []
        for channel in all_channels:
            index = reader.resolve(channel["channel_name_raw"], int(channel["channel_index_1based"]))
            values, sfreq, unit = reader.read(index, float(record["onset_sec"]) - 34.0, CONTEXT_SEC)
            scale = preprocessing.unit_scale_to_uv(unit)
            arrays.append(values * (scale if scale is not None else 1.0))
            frequencies.append(sfreq)
    finally:
        reader.close()
    if max(frequencies) - min(frequencies) > 1e-6:
        raise ValueError("mixed_sampling_frequencies")
    sfreq = frequencies[0]
    source = signal.detrend(np.asarray(arrays, dtype=np.float64), axis=-1, type="linear")
    index_by_channel = {
        (row["recording_id"], row["channel_index_1based"]): index for index, row in enumerate(all_channels)
    }
    selected_indices = [index_by_channel[(row["recording_id"], row["channel_index_1based"])] for row in selected_channels]
    selected_source = source[selected_indices]
    references = {
        "CAR": selected_source - np.mean(source, axis=0, keepdims=True),
        "median": selected_source - np.median(source, axis=0, keepdims=True),
    }
    return {
        name: preprocess_selected(values, sfreq, preprocessing.LINE_HZ[record["dataset_id"]])
        for name, values in references.items()
    }, sfreq


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Multimetric CFC window-length and temporal-position experiment.")
    parser.add_argument("--mode", choices=("smoke", "patient_pilot", "full"), default="smoke")
    parser.add_argument("--channels-per-record", type=int, default=1)
    parser.add_argument("--n-surrogates", type=int, default=10)
    parser.add_argument("--output", default="")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output = Path(args.output) if args.output else ROOT / f"window_cfc_{args.mode}_20260907"
    output.mkdir(parents=True, exist_ok=True)
    seizures = preprocessing.read_csv(INPUT / "Seizures_post_QC.csv")
    channels = preprocessing.read_csv(INPUT / "Channels_post_QC.csv")
    channels_by_record: dict[tuple[str, str], list[dict[str, str]]] = {}
    for row in channels:
        channels_by_record.setdefault((row["dataset_id"], row["recording_id"]), []).append(row)
    records = select_records(seizures, channels_by_record, args.mode)
    partial = output / "window_cfc_results.partial.csv"
    failures: list[dict[str, Any]] = []
    selection: list[dict[str, Any]] = []
    with partial.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=OUTPUT_FIELDS, extrasaction="ignore")
        writer.writeheader()
        completed = 0
        for record_index, record in enumerate(records, start=1):
            all_channels = sorted(
                channels_by_record[(record["dataset_id"], record["recording_id"])],
                key=lambda row: int(row["channel_index_1based"]),
            )
            selected_channels = preprocessing.evenly_spaced(all_channels, args.channels_per_record)
            try:
                references, source_sfreq = read_record(record, all_channels, selected_channels)
                for channel_index, channel in enumerate(selected_channels):
                    selection.append(
                        {
                            "dataset_id": record["dataset_id"],
                            "patient_id": record["patient_id"],
                            "recording_id": record["recording_id"],
                            "channel_name": channel["channel_name_raw"],
                            "channel_index_1based": channel["channel_index_1based"],
                            "selection_rule": "deterministic_even_spacing_without_SOZ_label",
                            "n_reference_channels": len(all_channels),
                        }
                    )
                    for reference_name, reference_values in references.items():
                        metadata = {
                            "dataset_id": record["dataset_id"],
                            "patient_id": record["patient_id"],
                            "recording_id": record["recording_id"],
                            "implant_type": record["implant_type"],
                            "source_sampling_frequency_hz": source_sfreq,
                            "channel_name": channel["channel_name_raw"],
                            "soz_label": channel["soz_label"],
                            "reference": reference_name,
                            "n_reference_channels": len(all_channels),
                        }
                        components = build_components(reference_values[channel_index])
                        for window in WINDOWS:
                            rows = compute_window_rows(metadata, window, reference_values[channel_index], components, args.n_surrogates)
                            writer.writerows(rows)
                            completed += 1
                            stream.flush()
                print(f"[{record_index}/{len(records)}] {record['dataset_id']} {record['recording_id']} complete", flush=True)
            except Exception as exc:
                failures.append(
                    {
                        "dataset_id": record["dataset_id"],
                        "patient_id": record["patient_id"],
                        "recording_id": record["recording_id"],
                        "error_type": type(exc).__name__,
                        "error": str(exc),
                    }
                )
                print(f"[{record_index}/{len(records)}] FAILED {record['recording_id']}: {exc}", flush=True)
    final_path = output / "window_cfc_results.csv"
    partial.replace(final_path)
    preprocessing.write_csv(output / "window_cfc_selection.csv", selection)
    preprocessing.write_csv(output / "window_cfc_failures.csv", failures, fieldnames=["dataset_id", "patient_id", "recording_id", "error_type", "error"])
    config = {
        "mode": args.mode,
        "records": len(records),
        "channels_per_record": args.channels_per_record,
        "references": ["CAR", "median"],
        "windows": [window.__dict__ for window in WINDOWS],
        "unique_windows": len(WINDOWS),
        "features_per_channel_reference_window": {"PAC": 45, "PPC": 90, "AAC": 56, "Bicoherence": 105, "CFC_coherence": 16, "total": 312},
        "n_surrogates": args.n_surrogates,
        "surrogate_use": "smoke-test only" if args.mode == "smoke" else "formal",
        "target_sampling_frequency_hz": TARGET_SFREQ,
        "filter_padding_sec": PADDING_SEC,
        "random_seed": RNG_SEED,
        "compute_device": str(DEVICE) if DEVICE is not None else "cpu_without_torch",
        "completed_channel_reference_windows": completed,
        "failures": len(failures),
    }
    (output / "window_cfc_config.json").write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    print({"results": str(final_path), "completed": completed, "failures": len(failures)}, flush=True)


if __name__ == "__main__":
    main()
