"""Measure-specific surrogate distributions with SHA256-derived random streams.

Scientific definitions follow the frozen author analysis; see REPRODUCE.md.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import time
from pathlib import Path
from typing import Any

import numpy as np

from . import metrics as cfc


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "signal_content_qc_20260907" / "full" / "post_qc_manifests"
COUNTS = (100, 200, 500, 800, 1000)
N_SEEDS = 5
PATIENTS_PER_DATASET = 5
CHANNELS_PER_RECORD = 6
WINDOW_IDS = ("pre_cumulative_30", "post_cumulative_30")
BASE_SEED = 2026090700

OUTPUT_FIELDS = (
    "dataset_id", "patient_id", "recording_id", "channel_name", "channel_index_1based",
    "reference", "window_id", "state", "seed_id", "n_surrogates", "cfc_family", "method",
    "feature_id", "frequency_1", "frequency_2", "frequency_3", "band_1", "band_2",
    "ratio_label", "observed_value", "surrogate_mean", "surrogate_std", "z_value",
    "empirical_p", "spectral_window_count", "finite_pass", "zero_surrogate_variance",
)


def stable_rng(seed: int, *parts: Any) -> np.random.Generator:
    identity = "|".join(str(part) for part in (seed, *parts))
    value = int.from_bytes(hashlib.sha256(identity.encode("utf-8")).digest()[:8], "little")
    return np.random.default_rng(value)


def circular_shifts(n_samples: int, sfreq: float, seed: int, *identity: Any) -> np.ndarray:
    """Draw reproducible shifts excluding the one-second neighborhood of zero.

    SHA-derived identities make streams independent of Python's salted hash
    and recording scheduling. The same count prefixes share a null stream.
    """
    minimum = max(1, int(round(sfreq)))
    maximum = n_samples - minimum
    if maximum <= minimum:
        raise ValueError(f"window_too_short:{n_samples}:{sfreq}")
    return stable_rng(seed, *identity, "circular_shifts").integers(
        minimum, maximum + 1, size=max(COUNTS)
    )


def nested_rows(base: dict[str, Any], observed: float, surrogates: np.ndarray) -> list[dict[str, Any]]:
    """Standardize against each requested null prefix and retain QC flags.

    Uses sample SD (ddof=1) and add-one empirical upper-tail probabilities.
    Degenerate variance is flagged; formal processing rejects those features.
    """
    values = np.asarray(surrogates, dtype=np.float64)
    rows = []
    for count in COUNTS:
        subset = values[:count]
        finite = subset[np.isfinite(subset)]
        if not np.isfinite(observed) or finite.size != count:
            mean = std = z_value = p_value = math.nan
        else:
            mean = float(np.mean(finite))
            std = float(np.std(finite, ddof=1))
            z_value = float((observed - mean) / std) if std > 0 else 0.0
            p_value = float((np.sum(finite >= observed) + 1) / (count + 1))
        row = dict(base)
        row.update(
            {
                "n_surrogates": count,
                "observed_value": observed,
                "surrogate_mean": mean,
                "surrogate_std": std,
                "z_value": z_value,
                "empirical_p": p_value,
                "finite_pass": int(all(np.isfinite(v) for v in (observed, mean, std, z_value, p_value))),
                "zero_surrogate_variance": int(np.isfinite(std) and std <= 0),
            }
        )
        rows.append(row)
    return rows


def feature_base(metadata: dict[str, Any], window: cfc.WindowSpec, family: str, method: str, feature_id: str) -> dict[str, Any]:
    return {
        **metadata,
        "window_id": window.window_id,
        "state": window.state,
        "cfc_family": family,
        "method": method,
        "feature_id": feature_id,
        "frequency_1": "",
        "frequency_2": "",
        "frequency_3": "",
        "band_1": "",
        "band_2": "",
        "ratio_label": "",
        "spectral_window_count": "",
    }


def compute_pac(metadata: dict[str, Any], window: cfc.WindowSpec, components: dict[str, Any], section: slice, seed: int) -> list[dict[str, Any]]:
    phases = {name: values[section] for name, values in components["pac_phase"].items()}
    amplitudes = {name: values[section] for name, values in components["pac_amplitude"].items()}
    n_samples = next(iter(phases.values())).size
    shifts = circular_shifts(n_samples, cfc.TARGET_SFREQ, seed, metadata["recording_id"], metadata["channel_name"], window.window_id, "pac")
    rows = []
    for phase_name, _phase_low, phase_high in cfc.PHASE_BANDS:
        for amplitude_name, amplitude_low, _amplitude_high in cfc.AMPLITUDE_BANDS:
            if amplitude_low <= phase_high:
                continue
            metrics = cfc.pac_metric_values_gpu(phases[phase_name], amplitudes[amplitude_name], shifts)
            for method, (observed, surrogates) in metrics.items():
                base = feature_base(metadata, window, "PAC", method, f"PAC|{method}|{phase_name}|{amplitude_name}")
                base.update({"band_1": phase_name, "band_2": amplitude_name})
                rows.extend(nested_rows(base, observed, surrogates))
    return rows


def compute_ppc(metadata: dict[str, Any], window: cfc.WindowSpec, components: dict[str, Any], section: slice, seed: int) -> list[dict[str, Any]]:
    phases = {frequency: values[section] for frequency, values in components["ppc_phase"].items()}
    n_samples = next(iter(phases.values())).size
    shifts = circular_shifts(n_samples, cfc.TARGET_SFREQ, seed, metadata["recording_id"], metadata["channel_name"], window.window_id, "ppc")
    rows = []
    for pair in cfc.PPC_PAIRS:
        low_component = np.exp(1j * pair["m"] * phases[pair["low"]])
        high_component = np.exp(-1j * pair["n"] * phases[pair["high"]])
        observed, surrogates = cfc.ppc_values_gpu(low_component, high_component, shifts)
        base = feature_base(metadata, window, "PPC", "phase_locking_value", f"PPC|{pair['low']:g}|{pair['high']:g}|{pair['ratio']}")
        base.update({"frequency_1": pair["low"], "frequency_2": pair["high"], "ratio_label": pair["ratio"]})
        rows.extend(nested_rows(base, observed, surrogates))
    return rows


def compute_aac(metadata: dict[str, Any], window: cfc.WindowSpec, components: dict[str, Any], section: slice, seed: int) -> list[dict[str, Any]]:
    step = int(round(cfc.TARGET_SFREQ / 50.0))
    envelopes = {name: cfc.COHERENCE.zscore(values[section][::step]) for name, values in components["envelope"].items()}
    ranks = {name: cfc.rank_zscore(values) for name, values in envelopes.items()}
    n_samples = next(iter(envelopes.values())).size
    shifts = circular_shifts(n_samples, 50.0, seed, metadata["recording_id"], metadata["channel_name"], window.window_id, "aac")
    rows = []
    for left_name, right_name in cfc.AAC_PAIRS:
        for method, left, right in (
            ("pearson", envelopes[left_name], envelopes[right_name]),
            ("spearman", ranks[left_name], ranks[right_name]),
        ):
            observed, surrogates = cfc.correlation_values_gpu(left, right, shifts)
            base = feature_base(metadata, window, "AAC", method, f"AAC|{method}|{left_name}|{right_name}")
            base.update({"band_1": left_name, "band_2": right_name})
            rows.extend(nested_rows(base, observed, surrogates))
    return rows


def compute_bicoherence(metadata: dict[str, Any], window: cfc.WindowSpec, values: np.ndarray, seed: int) -> list[dict[str, Any]]:
    spectrum, frequencies, info = cfc.BICOHERENCE.compute_fft_windows(values, cfc.TARGET_SFREQ)
    n_windows = int(info["window_count"])
    rng = stable_rng(seed, metadata["recording_id"], metadata["channel_name"], window.window_id, "bicoherence")
    permutations = np.vstack([rng.permutation(n_windows) for _ in range(max(COUNTS))])
    index_cache: dict[float, int] = {}
    rows = []
    for triplet in cfc.BIC_TRIPLETS:
        f1, f2, f3 = triplet["f1_hz"], triplet["f2_hz"], triplet["f3_hz"]
        for frequency in (f1, f2, f3):
            if frequency not in index_cache:
                index_cache[frequency] = cfc.BICOHERENCE.nearest_frequency_index(frequencies, frequency)
        x1, x2, x3 = spectrum[:, index_cache[f1]], spectrum[:, index_cache[f2]], spectrum[:, index_cache[f3]]
        observed, product, denominator = cfc.BICOHERENCE.bicoherence_from_components(x1, x2, x3)
        permuted_x3 = x3[permutations]
        numerators = np.abs(np.mean(product[np.newaxis, :] * np.conj(permuted_x3), axis=1)) ** 2
        surrogates = np.clip(numerators / denominator, 0.0, 1.0)
        base = feature_base(metadata, window, "Bicoherence", "squared_bicoherence", f"BIC|{f1:g}|{f2:g}|{f3:g}")
        base.update({"frequency_1": f1, "frequency_2": f2, "frequency_3": f3, "spectral_window_count": n_windows})
        rows.extend(nested_rows(base, observed, surrogates))
    return rows


def compute_coherence(metadata: dict[str, Any], window: cfc.WindowSpec, components: dict[str, Any], section: slice, seed: int) -> list[dict[str, Any]]:
    low_fft = {
        name: cfc.COHERENCE.welch_fft(cfc.COHERENCE.zscore(components["coherence_low"][name][section]), cfc.TARGET_SFREQ)
        for name, _low, _high in cfc.PHASE_BANDS
    }
    high_fft = {
        name: cfc.COHERENCE.welch_fft(cfc.COHERENCE.zscore(components["envelope"][name][section]), cfc.TARGET_SFREQ)[0]
        for name, _low, _high in cfc.AMPLITUDE_BANDS
    }
    rows = []
    for pair in cfc.COHERENCE_PAIRS:
        low_name, high_name = pair["low_signal_band"], pair["high_amplitude_band"]
        low_spectrum, frequencies, info = low_fft[low_name]
        mask = (frequencies >= float(pair["low_signal_low_hz"])) & (frequencies <= float(pair["low_signal_high_hz"]))
        low_band, high_band = low_spectrum[:, mask], high_fft[high_name][:, mask]
        observed, _mean_value, _peak_frequency = cfc.COHERENCE.coherence_peak_mean(low_band, high_band, frequencies[mask])
        n_windows = int(info["welch_window_count"])
        rng = stable_rng(seed, metadata["recording_id"], metadata["channel_name"], window.window_id, "coherence", low_name, high_name)
        permutations = np.vstack([rng.permutation(n_windows) for _ in range(max(COUNTS))])
        permuted_high = high_band[permutations]
        pxx = np.mean(np.abs(low_band) ** 2, axis=0)
        pyy = np.mean(np.abs(permuted_high) ** 2, axis=1)
        pxy = np.mean(low_band[np.newaxis, :, :] * np.conj(permuted_high), axis=1)
        denominator = pxx[np.newaxis, :] * pyy
        coherence = np.full_like(denominator, np.nan, dtype=np.float64)
        valid = denominator > 0
        coherence[valid] = np.clip(np.abs(pxy[valid]) ** 2 / denominator[valid], 0.0, 1.0)
        surrogates = np.nanmax(coherence, axis=1)
        base = feature_base(metadata, window, "CFC_coherence", "coherence_peak", f"COH|{low_name}|{high_name}")
        base.update({"band_1": low_name, "band_2": high_name, "spectral_window_count": n_windows})
        rows.extend(nested_rows(base, observed, surrogates))
    return rows


def compute_window(metadata: dict[str, Any], window: cfc.WindowSpec, values: np.ndarray, components: dict[str, Any], seed: int) -> list[dict[str, Any]]:
    """Return 312 measure-specific feature rows per requested surrogate count.

    Metadata, window identity and seed determine the archived random streams;
    arbitrary replacement IDs do not reproduce the original subject's stream.
    """
    section = cfc.window_slice(window)
    raw = values[section]
    rows = []
    rows.extend(compute_pac(metadata, window, components, section, seed))
    rows.extend(compute_ppc(metadata, window, components, section, seed))
    rows.extend(compute_aac(metadata, window, components, section, seed))
    rows.extend(compute_bicoherence(metadata, window, raw, seed))
    rows.extend(compute_coherence(metadata, window, components, section, seed))
    expected = 312 * len(COUNTS)
    if len(rows) != expected:
        raise AssertionError(f"expected_{expected}_rows_got_{len(rows)}")
    return rows


def evenly_select(rows: list[dict[str, str]], count: int) -> list[dict[str, str]]:
    if len(rows) <= count:
        return rows
    indices = sorted({int(round(value)) for value in np.linspace(0, len(rows) - 1, count)})
    return [rows[index] for index in indices]


def select_records(seizures: list[dict[str, str]], channels_by_record: dict[tuple[str, str], list[dict[str, str]]]) -> list[dict[str, str]]:
    patient_records = cfc.select_records(seizures, channels_by_record, "patient_pilot")
    selected = []
    for dataset in ("Lanzhou", "ds003029", "ds004100"):
        candidates = sorted((row for row in patient_records if row["dataset_id"] == dataset), key=lambda row: row["patient_id"])
        selected.extend(evenly_select(candidates, PATIENTS_PER_DATASET))
    return selected


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Nested surrogate-count convergence experiment.")
    parser.add_argument("--output", default=str(ROOT / "surrogate_convergence_20260907"))
    return parser.parse_args()


def main() -> None:
    if cfc.DEVICE is None or cfc.DEVICE.type != "cuda":
        raise RuntimeError("This experiment requires the xiaoluozai CUDA environment")
    args = parse_args()
    output = Path(args.output)
    shards = output / "shards"
    shards.mkdir(parents=True, exist_ok=True)
    seizures = cfc.preprocessing.read_csv(INPUT / "Seizures_post_QC.csv")
    channels = cfc.preprocessing.read_csv(INPUT / "Channels_post_QC.csv")
    channels_by_record: dict[tuple[str, str], list[dict[str, str]]] = {}
    for row in channels:
        channels_by_record.setdefault((row["dataset_id"], row["recording_id"]), []).append(row)
    records = select_records(seizures, channels_by_record)
    windows = [window for window in cfc.WINDOWS if window.window_id in WINDOW_IDS]
    failures = []
    selections = []
    started = time.perf_counter()
    for record_number, record in enumerate(records, start=1):
        shard = shards / f"{record_number:02d}_{record['dataset_id']}_{record['patient_id']}.csv"
        if shard.exists():
            print(f"[{record_number}/{len(records)}] SKIP {record['patient_id']}", flush=True)
            continue
        all_channels = sorted(
            channels_by_record[(record["dataset_id"], record["recording_id"])],
            key=lambda row: int(row["channel_index_1based"]),
        )
        selected_channels = cfc.preprocessing.evenly_spaced(all_channels, CHANNELS_PER_RECORD)
        temporary = shard.with_suffix(".partial.csv")
        try:
            references, _sfreq = cfc.read_record(record, all_channels, selected_channels)
            with temporary.open("w", encoding="utf-8-sig", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=OUTPUT_FIELDS, extrasaction="ignore")
                writer.writeheader()
                for channel_index, channel in enumerate(selected_channels):
                    metadata = {
                        "dataset_id": record["dataset_id"],
                        "patient_id": record["patient_id"],
                        "recording_id": record["recording_id"],
                        "channel_name": channel["channel_name_raw"],
                        "channel_index_1based": channel["channel_index_1based"],
                        "reference": "CAR",
                    }
                    selections.append({**metadata, "selection_rule": "deterministic_even_spacing"})
                    values = references["CAR"][channel_index]
                    components = cfc.build_components(values)
                    for seed_id in range(1, N_SEEDS + 1):
                        seed = BASE_SEED + seed_id
                        metadata["seed_id"] = seed_id
                        for window in windows:
                            writer.writerows(compute_window(metadata, window, values, components, seed))
                            stream.flush()
            temporary.replace(shard)
            print(f"[{record_number}/{len(records)}] {record['dataset_id']} {record['patient_id']} complete", flush=True)
        except Exception as exc:
            failures.append({"dataset_id": record["dataset_id"], "patient_id": record["patient_id"], "recording_id": record["recording_id"], "error_type": type(exc).__name__, "error": str(exc)})
            print(f"[{record_number}/{len(records)}] FAILED {record['patient_id']}: {exc}", flush=True)
    cfc.preprocessing.write_csv(output / "surrogate_selection.csv", selections)
    cfc.preprocessing.write_csv(output / "surrogate_failures.csv", failures, fieldnames=["dataset_id", "patient_id", "recording_id", "error_type", "error"])
    config = {
        "datasets": ["Lanzhou", "ds003029", "ds004100"],
        "patients_per_dataset": PATIENTS_PER_DATASET,
        "records": len(records),
        "channels_per_record": CHANNELS_PER_RECORD,
        "windows": list(WINDOW_IDS),
        "reference": "CAR",
        "surrogate_counts": list(COUNTS),
        "independent_seeds": N_SEEDS,
        "maximum_surrogates_generated_once_per_seed": max(COUNTS),
        "features_per_map": 312,
        "device": str(cfc.DEVICE),
        "elapsed_seconds": time.perf_counter() - started,
        "failures": len(failures),
    }
    (output / "surrogate_config.json").write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    print({"output": str(output), "records": len(records), "failures": len(failures), "elapsed_seconds": config["elapsed_seconds"]}, flush=True)


if __name__ == "__main__":
    main()
