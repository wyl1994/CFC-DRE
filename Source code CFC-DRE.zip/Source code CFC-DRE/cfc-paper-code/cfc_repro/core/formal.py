"""Archived all-contact computation and typed Parquet writer; use the portable CLI.

Scientific definitions follow the frozen author analysis; see REPRODUCE.md.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import shutil
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from scipy import signal

from . import metrics as cfc
from . import surrogates as convergence


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "signal_content_qc_20260907" / "full" / "post_qc_manifests"
N_SURROGATES = 1000
FORMAL_SEED = 20260908
WINDOW_IDS = ("pre_cumulative_30", "post_cumulative_30")
FEATURES_PER_MAP = 312
WRITE_CHANNEL_BATCH = 8

FLOAT_FIELDS = (
    "onset_sec", "source_sampling_frequency_hz", "window_start_sec", "window_end_sec",
    "window_duration_sec", "frequency_1", "frequency_2", "frequency_3", "observed_value",
    "surrogate_mean", "surrogate_std", "z_value", "empirical_p", "spectral_window_count",
)
INTEGER_FIELDS = (
    "channel_index_1based", "n_reference_channels", "seed_id", "n_surrogates",
    "finite_pass", "zero_surrogate_variance",
)

OUTPUT_FIELDS = (
    "dataset_id", "patient_id", "recording_id", "implant_type", "onset_sec",
    "source_sampling_frequency_hz", "channel_name", "channel_index_1based", "soz_label",
    "reference", "n_reference_channels", "window_id", "state", "window_start_sec",
    "window_end_sec", "window_duration_sec", "seed_id", "n_surrogates", "cfc_family",
    "method", "feature_id", "frequency_1", "frequency_2", "frequency_3", "band_1",
    "band_2", "ratio_label", "observed_value", "surrogate_mean", "surrogate_std",
    "z_value", "empirical_p", "spectral_window_count", "finite_pass",
    "zero_surrogate_variance",
)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_name(value: str) -> str:
    return "".join(character if character.isalnum() or character in "-_" else "_" for character in value)


def read_record_car(
    record: dict[str, str], all_channels: list[dict[str, str]]
) -> tuple[np.ndarray, float]:
    """Return all-retained-contact buffered signals in microvolts and source Hz.

    Units and contact identities are checked before CAR. Display/demo contact
    selection must happen after this function, never before referencing.
    """
    reader = cfc.preprocessing.make_reader(Path(record["signal_path"]), record["file_format"])
    try:
        arrays = []
        frequencies = []
        for channel in all_channels:
            index = reader.resolve(channel["channel_name_raw"], int(channel["channel_index_1based"]))
            values, sfreq, unit = reader.read(index, float(record["onset_sec"]) - 34.0, cfc.CONTEXT_SEC)
            scale = cfc.preprocessing.unit_scale_to_uv(unit)
            if scale is None:
                raise ValueError(f"Unknown signal unit {unit!r}; correct source metadata before computing")
            arrays.append(values * scale)
            frequencies.append(sfreq)
    finally:
        reader.close()
    if not frequencies or max(frequencies) - min(frequencies) > 1e-6:
        raise ValueError("missing_or_mixed_sampling_frequencies")
    source = signal.detrend(np.asarray(arrays, dtype=np.float64), axis=-1, type="linear")
    referenced = source - np.mean(source, axis=0, keepdims=True)
    return cfc.preprocess_selected(referenced, frequencies[0], cfc.preprocessing.LINE_HZ[record["dataset_id"]]), frequencies[0]


def expected_rows(n_channels: int) -> int:
    return n_channels * len(WINDOW_IDS) * FEATURES_PER_MAP


def parquet_rows(path: Path) -> int:
    try:
        return int(pq.ParquetFile(path).metadata.num_rows)
    except Exception:
        return -1


def append_runtime(path: Path, row: dict[str, Any]) -> None:
    exists = path.exists()
    with path.open("a", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(row))
        if not exists:
            writer.writeheader()
        writer.writerow(row)


def write_batch(writer: pq.ParquetWriter | None, rows: list[dict[str, Any]], path: Path) -> pq.ParquetWriter:
    frame = pd.DataFrame(rows, columns=OUTPUT_FIELDS)
    for column in FLOAT_FIELDS:
        frame[column] = pd.to_numeric(frame[column], errors="coerce").astype("float64")
    for column in INTEGER_FIELDS:
        frame[column] = pd.to_numeric(frame[column], errors="raise").astype("int64")
    for column in set(OUTPUT_FIELDS) - set(FLOAT_FIELDS) - set(INTEGER_FIELDS):
        frame[column] = frame[column].astype("string")
    table = pa.Table.from_pandas(frame, preserve_index=False)
    if writer is None:
        writer = pq.ParquetWriter(path, table.schema, compression="zstd", compression_level=3)
    writer.write_table(table)
    return writer


def validate_rows(rows: list[dict[str, Any]]) -> None:
    if len(rows) != FEATURES_PER_MAP:
        raise AssertionError(f"expected_{FEATURES_PER_MAP}_features_got_{len(rows)}")
    if any(int(row["finite_pass"]) != 1 for row in rows):
        raise ValueError("nonfinite_standardized_result")
    if any(int(row["zero_surrogate_variance"]) != 0 for row in rows):
        raise ValueError("zero_surrogate_variance")
    lower = 1.0 / (N_SURROGATES + 1)
    if any(not lower - 1e-12 <= float(row["empirical_p"]) <= 1.0 for row in rows):
        raise ValueError("empirical_p_out_of_range")


def process_record(
    record: dict[str, str],
    channels: list[dict[str, str]],
    windows: list[cfc.WindowSpec],
    final_path: Path,
) -> dict[str, Any]:
    started = time.perf_counter()
    temporary = final_path.with_suffix(".partial.parquet")
    temporary.parent.mkdir(parents=True, exist_ok=True)
    if temporary.exists():
        temporary.unlink()
    values_by_channel, source_sfreq = read_record_car(record, channels)
    writer: pq.ParquetWriter | None = None
    pending: list[dict[str, Any]] = []
    written_rows = 0
    try:
        for channel_position, channel in enumerate(channels):
            values = values_by_channel[channel_position]
            components = cfc.build_components(values)
            metadata = {
                "dataset_id": record["dataset_id"],
                "patient_id": record["patient_id"],
                "recording_id": record["recording_id"],
                "implant_type": record["implant_type"],
                "onset_sec": float(record["onset_sec"]),
                "source_sampling_frequency_hz": source_sfreq,
                "channel_name": channel["channel_name_raw"],
                "channel_index_1based": int(channel["channel_index_1based"]),
                "soz_label": channel["soz_label"],
                "reference": "CAR",
                "n_reference_channels": len(channels),
                "seed_id": FORMAL_SEED,
            }
            for window in windows:
                rows = convergence.compute_window(metadata, window, values, components, FORMAL_SEED)
                for row in rows:
                    row.update(
                        {
                            "window_start_sec": window.start_sec,
                            "window_end_sec": window.end_sec,
                            "window_duration_sec": window.end_sec - window.start_sec,
                        }
                    )
                validate_rows(rows)
                pending.extend(rows)
            if len(pending) >= WRITE_CHANNEL_BATCH * len(windows) * FEATURES_PER_MAP:
                writer = write_batch(writer, pending, temporary)
                written_rows += len(pending)
                pending.clear()
        if pending:
            writer = write_batch(writer, pending, temporary)
            written_rows += len(pending)
            pending.clear()
    finally:
        if writer is not None:
            writer.close()
    expected = expected_rows(len(channels))
    actual = parquet_rows(temporary)
    if written_rows != expected or actual != expected:
        raise AssertionError(f"row_count_mismatch:written={written_rows}:parquet={actual}:expected={expected}")
    temporary.replace(final_path)
    return {
        "dataset_id": record["dataset_id"],
        "patient_id": record["patient_id"],
        "recording_id": record["recording_id"],
        "status": "complete",
        "channels": len(channels),
        "rows": actual,
        "elapsed_seconds": round(time.perf_counter() - started, 3),
        "output_bytes": final_path.stat().st_size,
        "error_type": "",
        "error": "",
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Formal all-channel five-family CFC standardization.")
    parser.add_argument("--output", default=str(ROOT / "formal_cfc_standardization_20260908"))
    parser.add_argument("--max-records", type=int, default=0)
    parser.add_argument("--recording-id", default="")
    return parser.parse_args()


def main() -> None:
    if cfc.DEVICE is None or cfc.DEVICE.type != "cuda":
        raise RuntimeError("CUDA is required; run in the xiaoluozai environment")
    convergence.COUNTS = (N_SURROGATES,)
    args = parse_args()
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    runtime_path = output / "runtime_log.csv"
    failures_path = output / "failure_manifest.csv"
    seizure_path = INPUT / "Seizures_post_QC.csv"
    channel_path = INPUT / "Channels_post_QC.csv"
    seizures = cfc.preprocessing.read_csv(seizure_path)
    channel_rows = cfc.preprocessing.read_csv(channel_path)
    channels_by_record: dict[tuple[str, str], list[dict[str, str]]] = {}
    for row in channel_rows:
        channels_by_record.setdefault((row["dataset_id"], row["recording_id"]), []).append(row)
    records = sorted(seizures, key=lambda row: (row["dataset_id"], row["patient_id"], row["recording_id"]))
    if args.recording_id:
        records = [row for row in records if row["recording_id"] == args.recording_id]
    if args.max_records > 0:
        records = records[: args.max_records]
    windows = [window for window in cfc.WINDOWS if window.window_id in WINDOW_IDS]

    if not (output / "frozen_seizure_manifest.csv").exists():
        shutil.copy2(seizure_path, output / "frozen_seizure_manifest.csv")
        shutil.copy2(channel_path, output / "frozen_channel_manifest.csv")
    config = {
        "created_date": "2026-09-08",
        "input_seizure_manifest_sha256": file_sha256(seizure_path),
        "input_channel_manifest_sha256": file_sha256(channel_path),
        "records_in_this_run": len(records),
        "all_manifest_records": len(seizures),
        "all_manifest_channel_record_rows": len(channel_rows),
        "reference": "CAR",
        "windows": list(WINDOW_IDS),
        "target_sampling_frequency_hz": cfc.TARGET_SFREQ,
        "filter_padding_sec": cfc.PADDING_SEC,
        "n_surrogates": N_SURROGATES,
        "formal_seed": FORMAL_SEED,
        "features_per_channel_window": FEATURES_PER_MAP,
        "expected_full_rows": len(channel_rows) * len(WINDOW_IDS) * FEATURES_PER_MAP,
        "device": str(cfc.DEVICE),
        "result_format": "parquet_zstd_per_recording",
    }
    (output / "frozen_config.json").write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")

    failures = []
    started = time.perf_counter()
    for index, record in enumerate(records, start=1):
        channels = sorted(
            channels_by_record[(record["dataset_id"], record["recording_id"])],
            key=lambda row: int(row["channel_index_1based"]),
        )
        final_path = output / "shards" / safe_name(record["dataset_id"]) / safe_name(record["patient_id"]) / f"{safe_name(record['recording_id'])}.parquet"
        expected = expected_rows(len(channels))
        if final_path.exists() and parquet_rows(final_path) == expected:
            print(f"[{index}/{len(records)}] SKIP {record['recording_id']} rows={expected}", flush=True)
            continue
        try:
            result = process_record(record, channels, windows, final_path)
            append_runtime(runtime_path, result)
            print(
                f"[{index}/{len(records)}] {record['dataset_id']} {record['recording_id']} "
                f"channels={result['channels']} rows={result['rows']} seconds={result['elapsed_seconds']}",
                flush=True,
            )
        except Exception as exc:
            failure = {
                "dataset_id": record["dataset_id"],
                "patient_id": record["patient_id"],
                "recording_id": record["recording_id"],
                "status": "failed",
                "channels": len(channels),
                "rows": 0,
                "elapsed_seconds": "",
                "output_bytes": "",
                "error_type": type(exc).__name__,
                "error": str(exc),
            }
            failures.append(failure)
            append_runtime(runtime_path, failure)
            print(f"[{index}/{len(records)}] FAILED {record['recording_id']}: {exc}", flush=True)
    cfc.preprocessing.write_csv(
        failures_path,
        failures,
        fieldnames=["dataset_id", "patient_id", "recording_id", "status", "channels", "rows", "elapsed_seconds", "output_bytes", "error_type", "error"],
    )
    print(
        {
            "output": str(output),
            "records_requested": len(records),
            "failures": len(failures),
            "elapsed_seconds": round(time.perf_counter() - started, 3),
        },
        flush=True,
    )


if __name__ == "__main__":
    main()
