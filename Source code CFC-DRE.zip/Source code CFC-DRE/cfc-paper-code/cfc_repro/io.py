"""Manifest validation and reproducibility metadata shared by the public commands."""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
import platform
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd


def sha256(path: Path) -> str:
    """Hash bytes without loading a potentially large signal file into memory."""
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def read_manifests(seizures: Path, channels: Path, data_root: Path | None = None):
    """Read explicit retained-contact lists; never infer clinical labels from signals."""
    records = pd.read_csv(seizures, dtype=str, keep_default_na=False)
    contacts = pd.read_csv(channels, dtype=str, keep_default_na=False)
    needed = {"dataset_id", "patient_id", "recording_id", "signal_path", "file_format", "implant_type", "onset_sec"}
    required_contacts = {"dataset_id", "recording_id", "channel_name_raw", "channel_index_1based", "soz_label"}
    for frame, required, name in ((records, needed, "seizures"), (contacts, required_contacts, "channels")):
        missing = required - set(frame.columns)
        if missing:
            raise ValueError(f"Missing {name} fields: {sorted(missing)}; see REPRODUCE.md")
    if records.duplicated(["dataset_id", "recording_id"]).any():
        raise ValueError("Duplicate recordings in seizure manifest")
    if contacts.duplicated(["dataset_id", "recording_id", "channel_index_1based"]).any():
        raise ValueError("Duplicate retained contact indices")
    indices = pd.to_numeric(contacts.channel_index_1based, errors="raise")
    if (indices.lt(1) | indices.mod(1).ne(0) | ~np.isfinite(indices)).any():
        raise ValueError("Contact indices must be positive 1-based integers")
    if records[list(needed)].eq("").any().any() or contacts[list(required_contacts)].eq("").any().any():
        raise ValueError("Required manifest fields cannot be empty")
    if not set(contacts.soz_label) <= {"SOZ", "NSOZ"}:
        raise ValueError("Retained contacts require SOZ or NSOZ labels")
    base = data_root.resolve() if data_root else seizures.resolve().parent
    rows = records.sort_values(["dataset_id", "patient_id", "recording_id"]).to_dict("records")
    groups = {}
    for key, frame in contacts.groupby(["dataset_id", "recording_id"], sort=True):
        frame = frame.assign(_index=pd.to_numeric(frame.channel_index_1based, errors="raise"))
        groups[key] = frame.sort_values("_index").drop(columns="_index").to_dict("records")
    record_keys = {(r["dataset_id"], r["recording_id"]) for r in rows}
    if set(groups) != record_keys:
        raise ValueError("Seizure and contact manifests must contain exactly the same recordings")
    for row in rows:
        signal = Path(row["signal_path"])
        if not signal.is_absolute():
            signal = base / signal
            original = Path(row["signal_path"])
            if (not signal.is_file() and original.parts[0] == row["dataset_id"]
                    and base.name in (row["dataset_id"], row["dataset_id"] + "-download")):
                signal = base.joinpath(*original.parts[1:])
        if not signal.is_file():
            raise FileNotFoundError(f"Missing recording: {signal}; set --data-root to your downloaded data folder")
        row["signal_path"] = str(signal.resolve())
        if row["dataset_id"] not in ("ds003029", "ds004100", "Lanzhou"):
            raise ValueError(f"Unsupported cohort: {row['dataset_id']}")
        if row["file_format"].upper() not in ("EDF", "VHDR"):
            raise ValueError("Only EDF and BrainVision VHDR files are supported")
        if not np.isfinite(float(row["onset_sec"])) or float(row["onset_sec"]) < 34:
            raise ValueError("Each recording must provide 34 seconds before onset, including padding")
        labels = {c["soz_label"] for c in groups[(row["dataset_id"], row["recording_id"]) ]}
        if labels != {"SOZ", "NSOZ"}:
            raise ValueError("Every paired recording must retain both regions")
    return rows, groups


def write_metadata(output: Path, settings: dict, input_paths=()):
    output.mkdir(parents=True, exist_ok=True)
    versions = {}
    for name in ("numpy", "scipy", "pandas", "matplotlib", "pyarrow", "statsmodels", "Pillow", "torch"):
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = None
    metadata = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "python": platform.python_version(), "platform": platform.platform(),
        "dependencies": versions, "settings": settings,
        "inputs": [{"name": Path(p).name, "sha256": sha256(Path(p))} for p in input_paths],
    }
    (output / "run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")


def assert_run_identity(output: Path, identity: dict):
    """Allow resume only when code, inputs, parameters and backend agree."""
    output.mkdir(parents=True, exist_ok=True)
    path = output / "run_identity.json"
    if path.exists():
        if json.loads(path.read_text(encoding="utf-8")) != identity:
            raise ValueError("Output contains a different run identity; choose a new --output directory")
    elif any(output.rglob("*.parquet")):
        raise ValueError("Existing shards have no run identity; choose a new --output directory")
    else:
        path.write_text(json.dumps(identity, indent=2), encoding="utf-8")
