"""Explicit commands for example execution, data computation, and paper reproduction."""
from __future__ import annotations

import argparse
import importlib
import json
import sys
from pathlib import Path


def repo_path() -> Path:
    """Locate bundled examples/configuration in an editable repository install."""
    return Path(__file__).resolve().parents[1]


def invoke(module: str, arguments):
    """Reuse archived command parsers without copying their scientific calculations."""
    implementation = importlib.import_module("cfc_repro.analysis." + module)
    old = sys.argv
    sys.argv = [module] + [str(a) for a in arguments]
    try:
        implementation.main()
    finally:
        sys.argv = old


def parser():
    p = argparse.ArgumentParser(description="Three-cohort CFC paper reproduction")
    commands = p.add_subparsers(dest="command", required=True)
    d = commands.add_parser("demo", help="Run one documented public subject example")
    d.add_argument("--example", type=Path, default=repo_path() / "example/public_subject_preprocessed.npz")
    d.add_argument("--output", type=Path, default=Path("outputs/demo"))
    d.add_argument("--surrogates", type=int, default=20)
    d.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    d.add_argument("--six-windows", action="store_true")
    c = commands.add_parser("compute", help="Compute all 312 features on retained contacts")
    c.add_argument("--seizures", type=Path, required=True)
    c.add_argument("--channels", type=Path, required=True)
    c.add_argument("--data-root", type=Path)
    c.add_argument("--mode", choices=["spatial", "dynamic"], required=True)
    c.add_argument("--output", type=Path, required=True)
    c.add_argument("--surrogates", type=int, default=1000)
    c.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    c.add_argument("--max-records", type=int, default=0)
    c.add_argument("--recording-id", default="")
    c.add_argument("--rank-policy", choices=["ordinal_frozen", "average"], default="ordinal_frozen")
    a = commands.add_parser("aggregate", help="Build paired patient inputs from contact shards")
    a.add_argument("--spatial-shards", type=Path, required=True)
    a.add_argument("--dynamic-shards", type=Path, required=True)
    a.add_argument("--eligibility", type=Path, required=True)
    a.add_argument("--output", type=Path, required=True)
    s = commands.add_parser("statistics", help="Run the three study experiments on full patient inputs")
    s.add_argument("--patient-root", type=Path, required=True)
    s.add_argument("--seizures", type=Path, required=True)
    s.add_argument("--output", type=Path, required=True)
    s.add_argument("--stages", nargs="+", choices=["spatial", "loco", "dynamic", "reliability"],
                   default=["spatial", "loco", "dynamic", "reliability"])
    s.add_argument("--config", type=Path, default=repo_path() / "study.json")
    s.add_argument("--quick", action="store_true", help="Reduced resampling for software testing, not paper estimates")
    f = commands.add_parser("figures", help="Render panels from freshly calculated study outputs")
    f.add_argument("--study", type=Path, required=True)
    f.add_argument("--patient-root", type=Path, help="Matched patient inputs required for Fig. 4 regional levels")
    f.add_argument("--panels", nargs="+", choices=["fig2", "fig3", "fig4", "s6", "s10"],
                   default=["fig2", "fig3", "fig4", "s6", "s10"])
    f.add_argument("--output", type=Path, default=Path("outputs/publication"))
    cal = commands.add_parser("calibration", help="Run the archived nine-scenario surrogate calibration")
    cal.add_argument("--output", type=Path, default=Path("outputs/calibration"))
    cal.add_argument("--replicates", type=int, default=100)
    cal.add_argument("--surrogates", type=int, default=200)
    cal.add_argument("--seed", type=int, default=20260926)
    sen = commands.add_parser("sensitivity", help="Recompute targeted raw-signal sensitivity diagnostics")
    sen.add_argument("--seizures", type=Path, required=True)
    sen.add_argument("--channels", type=Path, required=True)
    sen.add_argument("--data-root", type=Path)
    sen.add_argument("--output", type=Path, required=True)
    sen.add_argument("--kind", choices=["targeted", "conservative"], required=True)
    sen.add_argument("--max-records", type=int, default=0)
    sen.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    sen.add_argument("--surrogates", type=int, default=1000)
    primary = commands.add_parser("upper-ripple", help="Recompute the frozen 282-feature dynamic sensitivity")
    primary.add_argument("--patient-root", type=Path, required=True)
    primary.add_argument("--output", type=Path, required=True)
    sa = commands.add_parser("analyze-sensitivity", help="Aggregate raw sensitivity shards and compare with dynamic results")
    sa.add_argument("--kind", choices=["targeted", "conservative"], required=True)
    sa.add_argument("--raw-root", type=Path, required=True)
    sa.add_argument("--experiment-root", type=Path, required=True)
    return p


def statistics(args):
    """Run patient-level E1/E2/E3 and matched reliability with frozen settings.

    LOCO consumes E1 feature statistics from the same output tree. The two
    feature catalogs have intentionally different traversal orders because
    order allocates draws from the archived shared bootstrap stream.
    """
    settings = json.loads(args.config.read_text(encoding="utf-8"))
    source = args.patient_root
    out = args.output
    spatial_catalog = source / "spatial_feature_catalog.csv"
    if {"spatial", "loco"}.intersection(args.stages) and not spatial_catalog.is_file():
        raise FileNotFoundError("E1/E2 require spatial_feature_catalog.csv in the frozen computation order; see REPRODUCE.md")
    def options(name):
        values = settings[name].copy()
        if args.quick:
            for key in values:
                if key != "seed":
                    values[key] = 30
        return [item for key, value in values.items() for item in ("--" + key.replace("_", "-"), value)]
    if "spatial" in args.stages:
        invoke("spatial", ["--patient-table", source / "patient_spatial_0_30.parquet", "--feature-catalog", spatial_catalog,
                           "--manifest", args.seizures, "--output-root", out / "spatial"] + options("spatial_inference"))
    if "loco" in args.stages:
        feature_stats = out / "spatial/01_三队列独立SOZ与NSOZ分析/01_统计数据/cohort_feature_statistics.csv"
        if not feature_stats.is_file():
            raise FileNotFoundError("LOCO requires spatial statistics; include --stages spatial loco or reuse that output")
        invoke("loco", ["--patient-table", source / "patient_spatial_0_30.parquet", "--feature-catalog", spatial_catalog,
                        "--experiment1-feature-stats", feature_stats, "--output-root", out / "loco"] + options("loco_inference"))
    if "dynamic" in args.stages:
        invoke("dynamics", ["--source-experiment", source, "--output-root", out / "dynamic"] + options("dynamic_inference"))
    if "reliability" in args.stages:
        invoke("reliability", ["--early", source / "patient_early_interaction_312_features.parquet", "--catalog", source / "feature_catalog.csv",
                              "--output", out / "reliability"] + options("matched_reliability"))
    from .io import write_metadata
    write_metadata(out, {"stages": args.stages, "quick_test_only": args.quick, "config": settings}, (args.config,))


def sensitivity(args):
    from .pipeline import configure
    from .io import read_manifests, write_metadata, sha256, assert_run_identity
    from .core import raw_sensitivity as raw, conservative_spikes as conservative
    configure("raw_sensitivity", args.surrogates, args.device)
    raw.N_SURROGATES = args.surrogates
    conservative.N_SURROGATES = args.surrogates
    records, groups = read_manifests(args.seizures, args.channels, args.data_root)
    if args.max_records:
        records = records[:args.max_records]
    args.output.mkdir(parents=True, exist_ok=True)
    from .core import metrics, surrogates
    identity = {"kind": args.kind, "surrogates": args.surrogates, "device": args.device,
                "rank_policy": metrics.RANK_POLICY, "welch_window_sec": 4,
                "seed": raw.SEED if args.kind == "targeted" else conservative.SEED,
                "recordings": [r["recording_id"] for r in records],
                "seizures_sha256": sha256(args.seizures), "channels_sha256": sha256(args.channels),
                "code_sha256": {Path(m.__file__).name: sha256(Path(m.__file__))
                    for m in (metrics, metrics.preprocessing, surrogates, raw, conservative, metrics.PAC, metrics.COHERENCE)}}
    assert_run_identity(args.output, identity)
    process = raw.process_record if args.kind == "targeted" else conservative.process_record
    for i, record in enumerate(records, 1):
        print(f"[{i}/{len(records)}] {record['recording_id']}", flush=True)
        process(record, groups[(record["dataset_id"], record["recording_id"])], args.output)
    write_metadata(args.output, {"kind": args.kind, "device": args.device, "surrogates": args.surrogates,
                                "welch_window_sec": 4, "seed": raw.SEED if args.kind == "targeted" else conservative.SEED},
                   (args.seizures, args.channels))


def main():
    args = parser().parse_args()
    if args.command == "demo":
        from .pipeline import demo
        demo(args.example, args.output, args.surrogates, args.device, args.six_windows)
    elif args.command == "compute":
        from .pipeline import compute_records
        compute_records(args.seizures, args.channels, args.output, args.mode, args.surrogates,
                        args.device, args.data_root, args.max_records, args.recording_id, args.rank_policy)
    elif args.command == "aggregate":
        from .pipeline import aggregate
        aggregate(args.spatial_shards, args.dynamic_shards, args.eligibility, args.output)
    elif args.command == "statistics":
        statistics(args)
    elif args.command == "figures":
        from .figures import render
        render(args.study, args.output, args.panels, args.patient_root)
    elif args.command == "calibration":
        from .core import metrics
        invoke("calibration", ["--bicoherence-module", metrics.BICOHERENCE.__file__, "--coherence-module", metrics.COHERENCE.__file__,
                               "--output", args.output, "--replicates", args.replicates, "--surrogates", args.surrogates, "--seed", args.seed])
    elif args.command == "sensitivity":
        sensitivity(args)
    elif args.command == "upper-ripple":
        from .analysis.upper_ripple import run
        run(args.patient_root, args.output)
    elif args.command == "analyze-sensitivity":
        if args.kind == "targeted":
            invoke("raw_sensitivity_analysis", ["--raw-root", args.raw_root, "--experiment-root", args.experiment_root])
        else:
            from .analysis import conservative_spike_analysis as cs
            cs.RAW = args.raw_root
            cs.ROOT = args.experiment_root
            cs.SECTION = cs.ROOT / "07_关键敏感性分析"
            cs.DATA_OUT = cs.SECTION / "01_统计数据"
            cs.FIG_OUT = cs.SECTION / "02_结果图"
            cs.CODE_OUT = cs.SECTION / "03_分析代码"
            cs.main()


if __name__ == "__main__":
    main()
