"""Small deterministic checks of estimator definitions and scientific aggregation."""
import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

from cfc_repro.core import metrics, surrogates, preprocessing
from cfc_repro.pipeline import configure
from cfc_repro.analysis import dynamics, window_aggregation as wa
from cfc_repro.io import read_manifests, sha256, assert_run_identity
from cfc_repro.cli import repo_path
from scripts.prepare_inputs import unpack_selection
from scripts.run_study import parser as study_parser, build_commands


class EstimatorTests(unittest.TestCase):
    def setUp(self):
        configure("dynamic", 20, "cpu")

    def test_cpu_pac_matches_archived_helper(self):
        rng = np.random.default_rng(12)
        phase = rng.uniform(-np.pi, np.pi, 2000)
        amplitude = np.exp(.4 * np.cos(phase) + rng.normal(0, .2, 2000))
        shifts = np.array([500, 700, 1400])
        actual = metrics.pac_metric_values_gpu(phase, amplitude, shifts)
        helper = metrics.PAC.PhaseMetricHelper(phase)
        for name, fn in (("tort_mi", helper.tort_mi), ("mvl", helper.mvl), ("glm_pac", helper.glm_r2)):
            self.assertAlmostEqual(actual[name][0], fn(amplitude), places=13)
            np.testing.assert_allclose(actual[name][1], [fn(np.roll(amplitude, s)) for s in shifts], rtol=0, atol=1e-13)

    def test_ppc_and_correlation_shift_direction(self):
        rng = np.random.default_rng(31)
        low = np.exp(1j * rng.normal(size=2000))
        high = np.exp(-2j * rng.normal(size=2000))
        shifts = np.array([500, 800, 1000])
        observed, null = metrics.ppc_values_gpu(low, high, shifts)
        self.assertAlmostEqual(observed, abs(np.mean(low * high)))
        np.testing.assert_allclose(null, [abs(np.mean(low * np.roll(high, s))) for s in shifts])
        left, right = low.real, high.real
        observed, null = metrics.correlation_values_gpu(left, right, shifts)
        self.assertAlmostEqual(observed, np.mean(left * right))
        np.testing.assert_allclose(null, [np.mean(left * np.roll(right, s)) for s in shifts])

    def test_surrogate_standardization(self):
        mean, std, z, p = metrics.generic_stats(4, np.array([1, 2, 3, 4]))
        self.assertEqual(mean, 2.5)
        self.assertAlmostEqual(std, np.std([1, 2, 3, 4], ddof=1))
        self.assertAlmostEqual(z, 1.5 / std)
        self.assertEqual(p, .4)
        row = surrogates.nested_rows({}, 1, np.ones(20))[0]
        self.assertEqual(row["zero_surrogate_variance"], 1)

    def test_shift_stream_reproducibility_and_bounds(self):
        first = surrogates.circular_shifts(5000, 500, 20260916, "record", "channel")
        second = surrogates.circular_shifts(5000, 500, 20260916, "record", "channel")
        other = surrogates.circular_shifts(5000, 500, 20260916, "record", "other")
        np.testing.assert_array_equal(first, second)
        self.assertFalse(np.array_equal(first, other))
        self.assertTrue(((first >= 500) & (first <= 4500)).all())

    def test_aac_rank_policy_is_explicit(self):
        values = np.array([4., 1., 3., 2.])
        metrics.RANK_POLICY = "ordinal_frozen"
        frozen = metrics.rank_zscore(values)
        metrics.RANK_POLICY = "average"
        np.testing.assert_allclose(frozen, metrics.rank_zscore(values))
        tied = np.array([1., 1., 2., 2.])
        average = metrics.rank_zscore(tied)
        metrics.RANK_POLICY = "ordinal_frozen"
        self.assertFalse(np.allclose(average, metrics.rank_zscore(tied)))

    def test_welch_and_windows_remain_distinct(self):
        windows = configure("spatial", 20, "cpu")
        self.assertEqual(metrics.COHERENCE.WELCH_WINDOW_SEC, 4)
        self.assertEqual([w.end_sec - w.start_sec for w in windows], [30, 30])
        windows = configure("dynamic", 20, "cpu")
        self.assertEqual(metrics.COHERENCE.WELCH_WINDOW_SEC, 2)
        self.assertEqual([w.end_sec - w.start_sec for w in windows], [10] * 6)
        self.assertEqual(metrics.AMPLITUDE_BANDS[-1], ("fast_ripple_low", 150., 200.))

    def test_fdr_ignores_nonfinite_entries(self):
        q = dynamics.bh_fdr(np.array([.01, .04, .03, np.nan]))
        np.testing.assert_allclose(q[:3], [.03, .04, .04])
        self.assertTrue(np.isnan(q[3]))


class AggregationTests(unittest.TestCase):
    def test_contact_then_region_medians_not_pooled_contact_rows(self):
        rows = []
        # Contact A appears in three seizures; contact B in one. Pooling rows
        # would overweight A. Frozen aggregation gives (0 + 100) / 2 = 50.
        for record, channel, index, value in (("r1", "A", 1, 0), ("r2", "A", 1, 0),
                                               ("r3", "A", 1, 0), ("r1", "B", 2, 100)):
            row = dict(dataset_id="ds003029", patient_id="p", recording_id=record,
                       channel_name=channel, channel_index_1based=index, soz_label="SOZ",
                       window_id="post_cumulative_10", cfc_family="PAC", method="tort_mi", feature_id="f")
            row.update({name: value for name in wa.VALUE_COLUMNS})
            rows.append(row)
        frame = pd.DataFrame(rows)
        region = wa.aggregate_zone_window(frame, {("ds003029", r) for r in ("r1", "r2", "r3")})
        self.assertEqual(region.z_value.iloc[0], 50)
        self.assertEqual(np.median(frame.z_value), 0)

    def test_paired_regional_time_interaction(self):
        rows = []
        for window, soz, nsoz in ((wa.PRE_NEAR, 4, 3), (wa.POST_EARLY, 7, 2)):
            for label, value in (("SOZ", soz), ("NSOZ", nsoz)):
                row = dict(dataset_id="ds003029", patient_id="p", window_id=window,
                           cfc_family="PAC", method="tort_mi", feature_id="f", soz_label=label, n_channels=2)
                row.update({name: value for name in wa.VALUE_COLUMNS})
                rows.append(row)
        paired = wa.early_interaction(wa.spatial_contrast(pd.DataFrame(rows)))
        self.assertEqual(paired.interaction_z_value.iloc[0], (7 - 2) - (4 - 3))


class ReleaseTests(unittest.TestCase):
    def test_selection_rejects_corrupted_counts(self):
        selection = json.loads((repo_path() / "public_selection.json").read_text())
        selection["row_counts"]["channels"] += 1
        with self.assertRaisesRegex(ValueError, "row count"):
            unpack_selection(selection)

    def test_selection_rejects_unexpected_cohort(self):
        selection = json.loads((repo_path() / "public_selection.json").read_text())
        selection["seizures"][0][0] = "Lanzhou"
        with self.assertRaisesRegex(ValueError, "another cohort"):
            unpack_selection(selection)

    def test_driver_stops_public_pilot_before_statistics(self):
        args = study_parser().parse_args([
            "--seizures", "a.csv", "--channels", "b.csv", "--eligibility", "c.csv",
            "--data-root", ".", "--output", "outputs/test", "--stop-after", "compute"])
        commands = build_commands(args)
        self.assertEqual(len(commands), 2)
        self.assertTrue(all("compute" in command for command in commands))

    def test_figure_entry_rejects_missing_computed_input(self):
        from cfc_repro.figures import render
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            with self.assertRaisesRegex(FileNotFoundError, "Expected exactly one"):
                render(root, root / "plots", ["fig2"])
            self.assertFalse((root / "plots").exists())

    def test_paths_and_inference_settings(self):
        from cfc_repro.cli import parser
        args = parser().parse_args(["statistics", "--patient-root", ".", "--seizures", "a.csv", "--output", "outputs/test"])
        self.assertEqual(args.config, repo_path() / "study.json")
        settings = json.loads(args.config.read_text())
        self.assertEqual(settings["surrogates"], 1000)
        self.assertEqual(settings["spatial_inference"]["feature_bootstrap"], 10000)
        self.assertTrue((repo_path() / "REPRODUCE.md").is_file())

    def test_example_integrity_and_single_public_subject(self):
        path = repo_path() / "example"
        metadata = json.loads((path / "metadata.json").read_text())
        self.assertEqual(metadata["license"], "CC0-1.0")
        self.assertEqual(metadata["dataset_version"], "1.0.3")
        self.assertEqual(sha256(path / "public_subject_preprocessed.npz"), metadata["sha256"])
        with np.load(path / "public_subject_preprocessed.npz", allow_pickle=False) as contents:
            self.assertEqual(contents["signal_uv"].shape, (4, 34000))
            self.assertTrue(np.isfinite(contents["signal_uv"]).all())
            self.assertEqual(list(contents["soz_labels"]), ["SOZ", "SOZ", "NSOZ", "NSOZ"])

    def test_public_selectors_exclude_private_cohort(self):
        selection = json.loads((repo_path() / "public_selection.json").read_text())
        tables = unpack_selection(selection)
        recordings = pd.DataFrame(tables["seizures.csv"][1], columns=tables["seizures.csv"][0])
        self.assertEqual(set(recordings.dataset_id), {"ds003029", "ds004100"})
        self.assertEqual(len(recordings), 167)
        self.assertEqual(recordings.groupby("dataset_id").patient_id.nunique().to_dict(), {"ds003029": 14, "ds004100": 35})
        self.assertFalse(recordings.signal_path.str.contains(":|\\\\", regex=True).any())
        self.assertEqual(len(tables["channels.csv"][1]), 16020)
        self.assertEqual(len(tables["window_eligibility.csv"][1]), 1002)

    def test_rejects_duplicate_manifest_records(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            row = dict(dataset_id="ds003029", patient_id="p", recording_id="r", signal_path="x.edf",
                       file_format="EDF", implant_type="ECOG", onset_sec=40)
            pd.DataFrame([row, row]).to_csv(root / "seizures.csv", index=False)
            pd.DataFrame([dict(dataset_id="ds003029", recording_id="r", channel_name_raw="A",
                               channel_index_1based=1, soz_label="SOZ")]).to_csv(root / "channels.csv", index=False)
            with self.assertRaisesRegex(ValueError, "Duplicate recordings"):
                read_manifests(root / "seizures.csv", root / "channels.csv")

    def test_unknown_units_are_not_assumed(self):
        self.assertEqual(preprocessing.unit_scale_to_uv("mV"), 1000)
        self.assertIsNone(preprocessing.unit_scale_to_uv("unknown"))

    def test_resume_rejects_different_parameters(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            assert_run_identity(root, {"surrogates": 20})
            assert_run_identity(root, {"surrogates": 20})
            with self.assertRaisesRegex(ValueError, "different run identity"):
                assert_run_identity(root, {"surrogates": 1000})

    def test_resume_rejects_unidentified_old_shards(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "old.parquet").touch()
            with self.assertRaisesRegex(ValueError, "no run identity"):
                assert_run_identity(root, {"surrogates": 1000})


if __name__ == "__main__":
    unittest.main()
