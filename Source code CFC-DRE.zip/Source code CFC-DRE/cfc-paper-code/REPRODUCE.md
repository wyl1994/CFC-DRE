# Reproduce The Analyses

Run commands from the repository root after the editable installation in
README.md. Keep recordings, private inputs and generated outputs outside Git.

## 1. Inputs

The public selection covers 49 patients and 167 recordings: 14/39 in ds003029
v1.0.3 and 35/128 in ds004100 v1.1.3. The private Lanzhou cohort contains
32 patients and 102 recordings and is not distributed. The full study uses
81 patients; complete six-window trajectories use 79 matched patients.

```bash
python scripts/prepare_inputs.py --output local_inputs/public
python scripts/prepare_inputs.py --templates --output local_inputs/private_templates
```

The first command restores the frozen public selectors. The second writes
header-only schemas for authorized private annotations. Existing files are
never overwritten. Use `--cohort ds003029` or `--cohort ds004100` for one cohort.
Do not substitute every recording in the downloaded datasets for this subset.

| File | One row per | Required fields |
| --- | --- | --- |
| seizures.csv | Recording | dataset_id, patient_id, recording_id, signal_path, file_format, implant_type, onset_sec |
| channels.csv | Retained contact/recording | dataset_id, recording_id, channel_name_raw, channel_index_1based, soz_label |
| window_eligibility.csv | Recording/window | dataset_id, patient_id, recording_id, start_sec, end_sec, window_state_status, offset_status |

`onset_sec` is relative to the actual signal file, including any local crop.
`signal_path` may be absolute or relative to `--data-root`. Public relative paths
start with `ds003029/` or `ds004100/`. Supported source formats are EDF and
BrainVision VHDR; keep VHDR/EEG/VMRK sidecars together. Header units are converted
to microvolts. Unknown units are rejected, not assumed.

Contact indices are one-based, names must match source headers, and `soz_label`
is SOZ or NSOZ. **CAR uses all retained intracranial contacts**, not a display
subset. Clinical onset, bad-contact exclusion and labels are input annotations,
not outputs inferred by CFC. Authorized Lanzhou rows must use the same schema.

Eligibility retains actual annotated seizure coverage. Known short seizures
are excluded from relevant post-onset windows; `confirmed_ge30` is the separate
documented-duration sensitivity subset. An unknown offset is not confirmation.

## 2. Compute And Aggregate

Full primary workflow, with all three authorized cohorts in the manifests:

```bash
python scripts/run_study.py --seizures private_inputs/seizures.csv --channels private_inputs/channels.csv --eligibility private_inputs/window_eligibility.csv --data-root local_data --output outputs/full_run
```

Equivalent individual steps:

```bash
python -m cfc_repro compute --seizures private_inputs/seizures.csv --channels private_inputs/channels.csv --data-root local_data --mode spatial --surrogates 1000 --output outputs/spatial
python -m cfc_repro compute --seizures private_inputs/seizures.csv --channels private_inputs/channels.csv --data-root local_data --mode dynamic --surrogates 1000 --output outputs/dynamic
python -m cfc_repro aggregate --spatial-shards outputs/spatial/shards --dynamic-shards outputs/dynamic/shards --eligibility private_inputs/window_eligibility.csv --output outputs/patient_inputs
python -m cfc_repro statistics --patient-root outputs/patient_inputs --seizures private_inputs/seizures.csv --output outputs/study
```

For public-only computation, substitute `local_inputs/public/*.csv`, pass
`--stop-after compute` to the driver and keep the downloaded BIDS hierarchy.
For a recording pilot, add `--max-records 1 --surrogates 20`. These reduced runs
are software tests, not paper estimates. Three-cohort statistics intentionally
require all three authorized cohorts. Optional CUDA needs compatible PyTorch;
the CPU backend runs without it. CPU float64 and CUDA float32 are not claimed
to give bitwise identical output.

The driver creates `01_computation/`, `02_patient_inputs/` and `03_statistics/`.
The individual commands above use shorter output-directory names. Do not mix
these two path conventions when following later commands.

Windows are cropped only after filtering the buffered 68-s interval. Spatial
processing uses 30-s windows/4-s coherence Welch segments; dynamic processing
uses six 10-s windows/2-s segments. The frozen AAC rank policy is
`ordinal_frozen`; `--rank-policy average` is an explicitly different analysis.

Aggregation order: seizures within contact -> contacts within region -> paired
patient SOZ-NSOZ contrasts. The early interaction is
`(SOZ_post - NSOZ_post) - (SOZ_pre - NSOZ_pre)`, not a subtraction of two pooled
group medians. Do not reorder the spatial/dynamic feature catalogs: the frozen
bootstrap traversal assigns draws according to their original order.

`study.json` records seeds and resampling counts. Inference resampling settings
are read by `statistics`; estimator bands/preprocessing and computation seeds
remain frozen in the core code. Editing descriptive fields in the JSON alone
does not change those estimator settings. `--quick` reduces inference draws
only for testing and cannot reproduce paper confidence intervals/counts.

## 3. Plot Computed Results

For the individual-command output paths:

```bash
python scripts/reproduce_figures.py --study outputs/study --patient-root outputs/patient_inputs --output outputs/figures
```

For the driver paths, use `--study outputs/full_run/03_statistics` and
`--patient-root outputs/full_run/02_patient_inputs` instead.

The command redraws Fig. 2, Fig. 3, the archived Fig. 4 regional-level layout,
paired-contrast S6 and matched-window S10. It reads generated tables and
recomputes Fig. 4 regional-level display intervals with the original plotting
bootstrap (3,000 draws; seed 20260918). A 79-patient matched input is required.
Select only available panels using `--panels fig2 fig3` or `--panels s10`.
Missing or ambiguous inputs fail explicitly. No precomputed paper tables are
bundled. Fig. 1 is manually composed and is not generated by these scripts.

## 4. Sensitivity Checks

These are separate from the primary driver:

```bash
python -m cfc_repro upper-ripple --patient-root outputs/patient_inputs --output outputs/upper_ripple
python -m cfc_repro sensitivity --kind targeted --seizures private_inputs/seizures.csv --channels private_inputs/channels.csv --data-root local_data --output outputs/targeted
python -m cfc_repro analyze-sensitivity --kind targeted --raw-root outputs/targeted/raw_cache --experiment-root outputs/study/dynamic
python -m cfc_repro sensitivity --kind conservative --seizures private_inputs/seizures.csv --channels private_inputs/channels.csv --data-root local_data --output outputs/conservative
python -m cfc_repro analyze-sensitivity --kind conservative --raw-root outputs/conservative/raw_cache --experiment-root outputs/study/dynamic
python -m cfc_repro calibration --replicates 100 --surrogates 200 --seed 20260926 --output outputs/calibration
python -m cfc_repro.analysis.aac_audit --seizures private_inputs/seizures.csv --channels private_inputs/channels.csv --preprocessing-script cfc_repro/core/preprocessing.py --output outputs/aac_audit --patients-per-cohort 3 --surrogates 1000
```

The direct AAC audit needs resolved local `signal_path` values. Targeted checks
include guard windows, median referencing, aggressive transient masking,
power covariates and harmonic diagnostics. Conservative masking preserves the
8-MAD/2-MAD/80-ms/+/-25-ms event rule. Raw sensitivity coherence retains the
archived 4-s Welch setting; it is not silently replaced by the dynamic 2-s
setting. The 150-200-Hz exclusion retains 282 features. Calibration uses nine
synthetic scenarios and requires no patient data. Use separate output paths
for different counts/backends/settings; mismatched cached runs are rejected.

## Code To Paper

All paths below are within `cfc_repro/`. The CLI and driver set portable input
paths before invoking the archived calculations; use these documented entries
instead of invoking legacy helper `main()` functions with their old defaults.

| Code | Purpose / paper output |
| --- | --- |
| core/preprocessing.py, formal.py | EDF/VHDR readers, CAR, buffered preprocessing, record computation |
| core/pac.py | Tort MI, MVL and GLM PAC estimators |
| core/metrics.py, bicoherence.py, cfc_coherence.py | Band/feature catalog, PPC/AAC, bicoherence, LF-envelope coherence |
| core/surrogates.py | Measure-specific nulls and standardized contact features |
| pipeline.py, io.py | Portable computation, demo, manifests, patient aggregation, run identity |
| analysis/spatial_aggregation.py, window_aggregation.py | Original contact/patient hierarchy and paired windows |
| analysis/spatial.py | Within-cohort inference and pairwise regional map agreement; Fig. 2/3 |
| analysis/loco.py | Discovery/held-out rotations, candidates and transportability; Fig. 3 |
| analysis/dynamics.py | Family/feature early interaction, trajectories and cached checks; Table III/S6 |
| analysis/reliability.py | Matched-window comparison and split-half reliability; S10 |
| core/raw_sensitivity.py, analysis/raw_sensitivity_analysis.py | Guard/reference/mask, power/harmonic checks; Table IV/S8 |
| core/conservative_spikes.py, analysis/conservative_spike_analysis.py | Conservative spike-mask check; Table IV |
| analysis/upper_ripple.py, calibration.py, aac_audit.py | Upper-ripple sensitivity, simulations and rank audit |
| figures.py, analysis/publication.py | Fig. 2-4/S6/S10 plotting and importable paper table-format functions |
| cli.py, __main__.py | Public command dispatcher |

312 features: PAC 45, PPC 90, AAC 56, bicoherence 105, CFC coherence 16.
The paper's 228 positive-direction features, 75 jointly supported features and
82 all-rotation held-out features have different definitions. Do not report
them as one interchangeable significant-feature count. `fast_ripple_low` is
the frozen machine ID for the 150-200-Hz upper-ripple band.

