"""Plot newly computed study outputs; no stored result tables are bundled."""
import sys
from cfc_repro.cli import main

if __name__ == "__main__":
    sys.argv.insert(1, "figures")
    main()
