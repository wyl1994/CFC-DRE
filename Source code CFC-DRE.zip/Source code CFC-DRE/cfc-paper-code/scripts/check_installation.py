"""Check an editable install and the real public CPU example.

No external recordings or private annotations are required. Expected values
apply only to the separate demo identity, CPU backend and 20 surrogates.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "outputs/installation_check")
    args = parser.parse_args()
    output = args.output.resolve()
    from cfc_repro import __version__, __file__ as package_file

    if Path(package_file).resolve().parent != ROOT / "cfc_repro":
        raise RuntimeError("A different checkout is installed. Run pip install -e . --no-deps in this repository.")

    def run(*arguments: str) -> None:
        command = [sys.executable, *map(str, arguments)]
        print("Running:", subprocess.list2cmdline(command), flush=True)
        subprocess.run(command, cwd=ROOT, check=True)

    run("-m", "unittest", "test_reproducibility", "-v")
    run("-m", "cfc_repro", "demo", "--six-windows", "--surrogates", "20",
        "--device", "cpu", "--output", output / "demo")

    frame = pd.read_parquet(output / "demo/contact_window_features.parquet")
    if len(frame) != 7488 or not frame.groupby(["channel_name", "window_id"]).size().eq(312).all():
        raise ValueError("Expected 4 contacts x 6 windows x 312 complete features")
    if not frame.finite_pass.eq(1).all() or frame.zero_surrogate_variance.any():
        raise ValueError("Example contains invalid or degenerate surrogate results")

    def read_family(path: Path) -> pd.Series:
        return pd.read_csv(path).set_index("cfc_family").interaction.sort_index()

    actual = read_family(output / "demo/example_family_interactions.csv")
    expected = read_family(ROOT / "example/expected_cpu_20_surrogates.csv")
    if not actual.index.equals(expected.index):
        raise ValueError("Example family identifiers differ from the baseline")
    # Permit small CPU/library round-off, not scientifically meaningful drift.
    np.testing.assert_allclose(actual.to_numpy(), expected.to_numpy(), rtol=1e-9, atol=1e-9)
    report = {"version": __version__, "tests": "passed",
              "example_rows": len(frame), "device": "cpu", "surrogates": 20,
              "max_absolute_family_difference": float(np.max(np.abs(actual - expected))),
              "tolerance_rtol_atol": 1e-9, "population_inference": False}
    (output / "check_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"Installation check PASSED. Report: {output / 'check_report.json'}", flush=True)


if __name__ == "__main__":
    main()
