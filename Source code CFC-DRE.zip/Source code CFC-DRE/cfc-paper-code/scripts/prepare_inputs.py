"""Expand the compact public selection into the three computation input tables.

The JSON stores repeated contact lists once. Expansion preserves the frozen
row order and strings; it does not download EEG or infer clinical annotations.
"""
import argparse
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def unpack_selection(selection):
    """Return filename -> (column names, rows), without touching the filesystem."""
    if selection.get("schema_version") != 1:
        raise ValueError("Unsupported public selection schema")
    channels = []
    for cohort, record, profile_id in selection["contact_assignments"]:
        channels.extend([[cohort, record, *contact]
                         for contact in selection["contact_profiles"][profile_id]])
    eligibility = []
    for cohort, patient, record, windows in selection["eligibility"]:
        eligibility.extend([[cohort, patient, record, *window] for window in windows])
    tables = {
        "seizures.csv": (selection["seizure_columns"], selection["seizures"]),
        "channels.csv": (selection["channel_columns"], channels),
        "window_eligibility.csv": (selection["eligibility_columns"], eligibility),
    }
    for name, (columns, rows) in tables.items():
        key = {"window_eligibility.csv": "eligibility"}.get(name, name.removesuffix(".csv"))
        if len(rows) != selection["row_counts"][key] or any(len(row) != len(columns) for row in rows):
            raise ValueError(f"Invalid row count or width in {name}")
        if any(row[0] not in ("ds003029", "ds004100") for row in rows):
            raise ValueError("Public selection unexpectedly contains another cohort")
    return tables


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--selection", type=Path, default=ROOT / "public_selection.json")
    parser.add_argument("--output", type=Path, default=ROOT / "local_inputs/public")
    parser.add_argument("--cohort", choices=["ds003029", "ds004100"])
    parser.add_argument("--templates", action="store_true", help="Write empty headers for authorized private inputs")
    args = parser.parse_args()
    tables = unpack_selection(json.loads(args.selection.read_text(encoding="utf-8")))
    if any((args.output / name).exists() for name in tables):
        parser.error("Input files already exist; use a new output directory")
    args.output.mkdir(parents=True, exist_ok=True)
    for name, (columns, rows) in tables.items():
        selected = [] if args.templates else [r for r in rows if args.cohort is None or r[0] == args.cohort]
        with (args.output / name).open("w", encoding="utf-8", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(columns)
            writer.writerows(selected)
        print(f"{name}: {len(selected)} rows")
    print(f"Local manifests: {args.output.resolve()}")


if __name__ == "__main__":
    main()
