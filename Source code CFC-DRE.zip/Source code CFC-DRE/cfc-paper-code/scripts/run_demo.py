"""Run the labeled public example through the same estimators as the study."""
import sys
from cfc_repro.cli import main

if __name__ == "__main__":
    sys.argv.insert(1, "demo")
    main()
