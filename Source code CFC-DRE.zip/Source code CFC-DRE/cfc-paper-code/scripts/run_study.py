"""Run the primary study from authorized raw recordings to patient inference.

This sequential driver calls the documented CLI without reimplementing any
scientific calculation. Raw sensitivities and simulations are separate commands.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--seizures", type=Path, required=True)
    p.add_argument("--channels", type=Path, required=True)
    p.add_argument("--eligibility", type=Path, required=True)
    p.add_argument("--data-root", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--config", type=Path, default=ROOT / "study.json")
    p.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    p.add_argument("--surrogates", type=int, default=1000)
    p.add_argument("--max-records", type=int, default=0, help="Pilot limit; cannot be used with group inference")
    p.add_argument("--stop-after", choices=["compute", "aggregate", "statistics"], default="statistics")
    p.add_argument("--quick", action="store_true", help="Reduced statistical resampling; not paper estimates")
    return p


def build_commands(args: argparse.Namespace) -> list[list[str]]:
    """Construct ordered CLI calls with absolute local input/output paths."""
    root = args.output.resolve()
    spatial = root / "01_computation/spatial"
    dynamic = root / "01_computation/dynamic"
    patient = root / "02_patient_inputs"
    inference = root / "03_statistics"
    prefix = [sys.executable, "-m", "cfc_repro"]
    common = ["--seizures", str(args.seizures.resolve()), "--channels", str(args.channels.resolve()),
              "--data-root", str(args.data_root.resolve()), "--surrogates", str(args.surrogates),
              "--device", args.device, "--max-records", str(args.max_records)]
    commands = [prefix + ["compute", *common, "--mode", mode, "--output", str(target)]
                for mode, target in (("spatial", spatial), ("dynamic", dynamic))]
    if args.stop_after == "compute":
        return commands
    commands.append(prefix + ["aggregate", "--spatial-shards", str(spatial / "shards"),
                    "--dynamic-shards", str(dynamic / "shards"), "--eligibility", str(args.eligibility.resolve()),
                    "--output", str(patient)])
    if args.stop_after == "aggregate":
        return commands
    commands.append(prefix + ["statistics", "--patient-root", str(patient),
                    "--seizures", str(args.seizures.resolve()), "--output", str(inference),
                    "--config", str(args.config.resolve())] + (["--quick"] if args.quick else []))
    return commands


def main() -> None:
    p = parser()
    args = p.parse_args()
    if args.surrogates < 2 or args.max_records < 0:
        p.error("Use at least two surrogates and a nonnegative --max-records")
    if args.max_records and args.stop_after == "statistics":
        p.error("A recording pilot is not full group inference; use --stop-after compute or aggregate")
    for path in (args.seizures, args.channels, args.config):
        if not path.is_file():
            p.error(f"Missing local input: {path}")
    if args.stop_after != "compute" and not args.eligibility.is_file():
        p.error(f"Missing local eligibility: {args.eligibility}")
    if not args.data_root.is_dir():
        p.error(f"Missing raw-data folder: {args.data_root}")
    if args.stop_after == "statistics":
        cohorts = set(pd.read_csv(args.seizures, dtype=str).dataset_id)
        if cohorts != {"ds003029", "ds004100", "Lanzhou"}:
            p.error("Three-cohort inference requires authorized rows for all cohorts; use --stop-after compute for public-only data")

    for command in build_commands(args):
        print("Running:", subprocess.list2cmdline(command), flush=True)
        subprocess.run(command, cwd=ROOT, check=True)
    print(f"Primary workflow complete through {args.stop_after}: {args.output.resolve()}")


if __name__ == "__main__":
    main()
